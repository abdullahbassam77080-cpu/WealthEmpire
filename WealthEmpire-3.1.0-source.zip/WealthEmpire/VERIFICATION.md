# Wealth Empire 3.0.0 — verification

Verified 7 October 2026 with JDK 17, Gradle 8.9 and Android SDK 35.

| Check | Result |
|---|---|
| Core JVM tests | 102 passed, 0 failed/skipped |
| Android-module JVM tests | 29 passed, 0 failed/skipped |
| APK assembly | Passed, versionCode 7 / versionName 3.0.0 |
| Android lint | 0 errors; 4 non-blocking dependency-update suggestions |
| Android instrumentation | Compiled into a test APK; NOT executed on a device |
| APK signature | Verified; same certificate as 2.1.0 |
| AR/EN resources | 478 matching keys; no duplicates/missing translations |

## Financial and world coverage

Pause and ×1/5/12/16, old-speed settlement, backward clock, seeded save/restore, full elapsed absence over hours/days, Cross hedge-aware liquidation bounds, isolated limits, partial close, fees, reserved orders, limit/stop/TP/SL, sampled-path stop before later liquidation, funding, annual token APR/compounding/quotas/locks/cost basis, financial total conservation, research anti-farming, career modes, macro surprises/policy/commodities/network/earnings/story follow-ups, immutable chart histories and portfolio hedges.

The Room repository tests cover journal checksum/gap/idempotence, acknowledgement persistence, failed-write atomicity, full-snapshot isolation from commands, recovery from a valid backup+journal and reset/checkpoint ordering. JVM persistence tests use a memory DAO. Room migration/SQL and real pointer/navigation instrumentation tests are included and compiled, but their device execution remains unverified.

## Latency measurement

60 acknowledged commands: 30 transfers, 15 BTC futures opens and 15 closes. Active BTC Earn, ×16 backlog from one real-day absence, real GZIP snapshot encoding and a deliberately delayed 400ms snapshot store.

- Median: 5.00 ms.
- P95: 13.16 ms.
- Maximum: 39.41 ms.

This is a JVM/server measurement with a memory journal, not Android Room fsync, touchscreen-to-frame latency or a guarantee on a physical phone. It tests actor priority under competing simulation/compression. Device profiling is still required to validate 100–150ms and scrolling/FPS targets on the user's hardware.

## Balance runs

Three seeds (7, 42, 2026), each 2,160 game days, covering a complete economic cycle. Initial portfolio: $11,000 cash and $3,000 each BTC/NVDA/gold. Final net worth: $25,591.83, $28,682.03, $28,825.76. Monthly checks found finite positive prices, bounded inflation and histories; no rapid millionaire growth in this strategy. Separate repeated 50× BTC tests incurred liquidations and substantial losses. These are regression/balance samples, not exhaustive proofs that every strategy is balanced.

## Limits of verification

No physical device/emulator, device reboot, Android low-memory kill, visual screenshot review, measured FPS or ANR stress run was available. Streaming snapshots and bounded immutable histories reduce memory pressure but do not prove low-memory behavior on every device. Offline paths are sampled/adaptive, not tick-for-tick equivalent; old pre-game candles are synthetic. Sessions, bonds, regional FX proxies and microstructure are simplified as described in README and ARCHITECTURE.md.

APK SHA-256: `c4b073f95fbe45992a6931c9fa42b516a6c555532355fd8b4acb742dba093145`

Certificate SHA-256: `3423a1f0d69cb797487e8a6ea78e2cd01ac3ac59549b3bab9013368e76bb5cbf`

Raw test XML, balance/leverage/latency JSON and lint/signature metadata are included under `docs/`. Earlier 2.1.0 verification is archived under `docs/releases/2.1.0/`.
