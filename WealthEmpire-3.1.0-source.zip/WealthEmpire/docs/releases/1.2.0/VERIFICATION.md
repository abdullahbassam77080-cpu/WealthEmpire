# Verification — Wealth Empire 1.2.0

Date: 2026-10-06. Existing Android app modified; package `com.wealthempire`, versionCode 3.

- Android build succeeded with JDK 17, Gradle 8.9, AGP 8.7.3, SDK 35.
- **88 unit tests passed**, zero failures/errors. XML reports are in `docs/test-results`.
- Lint: zero errors, 2 advisory warnings; full reports in `docs`.
- Room/Compose instrumentation APK compiled. **Instrumentation and device/emulator UI tests were not executed.**
- APK signature verified and matches delivered 1.1.0. Android can update that version in place without uninstalling.
- minSdk 26 / targetSdk 35; no INTERNET permission.
- Market price algorithm, catalog, indicators, PRNG, futures rules and signing key compared byte-for-byte with 1.1.0 source: unchanged.

## Checks

Clock: all six candle frames at all four speeds, subminute phase, backwards-clock safety, bounded live/offline replay, no discontinuity on speed change, invalid speed rejected before mutation. Weekday localization and midnight rollover tested in Arabic/English.

Mining: level 1 pays exactly $10 per game minute at every speed, $10/$50/$120/$160 per real minute respectively, gradual ticks equal aggregate settlement, carried fractions survive save and cannot create rounding profit, speed change settles old earnings, saved-speed offline income respects the cap in real hours. Existing fleet, upgrade, capital and save migrations pass.

Slots: nine unique valid paylines, independently priced stakes, selected lines only, single-line/diagonal jackpot checks, multiple simultaneous prizes, exact total accounting, money and RNG unchanged after invalid bets, 89.471% RTP independently enumerated for every line. Full compressed snapshot roundtrip preserves clock, remainder, financial history and nine-cell outcomes without reroll.

Dashboard: screenshot case returns $102.05 financial total instead of $927.05 including equipment; all four wallets, holdings, margins, long/short PNL and order reserves count once. Buying/upgrading hardware reduces the dashboard total by the entire cash spent. Financial chart/day baseline exclude hardware.

Notices: session edges occur once, news links to its actual price bias, only latest notice is retained/deduplicated/dismissible, disabling notices keeps news and price effects active. Modal notice source removed. Rendering and four-second animation are compiled but not device-tested.

Futures: previous Cross hedging, progressive maintenance, partial-close quantity/margin/fee/funding conservation and trade regression tests pass. Compact cards retain close/partial/TP-SL controls; expanded data is optional.

## Limits and references

No screenshot or on-device visual/persistence check is claimed for this revision. The instrumented user path compiles, but requires a device/emulator to execute. Saya public site/store listings/gallery were reviewed; its fruit-machine rules could not be verified. The implementation is a 3×3/payline game matching the requested capabilities, not a claimed exact replica. Trading prices remain locally simulated, not live data.

Financial totals on the dashboard exclude mining hardware. The separate legacy asset statistic retains equipment book value; historical financial chart points begin at this update because the old mixed asset history cannot be reconstructed reliably.

## Updates

Same fixed development key as 1.1.0; keep `dev-signing/debug.keystore`, package and source for subsequent updates. Do not uninstall 1.1.0 to install this APK. Original 1.0.0 used a different, unavailable key; that historical signing limitation remains.

Build: `./gradlew --no-daemon --max-workers=2 -Pksp.incremental=false :core:test :app:testDebugUnitTest :app:assembleDebug :app:lintDebug :app:assembleDebugAndroidTest`.

## APK SHA-256

`7e0162f6496cf89a86c31b03480e855e4bc3bc06b2db32d32ed65269c2ae4fa4`
