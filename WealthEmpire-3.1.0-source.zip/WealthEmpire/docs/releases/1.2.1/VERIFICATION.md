# Verification — Wealth Empire 1.2.1

Date: 2026-10-06. Existing Android app updated; package `com.wealthempire`, versionCode 4.

- Android build succeeded with JDK 17, Gradle 8.9, AGP 8.7.3 and SDK 35.
- **98 unit tests passed**, zero failures/errors. XML reports: `docs/test-results`.
- Lint: zero errors, 1 advisory warnings. Full reports: `docs`.
- Room, gameplay and chart pointer-dispatch instrumentation APK compiled. **Instrumentation and device/emulator visual/gesture tests were not executed.**
- APK signature verified and matches delivered 1.2.0. It can update 1.1.0/1.2.0 without uninstalling.
- minSdk 26 / targetSdk 35; no INTERNET permission.
- All 32 core source/test, persistence/repository, market catalog, Room schema and signing files compared byte-for-byte with 1.2.0: unchanged.

## Chart regression checks

Ten new JVM tests cover vertical/diagonal gesture ownership and touch slop, history anchors during append/prune, following the latest candle, fractional pan accumulation, pinch-centre continuity, history/zoom limits, empty and short series, invalid transform input, rounded BTC and tiny-asset labels, distinct labels in narrow ranges, and compact volume formatting.

`ChartScrollTest` compiles three real pointer-dispatch cases in a Compose vertical-scroll parent: vertical swipe moves the parent without panning; horizontal swipe pans without parent scrolling and Latest restores the view; an active drag continues across a market tick. These cases require a device/emulator to run and are not counted among the 98 executed unit tests.

## Result and limits

One-finger gestures choose an axis after touch slop. Vertical changes remain unconsumed for the enclosing page; horizontal drags and two-finger transforms are consumed by the chart. Pointer handlers restart only on asset/timeframe changes, not price ticks or viewport movement. Historical candles anchor by time, and live view follows new bars. Candle/volume/indicator plots share their horizontal scale; the last price has a dashed marker and rounded axis tag.

Market details and indicator settings are collapsible, OHLC uses a compact row, and a Positions shortcut scrolls to the existing compact position cards. The candle countdown retains simulation speed and actual time remaining.

No on-device appearance or installation check is claimed. This is a native Compose chart with exchange-style interactions, not Binance/MEXC code or live TradingView data. Financial rules, clock/mining rates, Cross risk, partial closes, slot outcomes and save schema are unchanged. Tests for those prior features still pass.

## Reproduce

```sh
./gradlew --no-daemon --max-workers=2 -Pksp.incremental=false :app:clean :core:test :app:testDebugUnitTest :app:assembleDebug :app:lintDebug :app:assembleDebugAndroidTest
./gradlew :app:connectedDebugAndroidTest
```

Keep `dev-signing/debug.keystore` and applicationId for subsequent updates. The old 1.0.0 key differs; this historical limitation does not affect updating 1.1.0/1.2.0. Previous verification summary is retained in `docs/releases/1.2.0`.

APK SHA-256: `791ef1021a0e1d9b9aee984885c91873301734b77459d1a203040b15ac712556`
