# Verification — Wealth Empire 2.0.0

Date: 2026-10-06. Existing native Android app updated: package `com.wealthempire`, versionCode5.

- Build successful: JDK17, Gradle8.9, AGP8.7.3, SDK35, Kotlin2.0.21.
- **113 JVM unit tests passed**: 92 core +21 app; zero failures/errors/skips. Reports in `docs/test-results`.
- Lint: zero errors, 1 advisory warnings; full XML/HTML in `docs`.
- APK signature verified and matches delivered1.2.1. Update1.1.0/1.2.x without uninstalling. minSdk26 / targetSdk35; no INTERNET permission.
- Roomv1→v2 migration and snapshot schema4 are implemented. Both exported Room schemas are included.
- Room migration/large-row, gameplay, savings/new navigation and pointer-dispatch instrumentation APK compiled. **No device/emulator instrumentation, installation, appearance or FPS tests were executed.**
- Signing key, clock, mining, Cross mathematics and wallet rules compared byte-for-byte with1.2.1: unchanged.

## Executed coverage

Savings: annual APR/token units; equity and cost-basis conservation; global bonus tiers across split deposits; tick-frequency-invariant daily compounding; fixed locked APR; daily rewards counted once; early-return clawbacks and72game-hour wait; automatic maturity; USDT Spot-cash settlement; reserved sell quantities; invalid commands do not mutate balances.

Markets: gold/oil/gas units; CNY/JPY USD-per-unit valuation; known stocks/ETFs; target-specific hacks;42day policy effects; haven/risk responses; headline diversity and variable waiting times; exact replay from the saved RNG; no prelaunch execution/history; first-day Spot-only listings; shared ±3 benchmark ETF paths; four risk callbacks per minute; weekday calendars; schema3 clock/fleet retention.

Persistence/UI calculations: complete expanded snapshots; independent mutable typed copies; token/savings/news fields; compressed snapshot round trips; multi-megabyte chunking; missing/reordered/oversized chunks rejected; exact decimal balances; legacy disabled slot results preserved as data; FX/tiny price precision. Prior futures, hedge-aware Cross, partial closes, mining, wallet and chart viewport tests also pass.

## Implemented behavior and limits

75 catalog assets (7 legacy hidden unless owned/open),40 news templates ×3 bilingual variants plus numeric macro reports and branching follow-ups. Finite templates can repeat; random timing/outcomes and saved recent-key exclusion reduce a fixed learnable sequence. A seeded random stream resumes consistently; it is a game simulation, not live data or cryptographic unpredictability.

Gold/energy/Forex trade in inventory units with simulated session calendars. SOXL/SOXS use SOXX as a daily-reset proxy with fictional1% annual expense, not their real fund/index construction. Crypto new listings are fictional and bounded at32 for current save size. Initial chart history is synthetic per timeframe; subsequent OHLC derives from shared sampled marks. Intraminute liquidations are checked at the four sampled prices, not every continuous price between them.

Earn supports variable flexible APR with shared bonus quota, optional daily compounding, partial return, fixed30/90day terms, daily locked rewards, maturity and early-return reward clawback. Rates are simulated, not current Binance rates. This is a defined Simple Earn-style subset, not the entire Binance product family or real investment.

Passive state copying and JSON work were reduced; lists are lazy and indicators compute only when enabled. Financial commands persist immediately; passive checkpoints run every15real seconds and on STOP. A sudden process kill can lose up to15seconds of passive market detail; bounded elapsed-time settlement runs on resume. Market replay remains capped at480game minutes, separate from the mining8real-hour cap. No phone FPS claim is made.

Gambling screen, reel graphics, navigation, wager engine and unused gambling strings removed. Historical result/statistic fields remain data-only to read existing saves and preserve already-realized money.

## Reproduce

```sh
./gradlew --no-daemon --max-workers=2 -Pksp.incremental=false :core:clean :app:clean :core:test :app:testDebugUnitTest :app:assembleDebug :app:lintDebug :app:assembleDebugAndroidTest
./gradlew :app:connectedDebugAndroidTest
```

Room uses supported Kotlin code generation to avoid duplicate Java round outputs in this compiler combination. Previous release documents are retained in `docs/releases/1.2.1`.

APK SHA-256: `f991f816c34253ab203fd54e66e0c1e6fb792f7ddafeecdd867270c5619e245b`
