# Verification — Wealth Empire2.1.0

Date:2026-10-06. Native Android app `com.wealthempire`, versionCode6.

- **Build successful; 100 unit tests passed**:77 core +23 app, zero failures/errors/skips. XML reports in `docs/test-results`.
- Android lint:zero errors, 1 advisory warnings. Reports in `docs`.
- JDK17 / Gradle8.9 / AGP8.7.3 / Kotlin2.0.21 / SDK35; minSdk26, targetSdk35, no INTERNET permission.
- Signature verified and matches2.0.0. Retaining package/key does not preserve the old economy: the user authorized its reset.
- Instrumentation APK compiled. **No device/emulator installation, UI, Room instrumentation or FPS tests were executed.**

## New economy

Starting cash, initial-capital baseline, highest wealth and day-start wealth are$20,000. Other wallets and holdings start empty, realized profit iszero, XP iszero, and the first wealth milestone is$50,000. Mining routes, screens, illustrations, translated resources, engine, commands, models, carried-income and offline fields are removed. Historical gambling result/statistic fields are removed too.

Known earlier snapshot schemas1–4 restart once through `GameEngine.restore` and an atomic `SnapshotDao.reset`. New schema5 saves persist their actual remaining balances, positions, orders and savings and are never topped up on reopen. Correct speed and alert settings survive the authorized restart; fractional old economy time is reset. Unknown/corrupt saves remain errors or use the backup, rather than silently granting a new funded account.

## Executed checks

- Exact fresh$20,000 equity and zero earned profit/XP.
- No idle cash growth at1×,5×,12×,16× or after twelve real hours of absence; repeated resume does not repeat a market replay or grant money.
- Earlier economies restart to$20,000 once; later reopening keeps spent balances and token holdings.
- Unsupported saves and invalid speeds cannot mutate funds; switching speed settles the old clock phase and serialization retains the remainder.
- Removed legacy JSON fields are ignored and are absent from new serialized payloads.
- Aggregate wealth counts wallets, holdings, savings, reserves and both sides of futures PNL once; internal transfers cannot create wealth.
- Existing market/news, commodity/Forex units, listings, SOXL/SOXS, savings APR/redemption, Cross/partial-close, fees/funding, chunks, decimal precision and chart viewport tests still pass.
- 15 market/trading/savings/wallet/signing files match2.0.0 byte-for-byte. Their behavior was retained while the funding source was removed.

## Compiled instrumentation

Gameplay starts at$20,000 with no mining navigation, then transfers funds, opens and partially closes a trade and reloads Room. Repository coverage compiles an old-economy restart, no stale backup, command persistence and second-load continuity. Room migration/large-snapshot and savings/navigation/chart-dispatch tests also compile. These require an Android device or emulator to execute and are not counted among the100 JVM tests.

## Reproduce

```sh
./gradlew --no-daemon --max-workers=2 -Pksp.incremental=false :core:clean :app:clean :core:test :app:testDebugUnitTest :app:assembleDebug :app:lintDebug :app:assembleDebugAndroidTest
./gradlew :app:connectedDebugAndroidTest
```

Source includes build files, wrapper, fixed development key, schemas, tests, asset generator and README. No browser substitute was needed because the APK built successfully. Simulation and passive-checkpoint/replay limits are described in README. Prior release documents are archived in `docs/releases/2.0.0`.

APK SHA-256:`30698d341f2538479fa4ef434917b52f4cb0029343b2cd09610a3a9df811467a`
