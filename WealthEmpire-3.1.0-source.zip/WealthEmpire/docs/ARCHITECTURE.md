# Architecture decision — 3.0

Selected option B: retain the Android project and tested financial rules, rebuild world simulation, command ownership, persistence and navigation. The old broad lock/full-snapshot-on-action path is removed. Application identity and signing key are retained.

## Ownership and priorities

`GameRepository` owns mutable state on a single Default-dispatcher actor. Player actions enter a bounded priority channel; elapsed-time pulses are conflated. The actor drains commands before each bounded world quantum. A financial copy shares immutable candle values, avoiding chart-history copies for commands. World copies own mutable quote lists and world/ledger structures. Published/captured states are never modified in place.

Command sequence: validate and execute on a candidate → append checked journal row on IO → publish candidate → acknowledge. Failed journal writes do not publish a changed balance. Journal rows store executed ledger results, rather than rerunning a trade at a later price. A changed world frame accompanies commands when needed, without OHLC history. Periodic world frames include passive accrual; Earn must not force one complete frame for every accelerated tick.

Snapshots capture an immutable reference through the actor, then stream JSON into GZIP on IO. The snapshot mutex belongs to the checkpoint/reset path. A generation/revision check prevents old captures from overwriting a reset or a newer checkpoint. Room transactions preserve current and backup chunks; journal pruning retains replay coverage from the backup boundary.

## Determinism and event flow

World state holds separate macro and price RNG streams. The macro engine updates economic variables and business phases. Releases compare published actual values with forecasts; policy reacts to economic conditions. Company quarters, network events, commodity constraints and branching stories change saved fundamentals. Price estimates combine these values with a small correlated stochastic component and market microstructure. Bilingual news projects recorded events; it does not decide a random percentage move.

The same saved seed/state and simulation step sequence reproduce a scenario. Adaptive and fine-step paths intentionally consume different samples and are not guaranteed to produce identical prices. Historical pre-game candles are seeded synthetic history; future active candles use the simulated market marks.

## Absence

Wall elapsed time is retained as backlog at the saved time speed. Pause adds no simulated elapsed time. Adaptive quanta range from seconds to six hours, with shorter chunks while positions/orders are exposed. Scheduled events, funding, day/session changes and listings split quanta. Four sampled marks per chunk update markets; trigger crossings along a continuous sampled segment are processed before a later endpoint liquidation. Direct discontinuous-gap checks retain risk priority. Funding and Earn advance at the sampled timestamps. Bond coupons accrue by holding duration, not by buying immediately before a month boundary.

The return report uses cumulative execution counters and event occurrence times, not event scheduling IDs. Long absence reports retain major recent news, while bounded histories prevent unbounded save growth.

## Extensions and current limits

Add assets in the JSON catalog/generator; append model fields with serialization defaults and migrate Room/save schemas explicitly. New world engines should update state outside Compose and use saved RNG/event boundaries. Real estate, businesses, debt, options and multiplayer have not been added.

The macro model is a causal game model, not an empirical forecast. Four regional economies act as proxies for currencies outside those regions. Spreads, OI, funding and liquidation clusters are aggregate crowding estimates; there is no individual-agent order book. Spot and futures share a simulated mark/index price feed. Initial listings are bounded to 64 projects for this release. Rank requirements combine wealth, XP, risk health and completed challenges; a comprehensive audited multi-year return record remains a future extension. Charts and offline execution use sampled paths rather than reconstructed tick-by-tick history. See README for session/bond simplifications and VERIFICATION for device-test limits.
