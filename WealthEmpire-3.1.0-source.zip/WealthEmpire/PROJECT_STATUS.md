# Wealth Empire 3.0.0 — delivery baseline

The existing Android project is upgraded and builds to APK versionCode 7. All 131 JVM tests pass. Lint has no errors; Android instrumentation compiles but has not run on a device. Six-year seeded world runs and command-priority/streaming-save benchmarks are included in VERIFICATION.md and docs/.

Continue future updates from this source, keeping the application ID and dev signing key. Do not regenerate a new project. World/save schema 6, Room version 3. No mining or gambling. See README and docs/ARCHITECTURE.md for extension points and simulation/test limits.
