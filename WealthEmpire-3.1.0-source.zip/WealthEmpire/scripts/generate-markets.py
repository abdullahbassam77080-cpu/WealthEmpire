"""Edit this catalog and rerun to synchronize Kotlin defaults and the editable Android asset."""
from pathlib import Path
import json
root=Path(__file__).resolve().parent.parent
assets=[]
def add(symbol,name,ar,kind,price,vol,cap,risk,sector,unit='token',**extra):
 assets.append(dict(symbol=symbol,name=name,nameAr=ar,kind=kind,initialPrice=str(price),volatility=vol,marketCap=str(cap),risk=risk,sector=sector,unit=unit,**extra))
for s,n,a,p,v,c,r in [
 ('BTC','Bitcoin','بيتكوين',65000,.00065,1300000000000,1),('ETH','Ethereum','إيثريوم',3200,.00085,380000000000,2),
 ('SOL','Solana','سولانا',145,.00135,67000000000,3),('BNB','BNB','بينانس كوين',580,.0009,85000000000,2),
 ('XRP','XRP','ريبل',.62,.0012,34000000000,3),('DOGE','Dogecoin','دوجكوين',.15,.0019,22000000000,5),
 ('LTC','Litecoin','لايتكوين',82,.00105,6100000000,3),('ADA','Cardano','كاردانو',.45,.0014,16000000000,4),
 ('AVAX','Avalanche','أفالانش',35,.00165,14000000000,4),('LINK','Chainlink','تشين لينك',16,.0014,9700000000,4),
 ('SUI','Sui','سوي',2.1,.0017,6500000000,4),('TON','Toncoin','تون',5.2,.0015,13000000000,4),
 ('DOT','Polkadot','بولكادوت',6.4,.00135,9000000000,4),('UNI','Uniswap','يونيسواب',8.5,.00155,5000000000,4),
 ('NEAR','NEAR Protocol','نير',4.8,.0017,5000000000,4),('ATOM','Cosmos','كوزموس',7.2,.0014,2800000000,4)]:add(s,n,a,'CRYPTO',p,v,c,r,'crypto')
add('USDT','US Dollar Token','الدولار الرقمي','CRYPTO',1,.000001,100000000000,1,'stable',stable=True)
companies=[
 ('AAPL','Apple','أبل',190,.00055,2900000000000,2,'tech'),('MSFT','Microsoft','مايكروسوفت',420,.0005,3100000000000,1,'tech'),
 ('NVDA','NVIDIA','إنفيديا',120,.0011,2800000000000,4,'chips'),('TSLA','Tesla','تسلا',240,.0013,750000000000,4,'auto'),
 ('AMZN','Amazon','أمازون',180,.0007,1900000000000,2,'retail'),('GOOGL','Alphabet / Google','ألفابت / جوجل',170,.0006,2100000000000,2,'tech'),
 ('META','Meta Platforms','ميتا',500,.00085,1300000000000,3,'tech'),('AMD','Advanced Micro Devices','إيه إم دي',150,.0012,240000000000,4,'chips'),
 ('AVGO','Broadcom','برودكوم',160,.0009,750000000000,3,'chips'),('INTC','Intel','إنتل',30,.001,130000000000,4,'chips'),
 ('TSM','Taiwan Semiconductor','تي إس إم سي',160,.0008,800000000000,3,'chips'),('ORCL','Oracle','أوراكل',140,.00065,380000000000,2,'tech'),
 ('CRM','Salesforce','سيلزفورس',270,.00075,260000000000,3,'tech'),('NFLX','Netflix','نتفليكس',650,.0009,280000000000,3,'media'),
 ('JPM','JPMorgan Chase','جي بي مورغان',205,.00055,590000000000,2,'banks'),('BAC','Bank of America','بنك أمريكا',40,.00065,300000000000,3,'banks'),
 ('GS','Goldman Sachs','جولدمان ساكس',480,.0007,160000000000,3,'banks'),('V','Visa','فيزا',280,.0005,550000000000,2,'payments'),
 ('MA','Mastercard','ماستركارد',470,.00055,430000000000,2,'payments'),('WMT','Walmart','وولمارت',70,.0004,560000000000,1,'retail'),
 ('COST','Costco','كوستكو',870,.00055,390000000000,2,'retail'),('KO','Coca-Cola','كوكاكولا',68,.00035,290000000000,1,'consumer'),
 ('PEP','PepsiCo','بيبسيكو',175,.0004,240000000000,1,'consumer'),('XOM','Exxon Mobil','إكسون موبيل',115,.00065,490000000000,3,'energy'),
 ('CVX','Chevron','شيفرون',150,.00065,280000000000,3,'energy'),('LLY','Eli Lilly','إيلي ليلي',900,.0008,850000000000,3,'health'),
 ('JNJ','Johnson & Johnson','جونسون آند جونسون',160,.0004,380000000000,1,'health'),('PFE','Pfizer','فايزر',30,.00065,170000000000,3,'health'),
 ('BA','Boeing','بوينغ',170,.001,100000000000,4,'industrial'),('DIS','Walt Disney','ديزني',100,.0007,180000000000,3,'media'),
 ('SPY','S&P 500 ETF','صندوق إس آند بي 500',550,.0004,550000000000,2,'index'),('QQQ','Nasdaq 100 ETF','صندوق ناسداك 100',470,.0006,290000000000,3,'tech'),
 ('SOXX','Semiconductor ETF','صندوق أشباه الموصلات',230,.0009,15000000000,4,'chips')]
for s,n,a,p,v,c,r,se in companies:add(s,n,a,'STOCK',p,v,c,r,se,'share')
add('SOXL','Daily Semiconductor Bull 3X','أشباه الموصلات صعود 3×','STOCK',40,.0027,12000000000,5,'chips','share',referenceSymbol='SOXX',dailyLeverage=3)
add('SOXS','Daily Semiconductor Bear 3X','أشباه الموصلات هبوط 3×','STOCK',25,.0027,1000000000,5,'chips','share',referenceSymbol='SOXX',dailyLeverage=-3)
for s,n,a,p,v,c,r,se,u in [
 ('XAU','Gold','الذهب',2400,.00045,15000000000000,2,'metals','troy_ounce'),('XAG','Silver','الفضة',28,.0008,1500000000000,3,'metals','troy_ounce'),
 ('XPT','Platinum','البلاتين',950,.0007,200000000000,3,'metals','troy_ounce'),('WTI','WTI Crude Oil','نفط خام غرب تكساس',78,.001,2500000000000,4,'energy','barrel'),
 ('BRENT','Brent Crude Oil','نفط خام برنت',82,.00095,3000000000000,4,'energy','barrel'),('NATGAS','Natural Gas','الغاز الطبيعي',2.7,.0018,800000000000,5,'gas','mmbtu'),
 ('COPPER','Copper','النحاس',4.2,.00075,200000000000,3,'industrial','pound')]:add(s,n,a,'COMMODITY',p,v,c,r,se,u)
for s,n,a,p,v,c,r in [
 ('USD','US Dollar','الدولار الأمريكي',1,.000001,20000000000000,1),('EUR','Euro','اليورو',1.08,.00018,13000000000000,1),
 ('GBP','Pound Sterling','الجنيه الإسترليني',1.27,.00024,3000000000000,2),('JPY','Japanese Yen','الين الياباني',.0069,.00022,4000000000000,2),
 ('CNY','Chinese Yuan','اليوان الصيني',.139,.00011,17000000000000,1),('CHF','Swiss Franc','الفرنك السويسري',1.12,.00017,900000000000,1),
 ('AUD','Australian Dollar','الدولار الأسترالي',.66,.00025,1600000000000,2),('CAD','Canadian Dollar','الدولار الكندي',.74,.00022,2000000000000,2),
 ('NZD','New Zealand Dollar','الدولار النيوزيلندي',.61,.00027,250000000000,2)]:add(s,n,a,'FOREX',p,v,c,r,'forex','currency',stable=s=='USD')
# Old symbols remain valid for existing holdings/positions; UI hides unowned legacy stocks.
for s,n,p,v,c,r,se in [('APL','Atlas Devices',190,.00055,2900000000000,2,'tech'),('MST','Meridian Software',420,.0005,3100000000000,1,'tech'),('NVA','Nova Compute',120,.0011,2800000000000,4,'chips'),('TSR','Terra Motors',240,.0013,750000000000,4,'auto'),('AMZ','Amaze Commerce',180,.0007,1900000000000,2,'retail'),('GLX','Galaxy Search',170,.0006,2100000000000,2,'tech'),('MTA','MetaSphere',500,.00085,1300000000000,3,'tech')]:add(s,n,n,'STOCK',p,v,c,r,se,'share',legacy=True)
(root/'app/src/main/assets/markets.json').write_text(json.dumps(assets,ensure_ascii=False,indent=2)+'\n')
rows=[]
for a in assets:
 row=f'        AssetSpec({json.dumps(a["symbol"])}, {json.dumps(a["name"])}, AssetKind.{a["kind"]}, d("{a["initialPrice"]}"), {a["volatility"]}, d("{a["marketCap"]}"), {a["risk"]}, "{a["sector"]}", "{a["unit"]}", "{a["nameAr"]}", stable={str(a.get("stable",False)).lower()}, legacy={str(a.get("legacy",False)).lower()}'
 if 'referenceSymbol' in a:row+=f', referenceSymbol="{a["referenceSymbol"]}", dailyLeverage={a["dailyLeverage"]}'
 rows.append(row+')')
(root/'core/src/main/kotlin/com/wealthempire/core/market/AssetCatalog.kt').write_text('''package com.wealthempire.core.market
import com.wealthempire.core.models.*

/** Fictional seed values, not live quotations. Generated by scripts/generate-markets.py. */
object AssetCatalog {
    val defaults = listOf(
'''+',\n'.join(rows)+'''
    )
    val frames = listOf(1, 5, 15, 60, 240, 1440)
    val leverages = listOf(1, 2, 3, 5, 10, 20, 25, 50, 75, 100, 125, 200, 250, 500)
}
''')
print('Catalog:',len(assets),'assets')
