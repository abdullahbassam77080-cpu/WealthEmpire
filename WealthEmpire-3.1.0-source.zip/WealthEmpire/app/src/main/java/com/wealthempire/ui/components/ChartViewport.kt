package com.wealthempire.ui.components

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.*

/** A gesture chooses its owner once; a vertical swipe must never move the chart. */
internal enum class ChartDragOwner { WAITING, PAGE, CHART }
internal fun chartDragOwner(dx: Float, dy: Float, slop: Float): ChartDragOwner = when {
    max(abs(dx), abs(dy)) <= slop -> ChartDragOwner.WAITING
    abs(dy) >= abs(dx) -> ChartDragOwner.PAGE
    else -> ChartDragOwner.CHART
}

internal data class ChartRange(val start: Int, val end: Int) {
    val size get() = end - start
}

/** Time anchors survive appended candles and removal of the oldest history entries. */
internal data class ChartViewport(
    val candleCount: Double = 55.0,
    val rightEdgeTime: Long? = null,
    val panRemainder: Double = 0.0
) {
    fun range(times: List<Long>): ChartRange {
        if (times.isEmpty()) return ChartRange(0, 0)
        val count = candleCount.roundToInt().coerceIn(20, 120).coerceAtMost(times.size)
        val anchor = rightEdgeTime
        val end = if (anchor == null) times.size else {
            val found = times.binarySearch(anchor)
            (if (found >= 0) found + 1 else -found - 1).coerceIn(count, times.size)
        }
        return ChartRange((end - count).coerceAtLeast(0), end)
    }

    fun transform(times: List<Long>, panPixels: Float, plotWidth: Float,
                  zoom: Float = 1f, focus: Float = 1f): ChartViewport {
        if (times.isEmpty() || !plotWidth.isFinite() || plotWidth <= 0 ||
            !panPixels.isFinite() || !zoom.isFinite() || zoom <= 0) return this
        val old = range(times)
        val newCount = (candleCount / zoom).coerceIn(20.0, 120.0)
        val count = newCount.roundToInt().coerceAtMost(times.size)
        // Preserve the candle beneath the pinch centre rather than jumping to the right edge.
        val targetEnd = old.end + panRemainder +
            (1.0 - focus.coerceIn(0f, 1f)) * (count - old.size) -
            panPixels / plotWidth * count
        val edge = targetEnd.coerceIn(count.toDouble(), times.size.toDouble())
        if (edge >= times.size) return ChartViewport(newCount)
        val end = edge.roundToInt().coerceIn(count, times.size)
        return ChartViewport(newCount, times[end - 1], edge - end)
    }
}

internal fun chartPriceDecimals(reference: Double, tick: Double? = null): Int {
    val price = abs(reference)
    val base = when {
        price >= 100 -> 2
        price >= 1 -> 3
        price >= .01 -> 4
        price > 0 -> (-floor(log10(price)).toInt() + 4).coerceIn(4, 12)
        else -> 2
    }
    val tickDigits = if (tick != null && tick > 0 && tick.isFinite())
        ceil(-log10(tick)).toInt().coerceIn(0, 12) else 0
    return max(base, tickDigits)
}

internal fun chartPrice(value: Double, decimals: Int): String =
    NumberFormat.getNumberInstance(Locale.US).apply {
        minimumFractionDigits = decimals
        maximumFractionDigits = decimals
    }.format(value)

internal fun chartVolume(value: Double): String = when {
    abs(value) >= 1_000_000_000 -> String.format(Locale.US, "%.2fB", value / 1_000_000_000)
    abs(value) >= 1_000_000 -> String.format(Locale.US, "%.2fM", value / 1_000_000)
    abs(value) >= 1_000 -> String.format(Locale.US, "%.2fK", value / 1_000)
    else -> String.format(Locale.US, "%.2f", value)
}
