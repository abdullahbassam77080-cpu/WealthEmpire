package com.wealthempire.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.*
import com.wealthempire.core.market.GameClock
import com.wealthempire.ui.components.*
import com.wealthempire.ui.t
import com.wealthempire.ui.theme.*
import java.time.*
import java.time.format.DateTimeFormatter

@Composable fun ListingsScreen(s:GameState,navigate:(String)->Unit) {
    var upcoming by remember {mutableStateOf(true)}
    val formatter=remember {DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm 'UTC'").withZone(ZoneOffset.UTC)}
    val now=GameClock.visualTime(s,System.currentTimeMillis())
    val filtered=s.listings.filter { (it.status==ListingStatus.UPCOMING)==upcoming }
    val listings=if(upcoming)filtered.sortedBy {it.opensAt} else filtered.sortedByDescending {it.opensAt}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Text(t("new_listings"),style=MaterialTheme.typography.headlineSmall)
            Text(t("listing_note"),color=Muted,style=MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                FilterChip(upcoming,{upcoming=true},label={Text(t("upcoming"))})
                FilterChip(!upcoming,{upcoming=false},label={Text(t("listed"))},modifier=Modifier.testTag("listings_live"))
            }
        }
        if(listings.isEmpty())item {Text(t("no_listings"),color=Muted)}
        items(listings,key={it.id}) {listing ->
            SectionCard {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                    Column {Text(listing.spec.symbol,color=Gold,style=MaterialTheme.typography.titleLarge);Text(assetName(listing.spec))}
                    AssetBadge(listing.spec.symbol,AssetKind.CRYPTO)
                    Text(t("new_token"),color=Muted,style=MaterialTheme.typography.labelSmall)
                }
                InfoRow(t("opens_at"),formatter.format(Instant.ofEpochMilli(listing.opensAt)))
                if(upcoming) {
                    InfoRow(t("remaining_game_time"),durationLabel(listing.opensAt-now))
                    Text(t("initial_price_estimate")+" "+marketPrice(listing.spec.initialPrice),color=Muted,style=MaterialTheme.typography.bodySmall)
                } else {
                    val q=s.quote(listing.spec.symbol)
                    Metric(t("current"),marketPrice(q.price),large=true)
                    Button(onClick={navigate("trade/${listing.spec.symbol}")},modifier=Modifier.fillMaxWidth().testTag("trade_listing_${listing.spec.symbol}")) {Text(t("trade_now"))}
                }
                s.world.tokens[listing.spec.symbol]?.let {token->InfoRow(t("team_quality"),"${(token.team*100).toInt()}/100");InfoRow(t("token_supply"),qty(d(token.supply)));InfoRow(t("circulating_supply"),qty(d(token.circulating)));InfoRow(t("valuation"),money(d(token.circulating)*listing.spec.initialPrice));InfoRow(t("next_unlock"),formatter.format(Instant.ofEpochMilli(token.nextUnlock)));InfoRow(t("hype"),"${(token.hype*100).toInt()}/100")}
                if(!upcoming)MiniSparkline(s.quote(listing.spec.symbol).bars[5].orEmpty().takeLast(24).map {it.close.toDouble()})
                Text(t("new_listing_risk"),color=Down,style=MaterialTheme.typography.labelSmall)
            }
        }
    }
}
