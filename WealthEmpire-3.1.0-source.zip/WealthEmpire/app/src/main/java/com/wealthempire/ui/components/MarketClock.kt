package com.wealthempire.ui.components
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wealthempire.core.market.*
import com.wealthempire.core.models.GameState
import com.wealthempire.ui.t
import com.wealthempire.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.flow
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
fun marketDateLabel(time:Long,language:String):String=DateTimeFormatter
    .ofPattern("EEEE • yyyy-MM-dd",Locale.forLanguageTag(language)).withZone(ZoneOffset.UTC)
    .format(Instant.ofEpochMilli(time))
private val clockFormatter=DateTimeFormatter.ofPattern("HH:mm:ss 'UTC'",Locale.US).withZone(ZoneOffset.UTC)
@Composable private fun marketNow():Long {
    val ticker=remember {flow {while(true){emit(System.currentTimeMillis());delay(250)}}}
    val now by ticker.collectAsStateWithLifecycle(initialValue=System.currentTimeMillis())
    return now
}
fun durationLabel(ms:Long):String {
    if(ms==Long.MAX_VALUE)return "—"
    val sec=(ms.coerceAtLeast(0)+999)/1000
    return String.format(Locale.US,"%02d:%02d:%02d",sec/3600,(sec/60)%60,sec%60)
}
@Composable fun MarketClockBanner(s:GameState) {
    val virtual=GameClock.visualTime(s,marketNow());val open=MarketSessions.isOpen(s.marketTime)
    val next=MarketSessions.nextTransition(s.marketTime)
    val language=LocalConfiguration.current.locales[0].language
    Surface(color=Panel,modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal=16.dp,vertical=7.dp)) {
            InfoRow(t("game_day"),marketDateLabel(virtual,language))
            InfoRow(t("market_timer"),clockFormatter.format(Instant.ofEpochMilli(virtual)))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                Text(t(if(open)"open_market" else "closed_market"),color=if(open)Up else Gold,style=MaterialTheme.typography.labelSmall)
                Text(t(if(next.opens)"opens_in" else "closes_in")+" "+durationLabel(GameClock.realRemaining(next.time-virtual,s.marketSpeed))+" • ×${s.marketSpeed}",color=Muted,style=MaterialTheme.typography.labelSmall)
            }
        }
    }
}
@Composable fun CandleTimer(s:GameState,frame:Int,closed:Boolean) {
    val remaining=GameClock.candleRemaining(s,frame,marketNow())
    Column(verticalArrangement=Arrangement.spacedBy(2.dp)) {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(t(if(s.marketSpeed==1)"real_time" else "accelerated_market")+" • ×${s.marketSpeed}",color=Gold,style=MaterialTheme.typography.labelSmall)
            if(!closed)Text(durationLabel(remaining)+" "+t("sim_time"),color=Muted,style=MaterialTheme.typography.labelSmall)
        }
        if(closed)Text(t("candle_paused"),color=Muted,style=MaterialTheme.typography.bodySmall)
        else InfoRow(t("candle_timer_real"),durationLabel(GameClock.realRemaining(remaining,s.marketSpeed)))
    }
}
