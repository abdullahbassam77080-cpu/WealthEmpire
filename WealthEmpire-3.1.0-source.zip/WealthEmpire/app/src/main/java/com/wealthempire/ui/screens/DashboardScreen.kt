package com.wealthempire.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.*
import com.wealthempire.core.market.MarketEngine
import com.wealthempire.core.portfolio.PortfolioAnalytics
import com.wealthempire.core.progression.ProgressionEngine
import com.wealthempire.core.statistics.Wealth
import com.wealthempire.core.trading.FuturesMath
import com.wealthempire.ui.*
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*

@Composable fun DashboardScreen(s:GameState,catalog:List<AssetSpec>,navigate:(String)->Unit) {
    val market=MarketEngine(catalog)
    ScreenColumn {
        WealthHero(s)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("crypto","savings","listings").forEach {key->OutlinedButton(onClick={navigate(key)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(8.dp)){Text(t(key),style=MaterialTheme.typography.labelMedium)}}}
        SectionTitle(t("market_pulse"),t("economy")){navigate("economy")}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric(t("fear_index"),"%.1f".format(s.world.fear));Metric(t("global_liquidity"),"%.2f".format(s.world.globalLiquidity));Metric(t("economic_phase"),t("phase_"+(s.world.economies["USA"]?.phase?.name?.lowercase() ?: "expansion")))}
        SectionTitle(t("allocation"),t("wallet")){navigate("wallet")}
        AllocationDonut(PortfolioAnalytics.allocation(s,market))
        SectionTitle(t("watchlist"),t("markets")){navigate("crypto")}
        catalog.filter {it.symbol in s.favorites}.take(5).forEach {a->MarketRow(a,s,{navigate("trade/${a.symbol}")})}
        if(s.positions.isNotEmpty()) {
            SectionTitle(t("positions_short"))
            s.positions.take(3).forEach {p->val pnl=FuturesMath.pnl(p,s.quote(p.symbol).price);Surface(color=Elevated,shape=MaterialTheme.shapes.medium){Row(Modifier.fillMaxWidth().padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("${p.symbol} • ${p.leverage}×",color=if(p.side==Side.LONG)Up else Down);Text(money(pnl),color=if(pnl>=ZERO)Up else Down)}}}
        }
        s.news.firstOrNull()?.let {news->SectionTitle(t("major_news"),t("news_feed")){navigate("news")};Surface(color=Panel,shape=MaterialTheme.shapes.large){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text(t("breaking"),color=Gold,style=MaterialTheme.typography.labelSmall);Text(newsHeadline(news),style=MaterialTheme.typography.titleMedium)}}}
        SectionTitle(t("progress"),t("statistics")){navigate("progress")}
        Text(t(ProgressionEngine.rank(s,market)),color=Gold,style=MaterialTheme.typography.titleLarge)
        val next=Wealth.milestones.firstOrNull {Wealth.total(s)<d(it)}
        if(next!=null){InfoRow(t("next_milestone"),money(d(next)));LinearProgressIndicator(progress={Wealth.total(s).divD(d(next)).toFloat().coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth(),color=Gold)}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("XP ${s.xp}",color=Muted);Text(t("risk_health")+" ${PortfolioAnalytics.health(s,market)}/100",color=Up)}
    }
}
