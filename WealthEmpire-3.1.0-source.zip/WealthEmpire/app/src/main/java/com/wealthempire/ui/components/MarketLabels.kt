package com.wealthempire.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import com.wealthempire.core.models.*
import com.wealthempire.ui.t
import java.math.RoundingMode

@Composable fun assetName(a:AssetSpec)=if(LocalConfiguration.current.locales[0].language=="ar")a.nameAr else a.name
@Composable fun newsHeadline(n:News):String {
    val title=if(LocalConfiguration.current.locales[0].language=="ar")n.titleAr else n.titleEn
    return title.ifBlank {t(n.key)}
}
@Composable fun newsDetail(n:News)=if(LocalConfiguration.current.locales[0].language=="ar")n.detailAr else n.detailEn
@Composable fun newsSource(n:News)=if(LocalConfiguration.current.locales[0].language=="ar")n.sourceAr else n.sourceEn
fun tokenAmount(value:java.math.BigDecimal)=value.setScale(16,RoundingMode.HALF_EVEN).stripTrailingZeros().toPlainString()
@Composable fun unitLabel(a:AssetSpec)=t("unit_"+a.unit)

@Composable fun sectorLabel(key:String)=t("sector_"+key)
