package com.wealthempire.data

import com.wealthempire.core.models.GameState
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.encodeToStream
import kotlinx.serialization.json.decodeFromStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/** Compress the complete snapshot; SnapshotDao stores it in bounded CursorWindow-safe chunks. */
@OptIn(kotlinx.serialization.ExperimentalSerializationApi::class)
object SnapshotCodec {
    private val json=Json {encodeDefaults=true;ignoreUnknownKeys=true}
    fun encode(state:GameState):ByteArray {
        val output=ByteArrayOutputStream()
        GZIPOutputStream(output).use { json.encodeToStream(GameState.serializer(),state,it) }
        return output.toByteArray()
    }
    fun decode(payload:ByteArray):GameState = GZIPInputStream(ByteArrayInputStream(payload))
        .use { json.decodeFromStream(GameState.serializer(),it) }
    fun copy(state:GameState):GameState = com.wealthempire.core.models.GameStateCopy.copy(state)
}
