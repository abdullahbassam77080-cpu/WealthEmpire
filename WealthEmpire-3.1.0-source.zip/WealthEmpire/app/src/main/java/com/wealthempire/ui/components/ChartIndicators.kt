package com.wealthempire.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.*
import com.wealthempire.ui.theme.*
import java.util.Locale
import kotlin.math.abs

@Composable internal fun IndicatorChart(values: List<Double?>, label: String, color: Color, axisWidth: Dp,
    fixedMin: Double? = null, fixedMax: Double? = null, second: List<Double?> = emptyList(), histogram: List<Double?> = emptyList()) {
    Text("$label  ${values.lastOrNull()?.let { String.format(Locale.US, "%.2f", it) } ?: "—"}", color = color, style = MaterialTheme.typography.labelSmall)
    Canvas(Modifier.fillMaxWidth().height(56.dp)) {
        val valid = (values + second + histogram).filterNotNull()
        if (valid.isEmpty()) return@Canvas
        val min = fixedMin ?: minOf(valid.min(), 0.0)
        val max = fixedMax ?: maxOf(valid.max(), 0.0)
        val range = (max - min).coerceAtLeast(.000001)
        val w = (size.width - axisWidth.toPx()).coerceAtLeast(1f)
        val step = w / values.size.coerceAtLeast(1)
        fun y(v: Double) = size.height - ((v - min) / range * size.height).toFloat()
        drawLine(Muted.copy(alpha = .25f), Offset(0f, y(if (fixedMax == 100.0) 50.0 else 0.0)), Offset(w, y(if (fixedMax == 100.0) 50.0 else 0.0)), 1f)
        histogram.forEachIndexed { i, v -> if (v != null) {
            drawRect((if (v >= 0) Up else Down).copy(alpha = .4f), Offset((i + .18f) * step, minOf(y(0.0), y(v))), Size(step * .64f, abs(y(v) - y(0.0)).coerceAtLeast(1f)))
        } }
        fun line(items: List<Double?>, c: Color) {
            var previous: Offset? = null
            items.forEachIndexed { i, v -> if (v != null) {
                val point = Offset((i + .5f) * step, y(v))
                previous?.let { drawLine(c, it, point, 1.dp.toPx()) }; previous = point
            } else previous = null }
        }
        line(values, color); line(second, Gold)
    }
}
