package com.wealthempire.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import com.wealthempire.core.market.GameClock

private val Context.settingsStore by preferencesDataStore("settings")
data class Settings(val language: String = "ar", val haptics: Boolean = true, val reducedMotion: Boolean = false,
    val soundEnabled:Boolean=false, val marketSpeed:Int=1,val alertsEnabled:Boolean=true)
class SettingsStore(context: Context) {
    private val data=context.settingsStore
    private val language=stringPreferencesKey("language")
    private val haptics=booleanPreferencesKey("haptics")
    private val motion=booleanPreferencesKey("reduced_motion")
    private val speed=intPreferencesKey("market_speed")
    private val sound=booleanPreferencesKey("sound_enabled")
    private val alerts=booleanPreferencesKey("market_notices")
    val settings=data.data.map { Settings(it[language] ?: "ar", it[haptics] ?: true, it[motion] ?: false,
        it[sound] ?: false,it[speed]?.takeIf {value -> value in GameClock.speeds} ?: 1,it[alerts] ?: true) }
    suspend fun setLanguage(value: String) = data.edit { it[language]=value }
    suspend fun setHaptics(value: Boolean) = data.edit { it[haptics]=value }
    suspend fun setSound(value:Boolean)=data.edit {it[sound]=value}
    suspend fun setMotion(value: Boolean) = data.edit { it[motion]=value }
    suspend fun setSpeed(value:Int) {GameClock.requireSpeed(value);data.edit {it[speed]=value}}
    suspend fun setAlerts(value:Boolean)=data.edit {it[alerts]=value}
}
