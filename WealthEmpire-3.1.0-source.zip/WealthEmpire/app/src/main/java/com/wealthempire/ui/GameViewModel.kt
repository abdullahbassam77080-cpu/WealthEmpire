package com.wealthempire.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wealthempire.WealthApplication
import com.wealthempire.core.models.*
import com.wealthempire.core.savings.SavingsRules
import com.wealthempire.core.market.GameClock
import com.wealthempire.core.wallet.WalletRules
import com.wealthempire.data.Settings
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.math.BigDecimal

class GameViewModel(app: Application) : AndroidViewModel(app) {
    private val application=app as WealthApplication
    val repository=application.repository
    val state=repository.state
    val failure=repository.failure
    val settings=application.settings.settings.stateIn(viewModelScope,SharingStarted.Eagerly,Settings())
    val events=MutableSharedFlow<String>(extraBufferCapacity=16)
    private val _busy=MutableStateFlow(false)
    val busy=_busy.asStateFlow()
    private fun action(kind:String="PLAYER_COMMAND",block:(GameState)->Unit) {
        perform {repository.command(kind,block)}
    }
    private fun perform(block:suspend ()->Unit) {
        if(_busy.value) return
        _busy.value=true
        viewModelScope.launch {
            try {block(); events.emit("saved") }
            catch(e: Exception) { events.emit(e.message ?: "error") }
            finally { _busy.value=false }
        }
    }
    fun transfer(from: Wallet,to: Wallet,amount: BigDecimal)=action("TRANSFER") { WalletRules.transfer(it,from,to,amount) }
    fun subscribeSavings(symbol:String,quantity:BigDecimal,days:Int,compound:Boolean)=action {
        SavingsRules.subscribe(it,repository.engine.market,symbol,quantity,days,compound,GameClock.visualTime(it,System.currentTimeMillis()))
    }
    fun redeemSavings(id:Long,fraction:BigDecimal)=action {
        SavingsRules.redeem(it,repository.engine.market,id,fraction,GameClock.visualTime(it,System.currentTimeMillis()))
    }
    fun order(symbol:String,venue:OrderVenue,kind:OrderKind,side:Side,amount:BigDecimal,
        leverage:Int,mode:MarginMode,trigger:BigDecimal?,tp:BigDecimal?,sl:BigDecimal?)=action("ORDER_SUBMITTED") {
        repository.engine.trading.submit(it,symbol,venue,kind,side,amount,leverage,mode,trigger,tp,sl)
    }
    fun close(id:Long)=action("POSITION_CLOSED") { repository.engine.trading.close(it,id) }
    fun closeFraction(id:Long,fraction:BigDecimal)=action {repository.engine.trading.closeFraction(it,id,fraction)}
    fun dismissAlert(id:Long) {viewModelScope.launch {
        runCatching {repository.command {GameAlerts.dismiss(it,id)}}
    }}
    fun speed(value:Int)=perform {repository.setSpeed(value)}
    fun alerts(value:Boolean)=perform {repository.setAlerts(value)}
    fun cancel(id:Long)=action { repository.engine.trading.cancel(it,id) }
    fun brackets(id:Long,tp:BigDecimal?,sl:BigDecimal?)=action { repository.engine.trading.setBrackets(it,id,tp,sl) }
    fun reset(mode:com.wealthempire.core.world.GameMode=com.wealthempire.core.world.GameMode.PURE_INVESTOR) {
        if(_busy.value) return
        _busy.value=true
        viewModelScope.launch {
            try { repository.reset(mode); events.emit("new_game") }
            catch(e:Exception) { events.emit("storage_error") }
            finally { _busy.value=false }
        }
    }
    fun favorite(symbol:String)=action("FAVORITE_CHANGED"){if(symbol in it.favorites)it.favorites.remove(symbol) else it.favorites.add(symbol)}
    fun research(key:String)=action("RESEARCH"){com.wealthempire.core.progression.ProgressionEngine.research(it,key)}
    fun specialize(key:String)=action("SPECIALTY"){com.wealthempire.core.progression.ProgressionEngine.specialize(it,key)}
    fun skip()=action("SKIP_EVENT"){repository.engine.skip(it)}
    fun dismissAway()=action("AWAY_DISMISSED"){it.awayReport=null}
    fun language(value:String) { viewModelScope.launch { application.settings.setLanguage(value) } }
    fun haptics(value:Boolean) { viewModelScope.launch { application.settings.setHaptics(value) } }
    fun sound(value:Boolean){viewModelScope.launch {application.settings.setSound(value)}}
    fun motion(value:Boolean) { viewModelScope.launch { application.settings.setMotion(value) } }
}
