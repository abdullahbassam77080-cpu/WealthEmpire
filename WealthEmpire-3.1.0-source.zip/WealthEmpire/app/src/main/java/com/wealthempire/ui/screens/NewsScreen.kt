package com.wealthempire.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.GameState
import com.wealthempire.ui.t
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*
import java.time.*
import java.time.format.DateTimeFormatter
import kotlin.math.abs

@Composable fun NewsScreen(s:GameState) {
    val formatter=remember {DateTimeFormatter.ofPattern("MM-dd HH:mm 'UTC'").withZone(ZoneOffset.UTC)}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {Text(t("news_feed"),style=MaterialTheme.typography.titleLarge)}
        items(s.news,key={it.id}) {news ->
            var expanded by remember(news.id) {mutableStateOf(false)}
            SectionCard {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                    Text(if(abs(news.impact)>=.65)t("breaking") else newsSource(news).ifBlank {t("simulation_news")},color=Gold,style=MaterialTheme.typography.labelSmall)
                    if(s.quotes.any {it.symbol==news.target})Text(news.target,color=Muted,style=MaterialTheme.typography.labelSmall)
                }
                val importance=t(when {abs(news.impact)>=.65->"impact_high";abs(news.impact)>=.3->"impact_medium";else->"impact_low"})
                Text(t("impact")+" • "+importance,color=if(abs(news.impact)>=.65)Down else ChartBlue,style=MaterialTheme.typography.labelSmall)
                val affected=when {s.quotes.any {it.symbol==news.target}->listOf(news.target);news.key.startsWith("GEOPOLITICS")->listOf("WTI","NATGAS","XAU");news.key.startsWith("SECURITY")->listOf(news.target,"BTC");news.key=="WEATHER"->listOf("NATGAS");news.key=="AI"->listOf("NVDA","AMD","AVGO");else->listOf("BTC","NVDA","EUR","US2Y","XAU")}
                Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){affected.take(5).forEach {symbol->Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(4.dp)){AssetBadge(symbol,size=24);Text(symbol,color=Muted,style=MaterialTheme.typography.labelSmall)}}}
                Text(newsHeadline(news),style=MaterialTheme.typography.titleMedium)
                Text(formatter.format(Instant.ofEpochMilli(news.time)),color=Muted,style=MaterialTheme.typography.labelSmall)
                val detail=newsDetail(news)
                if(detail.isNotBlank()) {
                    if(expanded)Text(detail,color=Muted,style=MaterialTheme.typography.bodySmall)
                    TextButton(onClick={expanded=!expanded}) {Text(t(if(expanded)"less" else "news_details"))}
                }
            }
        }
    }
}
