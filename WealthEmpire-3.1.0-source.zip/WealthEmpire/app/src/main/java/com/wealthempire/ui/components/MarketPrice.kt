package com.wealthempire.ui.components

import java.math.BigDecimal
import java.text.NumberFormat
import java.util.Locale

/** Inventory prices need more decimals than dollar-valued wallet balances, especially FX. */
fun marketPrice(value:BigDecimal):String {
    val decimals=when {value.abs()>=BigDecimal(100)->2;value.abs()>=BigDecimal.ONE->4;else->8}
    return "$"+NumberFormat.getNumberInstance(Locale.US).apply {
        minimumFractionDigits=decimals;maximumFractionDigits=decimals
        roundingMode=java.math.RoundingMode.HALF_EVEN
    }.format(value)
}
