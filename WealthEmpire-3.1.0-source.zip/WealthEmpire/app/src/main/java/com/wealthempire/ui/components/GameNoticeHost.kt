package com.wealthempire.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.*
import com.wealthempire.ui.*
import com.wealthempire.ui.theme.*
import kotlinx.coroutines.delay

/** A non-modal notice: it never blocks the rest of the screen and closes itself. */
@Composable fun GameNoticeHost(s:GameState,vm:GameViewModel,reducedMotion:Boolean,modifier:Modifier=Modifier) {
    val alert=s.alerts.lastOrNull()?.takeIf {s.alertsEnabled} ?: return
    var visible by remember(alert.id) {mutableStateOf(false)}
    var dismissed by remember(alert.id) {mutableStateOf(false)}
    LaunchedEffect(alert.id,dismissed) {
        if(dismissed) {visible=false;delay(if(reducedMotion)0 else 220);vm.dismissAlert(alert.id)}
        else {visible=true;delay(4000);dismissed=true}
    }
    AnimatedVisibility(visible,modifier=modifier,
        enter=if(reducedMotion)fadeIn(tween(0)) else slideInVertically(tween(260)) {-it}+fadeIn(tween(220)),
        exit=if(reducedMotion)fadeOut(tween(0)) else slideOutVertically(tween(220)) {-it}+fadeOut(tween(180))) {
        Surface(color=Panel,shape=RoundedCornerShape(16.dp),shadowElevation=8.dp,
            tonalElevation=4.dp,modifier=Modifier.fillMaxWidth().testTag("game_notice")) {
            Row(Modifier.padding(start=12.dp,top=8.dp,bottom=8.dp)) {
                Icon(Icons.Default.NotificationsNone,contentDescription=null,tint=Gold,modifier=Modifier.padding(top=4.dp))
                Column(Modifier.weight(1f).padding(horizontal=10.dp),verticalArrangement=Arrangement.spacedBy(3.dp)) {
                    Text(t(when(alert.type){AlertType.NEWS->"breaking";AlertType.MARKET_OPEN->"open_market";AlertType.MARKET_CLOSED->"closed_market"}),
                        style=MaterialTheme.typography.labelMedium,color=Gold)
                    val article=s.news.firstOrNull {it.id==alert.id}
                    Text(if(article!=null)newsHeadline(article) else t(alert.key),style=MaterialTheme.typography.bodySmall,maxLines=2)
                }
                IconButton(onClick={dismissed=true},modifier=Modifier.size(40.dp).testTag("dismiss_notice")) {
                    Icon(Icons.Default.Close,contentDescription=t("dismiss_notice"),tint=Muted)
                }
            }
        }
    }
}
