package com.wealthempire.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.*
import com.wealthempire.core.market.AssetCatalog
import com.wealthempire.core.trading.FuturesMath
import com.wealthempire.core.trading.LiquidationRange
import com.wealthempire.core.market.PriceEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.wealthempire.ui.*
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun TradingTicket(s:GameState,vm:GameViewModel,busy:Boolean,symbol:String,venue:OrderVenue,stockOpen:Boolean) {
    var side by rememberSaveable(venue) { mutableStateOf(Side.LONG) }
    var kind by rememberSaveable { mutableStateOf(OrderKind.MARKET) }
    var mode by rememberSaveable { mutableStateOf(MarginMode.ISOLATED) }
    var leverage by rememberSaveable { mutableIntStateOf(5) }
    var amount by rememberSaveable(venue,side) { mutableStateOf(if(venue==OrderVenue.FUTURES || side==Side.LONG)"100" else "0.1") }
    var trigger by rememberSaveable(symbol) { mutableStateOf("") }
    var tp by rememberSaveable(symbol) { mutableStateOf("") }
    var sl by rememberSaveable(symbol) { mutableStateOf("") }
    var showBrackets by rememberSaveable {mutableStateOf(false)}
    var help by remember {mutableStateOf(false)}
    val futures=venue==OrderVenue.FUTURES
    val mark=s.quote(symbol).price
    val targetPrice=parsed(trigger)
    val crosses=kind==OrderKind.MARKET || (targetPrice!=null && when(kind){OrderKind.LIMIT->if(side==Side.LONG)mark<=targetPrice else mark>=targetPrice;OrderKind.STOP_MARKET->if(side==Side.LONG)mark>=targetPrice else mark<=targetPrice;else->true})
    val feeRate=if(kind==OrderKind.LIMIT && !crosses)FuturesMath.MAKER else FuturesMath.TAKER
    val estimate by produceState<LiquidationRange?>(null,s.positions,s.futuresCash,s.quotes.map {it.price},listOf(amount,side,mode,leverage,kind,trigger,symbol,venue)) {
        value=if(!futures)null else withContext(Dispatchers.Default) {runCatching {
            val margin=parsed(amount) ?: return@runCatching null
            val nominal=margin*d(leverage);val fee=nominal*feeRate
            if(margin<ONE || s.futuresCash<margin+fee)return@runCatching null
            val base=if(kind==OrderKind.MARKET)mark else targetPrice ?: return@runCatching null
            val slip=if(kind==OrderKind.LIMIT)ZERO else d(PriceEngine.slippage(s,symbol,nominal.toDouble()))
            val entry=base*(if(side==Side.LONG)ONE+slip else ONE-slip)
            val candidate=GameStateCopy.copy(s,false);candidate.futuresCash-=margin+fee
            val p=Position(-1,symbol,side,mode,leverage,entry,nominal.divD(entry),margin,margin,openedAt=s.marketTime)
            candidate.positions.add(p)
            val index=candidate.quotes.indexOfFirst {it.symbol==symbol};candidate.quotes[index]=candidate.quotes[index].copy(price=entry)
            FuturesMath.liquidationRange(candidate,p)
        }.getOrNull()}
    }
    val wallet=when(venue) {OrderVenue.FUTURES->Wallet.FUTURES;OrderVenue.SPOT->Wallet.SPOT;OrderVenue.STOCK->Wallet.STOCKS}
    SectionCard(t("submit_order")) {
        Metric(t("free_balance"),money(s.balance(wallet).positive()))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            FilterChip(selected=side==Side.LONG,onClick={side=Side.LONG},label={Text(t(if(futures)"long" else "buy"),color=Up)},modifier=Modifier.weight(1f))
            FilterChip(selected=side==Side.SHORT,onClick={side=Side.SHORT},label={Text(t(if(futures)"short" else "sell"),color=Down)},modifier=Modifier.weight(1f))
        }
        Choice(t("open_orders"),OrderKind.entries.toList(),kind,{kind=it}) {
            t(when(it){OrderKind.MARKET->"market";OrderKind.LIMIT->"limit";OrderKind.STOP_MARKET->"stop_market"})
        }
        if(futures) {
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) {Choice(t("leverage"),AssetCatalog.leverages,leverage,{leverage=it}) { "$it×" }}
                Box(Modifier.weight(1f)) {Choice(t("margin_mode"),MarginMode.entries.toList(),mode,{mode=it}) {t(if(it==MarginMode.ISOLATED)"isolated" else "cross")}}
            }
        }
        MoneyInput(t(if(futures)"margin_input" else if(side==Side.LONG)"buy_budget" else "sell_quantity"),amount,{amount=it})
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf(25,50,75,100).forEach {fraction->TextButton(onClick={
            val available=if(!futures && side==Side.SHORT)(s.holdings.firstOrNull {it.symbol==symbol}?.quantity ?: ZERO)-s.orders.filter {it.symbol==symbol && it.side==Side.SHORT}.fold(ZERO){a,o->a+o.amount} else s.balance(wallet).positive().divD(ONE+d(if(futures)leverage else 1)*FuturesMath.TAKER)
            amount=(available*d(fraction).divD(d(100))).setScale(if(!futures && side==Side.SHORT)8 else 2,java.math.RoundingMode.DOWN).toPlainString()
        },modifier=Modifier.weight(1f),contentPadding=PaddingValues(0.dp)){Text(if(fraction==100)"MAX" else "$fraction%")}}}
        if(futures){Slider(value=AssetCatalog.leverages.indexOf(leverage).toFloat(),onValueChange={leverage=AssetCatalog.leverages[it.toInt().coerceIn(0,AssetCatalog.leverages.lastIndex)]},valueRange=0f..AssetCatalog.leverages.lastIndex.toFloat(),steps=AssetCatalog.leverages.size-2)}
        if(!futures && side==Side.SHORT) {
            val held=s.holdings.firstOrNull { it.symbol==symbol }
            if(held!=null) TextButton(onClick={amount=held.quantity.stripTrailingZeros().toPlainString()}) { Text("MAX • ${qty(held.quantity)}") }
        }
        if(kind!=OrderKind.MARKET) MoneyInput(t("trigger_price"),trigger,{trigger=it})
        if(futures) {
            FilterChip(selected=showBrackets,onClick={showBrackets=!showBrackets},label={Text("TP / SL")})
            if(showBrackets)Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                MoneyInput(t("tp_optional"),tp,{tp=it},Modifier.weight(1f))
                MoneyInput(t("sl_optional"),sl,{sl=it},Modifier.weight(1f))
            }
            val nominal=(parsed(amount) ?: ZERO)*d(leverage)
            InfoRow(t("estimated_notional"),money(nominal))
            InfoRow(t("liquidation_price"),compactLiquidation(estimate))
            InfoRow(t("entry_fee"),money(nominal*feeRate))
        }
        Button(onClick={
            val a=parsed(amount);val price=if(kind==OrderKind.MARKET)null else parsed(trigger)
            val target=if(tp.isBlank())null else parsed(tp); val stop=if(sl.isBlank())null else parsed(sl)
            when {
                a==null -> vm.events.tryEmit("invalid_amount")
                kind!=OrderKind.MARKET && price==null -> vm.events.tryEmit("invalid_price")
                futures && showBrackets && tp.isNotBlank() && target==null -> vm.events.tryEmit("invalid_tp")
                futures && showBrackets && sl.isNotBlank() && stop==null -> vm.events.tryEmit("invalid_sl")
                else -> vm.order(symbol,venue,kind,side,a,if(futures)leverage else 1,mode,price,if(futures && showBrackets)target else null,if(futures && showBrackets)stop else null)
            }
        },enabled=!busy && stockOpen,modifier=Modifier.fillMaxWidth().testTag("submit_order"),
            colors=ButtonDefaults.buttonColors(containerColor=if(side==Side.LONG)Up else Down)) { Text(t(if(futures)if(side==Side.LONG)"open_long" else "open_short" else if(side==Side.LONG)"buy" else "sell")) }
        Text(t("maker_fee")+" • "+t("taker_fee"),color=Muted,style=MaterialTheme.typography.labelSmall)
        if(futures)TextButton(onClick={help=true}) {Text(t("trading_details"),style=MaterialTheme.typography.labelSmall)}
    }
    if(help)ModalBottomSheet(onDismissRequest={help=false},containerColor=Panel) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Text(t("trading_details"),style=MaterialTheme.typography.titleMedium)
            Text(t("margin_new_order_note"));Text(t(if(mode==MarginMode.CROSS)"cross_note" else "isolated_note"))
            Text(t("funding_note"));Text(t("cross_estimate_note"));Text(t("offline_replay_note"))
            Spacer(Modifier.height(16.dp))
        }
    }
}
