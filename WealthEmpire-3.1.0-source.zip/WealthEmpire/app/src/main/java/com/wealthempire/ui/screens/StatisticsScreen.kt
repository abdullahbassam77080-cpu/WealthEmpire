package com.wealthempire.ui.screens

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import com.wealthempire.core.models.*
import com.wealthempire.core.statistics.Wealth
import com.wealthempire.ui.t
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*

@Composable fun StatisticsScreen(s:GameState) {
    val st=s.stats
    ScreenColumn {
        SectionCard(t("statistics")) {
            Metric(t("net_worth"),money(Wealth.total(s)),large=true)
            WealthSparkline(s.wealthHistory)
            InfoRow(t("total_profit"),money(Wealth.total(s)-s.initialCapital))
            InfoRow(t("trading_profit"),money(st.futures))
            InfoRow(t("spot_profit"),money(st.spot));InfoRow(t("stock_profit"),money(st.stocks))
            InfoRow(t("savings_profit"),money(st.savings));InfoRow(t("total_fees"),money(st.fees))
            InfoRow(t("funding_pnl"),money(st.funding))
        }
        SectionCard {
            InfoRow(t("best_trade"),money(st.bestTrade));InfoRow(t("worst_trade"),money(st.worstTrade))
            InfoRow(t("total_trades"),"${st.trades}")
            InfoRow(t("win_rate"),percent(if(st.trades>0)d(st.wins).divD(d(st.trades))*d(100) else ZERO))
            InfoRow(t("largest_liquidation"),money(st.largestLiquidation))
            InfoRow(t("highest_wealth"),money(st.highestWealth))
            InfoRow(t("time_played"),"${st.timePlayedMs/3600000}h ${(st.timePlayedMs/60000)%60}m")
        }
        SectionCard(t("achievements")) {
            Wealth.milestones.forEach { threshold ->
                Text((if(threshold in s.achievements)"✓ " else "○ ")+money(d(threshold)),color=if(threshold in s.achievements)Gold else Muted)
                LinearProgressIndicator(progress={Wealth.total(s).divD(d(threshold)).toFloat().coerceIn(0f,1f)})
            }
        }
    }
}
