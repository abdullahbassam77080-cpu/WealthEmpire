package com.wealthempire.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wealthempire.core.models.*
import com.wealthempire.ui.*
import com.wealthempire.ui.theme.*

@Composable fun AssetBadge(symbol:String,kind:AssetKind?=null,size:Int=40) {
    val color=when {symbol=="BTC"->Gold;symbol=="ETH"->Violet;symbol in listOf("XAU","XAG","XPT")->Gold;kind==AssetKind.FOREX->ChartBlue;kind==AssetKind.STOCK->ChartBlue;kind==AssetKind.BOND->Up;else->Violet}
    val glyph=when(symbol){"BTC"->"₿";"ETH"->"Ξ";"SOL"->"≋";"XAU"->"◆";"WTI","BRENT"->"◈";"NATGAS"->"♨";"USD","USDT"->"$";"EUR"->"€";"JPY","CNY"->"¥";"GBP"->"£";else->symbol.take(2)}
    Box(Modifier.size(size.dp).background(Brush.linearGradient(listOf(color.copy(alpha=.26f),color.copy(alpha=.07f))),CircleShape),contentAlignment=Alignment.Center){Text(glyph,color=color,fontWeight=FontWeight.Bold,fontSize=if(glyph.length==1)22.sp else 13.sp)}
}
@Composable fun MiniSparkline(values:List<Double>,modifier:Modifier=Modifier,positive:Boolean=true) {
    val color=if(positive)Up else Down
    Canvas(modifier.width(62.dp).height(28.dp)) {
        if(values.size<2)return@Canvas
        val lo=values.minOrNull()!!;val span=(values.maxOrNull()!!-lo).coerceAtLeast(1e-9)
        val path=Path();values.forEachIndexed {i,v->val x=size.width*i/(values.size-1);val y=size.height*(1-(v-lo)/span).toFloat();if(i==0)path.moveTo(x,y)else path.lineTo(x,y)}
        drawPath(path,color,style=Stroke(1.6.dp.toPx(),cap=StrokeCap.Round))
    }
}
@Composable fun MarketRow(a:AssetSpec,s:GameState,onClick:()->Unit,onFavorite:(()->Unit)?=null) {
    val q=s.quote(a.symbol);val change=(q.price-q.dayOpen).divD(q.dayOpen)*d(100)
    Row(Modifier.fillMaxWidth().clickable(onClick=onClick).padding(vertical=12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        AssetBadge(a.symbol,a.kind)
        Column(Modifier.weight(1f)){Text(a.symbol,fontWeight=FontWeight.SemiBold);Text(assetName(a),color=Muted,style=MaterialTheme.typography.labelSmall,maxLines=1)}
        MiniSparkline(q.bars[5].orEmpty().takeLast(24).map {it.close.toDouble()},positive=change>=ZERO)
        Column(horizontalAlignment=Alignment.End){Text(marketPrice(q.price),style=MaterialTheme.typography.titleSmall);Text(percent(change),color=if(change>=ZERO)Up else Down,style=MaterialTheme.typography.labelSmall)}
        if(onFavorite!=null)TextButton(onClick=onFavorite,contentPadding=PaddingValues(0.dp),modifier=Modifier.width(28.dp)){Text(if(a.symbol in s.favorites)"★" else "☆",color=Gold)}
    }
}
@Composable fun WealthHero(s:GameState,title:String=t("financial_total")) {
    val worth=com.wealthempire.core.statistics.Wealth.total(s);val start=s.stats.financialDayStart ?: worth;val today=worth-start
    Surface(shape=RoundedCornerShape(24.dp),color=Panel) {
        Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(ChartBlue.copy(alpha=.16f),Panel,Up.copy(alpha=.05f)))).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(title,color=Muted,style=MaterialTheme.typography.labelMedium);Text("LV ${s.level}",color=Gold,style=MaterialTheme.typography.labelMedium)}
            Text(money(worth),fontWeight=FontWeight.Bold,style=MaterialTheme.typography.displaySmall)
            Text(money(today)+"  •  "+percent(if(start>ZERO)today.divD(start)*d(100) else ZERO),color=if(today>=ZERO)Up else Down)
            WealthSparkline(s.financialHistory)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric(t("wallet_cash_total"),money(com.wealthempire.core.statistics.Wealth.availableCash(s)));Metric(t("invested"),money(com.wealthempire.core.statistics.Wealth.financialInvested(s)))}
        }
    }
}
@Composable fun AllocationDonut(values:Map<String,Double>) {
    val colors=listOf(ChartBlue,Up,Gold,Violet,Down,Muted)
    val entries=values.entries.toList();val total=entries.sumOf {it.value}.coerceAtLeast(1.0)
    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(24.dp)) {
        Canvas(Modifier.size(112.dp)) {var start=-90f;entries.forEachIndexed {i,e->val sweep=(e.value/total*360).toFloat();drawArc(colors[i%colors.size],start,sweep-2,false,topLeft=Offset(8f,8f),size=Size(size.width-16,size.height-16),style=Stroke(14.dp.toPx()));start+=sweep}}
        Column(verticalArrangement=Arrangement.spacedBy(6.dp)){entries.forEachIndexed {i,e->Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Text("●",color=colors[i%colors.size]);Text(t(when(e.key){"CRYPTO"->"crypto_market";"STOCK"->"stocks";"FOREX"->"forex";"COMMODITY"->"commodities";"BOND"->"bonds";"cash"->"cash_wallet";else->e.key}),style=MaterialTheme.typography.labelSmall);Text("${(e.value/total*100).toInt()}%",color=Muted,style=MaterialTheme.typography.labelSmall)}}}
    }
}
@Composable fun SectionTitle(title:String,action:String?=null,onAction:(()->Unit)?=null) {
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text(title,fontWeight=FontWeight.SemiBold,style=MaterialTheme.typography.titleMedium);if(action!=null && onAction!=null)TextButton(onClick=onAction){Text(action,style=MaterialTheme.typography.labelSmall)}}
}
