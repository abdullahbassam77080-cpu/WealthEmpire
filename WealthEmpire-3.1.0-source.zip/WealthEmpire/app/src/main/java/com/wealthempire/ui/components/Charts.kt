package com.wealthempire.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.WealthPoint
import com.wealthempire.ui.theme.Up

@Composable fun WealthSparkline(points:List<WealthPoint>) {
    Canvas(Modifier.fillMaxWidth().height(100.dp)) {
        if(points.size<2) { drawLine(Up,Offset(0f,size.height/2),Offset(size.width,size.height/2),2.dp.toPx()); return@Canvas }
        val values=points.map { it.value.toFloat() }; val min=values.min(); val range=(values.max()-min).coerceAtLeast(1f)
        val path=Path()
        values.forEachIndexed { i,v -> val x=i.toFloat()/(values.size-1)*size.width; val y=size.height-(v-min)/range*(size.height-12)-6
            if(i==0) path.moveTo(x,y) else path.lineTo(x,y) }
        val fill=Path().apply { addPath(path); lineTo(size.width,size.height); lineTo(0f,size.height);close() }
        drawPath(fill,Brush.verticalGradient(listOf(Up.copy(alpha=.20f),Color.Transparent)))
        drawPath(path,Up,style=androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
    }
}
