package com.wealthempire.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.*
import com.wealthempire.core.trading.FuturesMath
import com.wealthempire.ui.*
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*
@Composable fun PartialCloseDialog(s:GameState,p:Position,vm:GameViewModel,busy:Boolean,onDismiss:()->Unit) {
    var percentage by remember(p.id){mutableIntStateOf(25)}
    val fraction=d(percentage).divD(d(100));val quantity=p.quantity*fraction
    val mark=s.quote(p.symbol).price;val fee=quantity*mark*FuturesMath.TAKER
    val pnl=FuturesMath.pnl(p,mark)*fraction+(p.margin-p.originalMargin)*fraction-p.openFee*fraction-fee
    AlertDialog(onDismissRequest=onDismiss,title={Text(t("partial_close"))},text={
        Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Text("${p.symbol}/USDT • "+t(if(p.side==Side.LONG)"long" else "short"))
            Choice(t("close_percentage"),listOf(10,25,50,75,100),percentage,{percentage=it}){"$it%"}
            InfoRow(t("close_quantity"),qty(quantity));InfoRow(t("remaining_quantity"),qty(p.quantity-quantity))
            InfoRow(t("exit_fee"),money(fee));Metric(t("estimated_realized_pnl"),money(pnl),pnl>=ZERO)
        }
    },confirmButton={TextButton(onClick={vm.closeFraction(p.id,fraction);onDismiss()},enabled=!busy,modifier=Modifier.testTag("confirm_partial_close")){Text(t("close_position")+" $percentage%")}},
        dismissButton={TextButton(onClick=onDismiss){Text(t("cancel"))}})
}
