package com.wealthempire.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.*
import com.wealthempire.core.market.*
import com.wealthempire.ui.*
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class,ExperimentalLayoutApi::class)
@Composable fun MarketScreen(s:GameState,vm:GameViewModel,busy:Boolean,stocks:Boolean=false,initialSymbol:String?=null) {
    val market=vm.repository.engine.market
    val available=market.visibleAssets(s).filter {it.symbol!="USDT"}
    val initial=available.firstOrNull {it.symbol==initialSymbol}
    var category by rememberSaveable(stocks,initialSymbol) {mutableStateOf(initial?.kind ?: if(stocks)AssetKind.STOCK else AssetKind.CRYPTO)}
    val catalog=available.filter {it.kind==category}
    var symbol by rememberSaveable(stocks,initialSymbol) { mutableStateOf(initial?.symbol ?: catalog.first().symbol) }
    var frame by rememberSaveable { mutableIntStateOf(1) }
    var future by rememberSaveable(initialSymbol) { mutableStateOf(initialSymbol==null && !stocks) }
    var enabled by remember { mutableStateOf(setOf("EMA20","Volume")) }
    var showIndicators by remember { mutableStateOf(false) }
    var tab by rememberSaveable {mutableIntStateOf(0)}
    val positionsAnchor=remember {BringIntoViewRequester()}
    val scope=rememberCoroutineScope()
    val spec=catalog.firstOrNull {it.symbol==symbol} ?: catalog.first()
    val activeSymbol=spec.symbol;val quote=s.quote(activeSymbol)
    val listingRestricted=s.listings.any {it.spec.symbol==activeSymbol && s.marketTime<it.opensAt+NewsEngine.DAY}
    val venue=if(future && !listingRestricted && !spec.stable)OrderVenue.FUTURES else if(category==AssetKind.STOCK)OrderVenue.STOCK else OrderVenue.SPOT
    val stockOpen=market.isOpen(spec,s.marketTime)
    ScreenColumn(Modifier.testTag("market_scroll")) {
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            listOf(AssetKind.CRYPTO to "crypto_market",AssetKind.COMMODITY to "commodities",AssetKind.FOREX to "forex",AssetKind.STOCK to "stocks",AssetKind.BOND to "bonds").forEach {(kind,label)->
                FilterChip(selected=category==kind,onClick={category=kind;symbol=available.first {it.kind==kind}.symbol;future=kind==AssetKind.CRYPTO},label={Text(t(label))},modifier=Modifier.testTag("category_${kind.name}"))
            }
        }
        if(!listingRestricted && !spec.stable) {
            TabRow(selectedTabIndex=if(future)0 else 1) {
                Tab(selected=future,onClick={future=true},text={Text(t("futures"))})
                Tab(selected=!future,onClick={future=false},text={Text(t("spot"))})
            }
        }
        ScrollableTabRow(tab,edgePadding=0.dp){listOf("chart","trade","positions","open_orders","asset_info").forEachIndexed {i,key->Tab(tab==i,{tab=i},text={Text(t(key))})}}
        SectionCard {
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){AssetBadge(spec.symbol,spec.kind);Text(spec.symbol,style=MaterialTheme.typography.titleLarge)}
            AssetPicker(catalog,spec,s) {symbol=it}
            val change=(quote.price-quote.dayOpen).divD(quote.dayOpen)*d(100)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                Metric(assetName(spec),marketPrice(quote.price),large=true)
                Metric(t("daily_change"),percent(change),change>=ZERO)
            }
            Text("USD / "+unitLabel(spec)+" • "+t(if(stockOpen)"open_market" else "closed_market"),color=if(stockOpen)Muted else Gold,style=MaterialTheme.typography.labelSmall)
            if(category==AssetKind.FOREX && !spec.stable)InfoRow("1 USD",qty(ONE.divD(quote.price))+" ${spec.symbol}")
            if(listingRestricted)Text(t("listing_spot_only"),color=Gold,style=MaterialTheme.typography.labelSmall)
        }
        if(tab==0)SectionCard {
            Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                AssetCatalog.frames.forEach { f -> FilterChip(selected=frame==f,onClick={frame=f},label={Text(when(f){60->"1H";240->"4H";1440->"1D";else->"${f}m"})}) }
            }
            CandleTimer(s,frame,!stockOpen)
            CandleChart(quote.bars[frame] ?: emptyList(),enabled,"$activeSymbol:$frame")
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                TextButton(onClick={showIndicators=!showIndicators}) {Text(t("indicators"))}
                TextButton(onClick={tab=4}) {Text(t("market_details"))}
                if(venue==OrderVenue.FUTURES) TextButton(onClick={tab=2},modifier=Modifier.testTag("jump_positions")) {
                    Text(t("positions_short")+" (${s.positions.size})")
                }
            }
            if(showIndicators) FlowRow(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                listOf("EMA20","EMA50","EMA200","RSI","MACD","Bollinger","Volume").forEach { indicator ->
                    FilterChip(selected=indicator in enabled,onClick={enabled=if(indicator in enabled)enabled-indicator else enabled+indicator},label={Text(indicator)})
                }
            }

        }
        if(tab==1 && spec.stable)Text(t("settlement_asset"),color=Muted) else if(tab==1)TradingTicket(s,vm,busy,activeSymbol,venue,stockOpen)
        if(tab==2 && venue==OrderVenue.FUTURES) Box(Modifier.fillMaxWidth().bringIntoViewRequester(positionsAnchor).testTag("positions_panel")) {PositionsPanel(s,vm,busy)}
        else if(tab==2)HoldingsPanel(s,catalog.map { it.symbol }.toSet())
        if(tab==3)OrdersPanel(s,vm,busy,venue)
        if(tab==4)AssetInfo(s,spec,vm)
        if(category==AssetKind.STOCK) Text(t("sessions_note"),color=Muted,style=MaterialTheme.typography.bodySmall)
    }
}
