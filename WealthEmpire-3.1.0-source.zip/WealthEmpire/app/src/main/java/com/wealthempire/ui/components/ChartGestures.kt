package com.wealthempire.ui.components

import androidx.compose.foundation.gestures.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.*
import kotlin.math.sign

/** Only consume horizontal drags and two-finger transforms, never one-finger vertical scroll. */
@Composable
internal fun Modifier.chartGestures(
    key: Any,
    onTransform: (panX: Float, zoom: Float, focusX: Float) -> Unit,
    onTap: (Offset) -> Unit
): Modifier {
    val transform by rememberUpdatedState(onTransform)
    val tap by rememberUpdatedState(onTap)
    // Market ticks and viewport updates must not cancel a gesture already in progress.
    return pointerInput(key) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            var owner = ChartDragOwner.WAITING
            var movement = Offset.Zero
            var canTap = true
            while (true) {
                val event = awaitPointerEvent()
                if (event.changes.any { it.isConsumed }) return@awaitEachGesture
                val changes = event.changes
                val multiTouch = changes.count { it.pressed && it.previousPressed } >= 2
                if (multiTouch) {
                    owner = ChartDragOwner.CHART
                    canTap = false
                    transform(event.calculatePan().x, event.calculateZoom(), event.calculateCentroid().x)
                    changes.filter { it.positionChanged() }.forEach { it.consume() }
                } else {
                    val change = changes.firstOrNull { it.id == down.id }
                        ?: changes.firstOrNull { it.pressed }
                        ?: return@awaitEachGesture
                    val delta = change.positionChange()
                    movement += delta
                    val previousOwner = owner
                    if (owner == ChartDragOwner.WAITING)
                        owner = chartDragOwner(movement.x, movement.y, viewConfiguration.touchSlop)
                    if (owner == ChartDragOwner.PAGE) return@awaitEachGesture
                    if (owner == ChartDragOwner.CHART) {
                        canTap = false
                        val pan = if (previousOwner == ChartDragOwner.WAITING)
                            movement.x - sign(movement.x) * viewConfiguration.touchSlop else delta.x
                        transform(pan, 1f, change.position.x)
                        changes.filter { it.positionChanged() }.forEach { it.consume() }
                    }
                    if (changes.none { it.pressed }) {
                        if (canTap) { change.consume(); tap(change.position) }
                        return@awaitEachGesture
                    }
                }
                // The parent may have claimed a vertical scroll during the Main pass.
                if (owner == ChartDragOwner.WAITING &&
                    awaitPointerEvent(PointerEventPass.Final).changes.any { it.isConsumed })
                    return@awaitEachGesture
            }
        }
    }
}
