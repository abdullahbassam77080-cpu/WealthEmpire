package com.wealthempire.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.wealthempire.data.Settings
import com.wealthempire.ui.*
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*
import com.wealthempire.core.market.GameClock
import com.wealthempire.core.models.d
import com.wealthempire.core.models.divD

@Composable fun SettingsScreen(settings:Settings,vm:GameViewModel) {
    var reset by remember { mutableStateOf(false) }
    var mode by remember {mutableStateOf(com.wealthempire.core.world.GameMode.PURE_INVESTOR)}
    ScreenColumn {
        SectionCard(t("settings")) {
            Choice(t("language"),listOf("ar","en"),settings.language,vm::language){t(if(it=="ar")"arabic" else "english")}
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                Text(t("haptics"));Switch(checked=settings.haptics,onCheckedChange=vm::haptics)
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                Text(t("reduced_motion"));Switch(checked=settings.reducedMotion,onCheckedChange=vm::motion)
            }
        }
        SectionCard {Choice(t("game_mode"),com.wealthempire.core.world.GameMode.entries.toList(),mode,{mode=it}){t("mode_"+it.name.lowercase())}
            Text(t("mode_description"),color=Muted,style=MaterialTheme.typography.bodySmall)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(t("sounds"));Switch(settings.soundEnabled,vm::sound)}}
        SectionCard(t("clock_speed")) {
            Choice(t("clock_speed"),GameClock.speeds,settings.marketSpeed,vm::speed) {
                if(it==0)t("pause") else if(it==1)t("real_time")+" • ×1" else "×$it"
            }
            Text(t("clock_speed_note"),color=Muted,style=MaterialTheme.typography.bodySmall)
            InfoRow(t("one_game_minute"),if(settings.marketSpeed==0)t("pause") else qty(d(60).divD(d(settings.marketSpeed)))+" "+t("real_seconds"))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                Text(t("light_notices"),modifier=Modifier.weight(1f))
                Switch(checked=settings.alertsEnabled,onCheckedChange=vm::alerts)
            }
            Text(t("light_notices_note"),color=Muted,style=MaterialTheme.typography.bodySmall)
        }
        SectionCard {
            Button(onClick={reset=true},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Down)){Text(t("new_game"))}
            OutlinedButton(onClick={reset=true},modifier=Modifier.fillMaxWidth()){Text(t("reset_game"))}
            Text(t("bankrupt_hint"),color=Muted,style=MaterialTheme.typography.bodySmall)
        }
        Text(t("about"),color=Muted);Text(t("virtual_only"),color=Gold)
    }
    if(reset) AlertDialog(onDismissRequest={reset=false},title={Text(t("reset_title"))},text={Text(t("reset_message"))},
        confirmButton={TextButton(onClick={vm.reset(mode);reset=false}){Text(t("confirm_reset"),color=Down)}},
        dismissButton={TextButton(onClick={reset=false}){Text(t("cancel"))}})
}
