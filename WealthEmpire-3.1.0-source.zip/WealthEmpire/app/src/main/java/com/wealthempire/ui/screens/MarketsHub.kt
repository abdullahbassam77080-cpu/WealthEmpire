package com.wealthempire.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.*
import com.wealthempire.ui.*
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*

@Composable fun MarketsHub(s:GameState,vm:GameViewModel,navigate:(String)->Unit) {
    var category by rememberSaveable {mutableIntStateOf(0)};var sort by rememberSaveable {mutableIntStateOf(0)};var search by rememberSaveable {mutableStateOf("")}
    val labels=listOf("crypto_market","stocks","etf","forex","commodities","bonds","listings")
    val all=vm.repository.engine.market.visibleAssets(s).filter {a->!a.stable && when(category){0->a.kind==AssetKind.CRYPTO && a.sector!="emerging";1->a.kind==AssetKind.STOCK && !a.isEtf;2->a.isEtf;3->a.kind==AssetKind.FOREX;4->a.kind==AssetKind.COMMODITY;5->a.kind==AssetKind.BOND;else->a.sector=="emerging"}}
        .filter {search.isBlank() || (it.symbol+it.name+it.nameAr).contains(search,true)}
    fun change(a:AssetSpec)=s.quote(a.symbol).let {it.price.divD(it.dayOpen).toDouble()-1}
    val rows=when(sort){1->all.filter {it.symbol in s.favorites};2->all.sortedByDescending(::change);3->all.sortedBy(::change);4->all.sortedByDescending {s.world.micro[it.symbol]?.volume ?: 0.0};else->all}
    Column(Modifier.fillMaxSize().padding(horizontal=16.dp)) {
        OutlinedTextField(search,{search=it},placeholder={Text(t("search_asset"))},singleLine=true,modifier=Modifier.fillMaxWidth())
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){labels.forEachIndexed {i,key->FilterChip(category==i,{category=i},label={Text(t(key))},modifier=Modifier.testTag("category_$key"))}}
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("all","favorites","top_gainers","top_losers","most_active").forEachIndexed {i,key->FilterChip(sort==i,{sort=i},label={Text(t(key))})}}
        if(category==6)TextButton(onClick={navigate("listings")}){Text(t("upcoming"))}
        LazyColumn {items(rows,key={it.symbol}){a->MarketRow(a,s,{navigate("trade/${a.symbol}")}){vm.favorite(a.symbol)};HorizontalDivider(color=Muted.copy(alpha=.08f))}}
    }
}
