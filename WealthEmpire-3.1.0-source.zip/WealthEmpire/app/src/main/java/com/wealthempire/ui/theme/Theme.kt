package com.wealthempire.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Background=Color(0xFF070B12)
val Panel=Color(0xFF111A27)
val Up=Color(0xFF31D9A1)
val Down=Color(0xFFFF5C74)
val Gold=Color(0xFFE7BD65)
val Muted=Color(0xFF8A9BB5)
val ChartBlue=Color(0xFF75A7FF)
val Elevated=Color(0xFF172235)
val Violet=Color(0xFF9A7DFF)
private val Colors=darkColorScheme(primary=Up,secondary=Gold,background=Background,surface=Panel,
    surfaceVariant=Color(0xFF1B2940),onPrimary=Background,onBackground=Color(0xFFF1F5FD),
    onSurface=Color(0xFFF1F5FD),onSurfaceVariant=Muted,error=Down)
@Composable fun EmpireTheme(content:@Composable ()->Unit) { MaterialTheme(colorScheme=Colors,typography=Typography(
    displaySmall=androidx.compose.ui.text.TextStyle(fontSize=36.sp,fontWeight=androidx.compose.ui.text.font.FontWeight.Bold),
    titleMedium=androidx.compose.ui.text.TextStyle(fontSize=17.sp,fontWeight=androidx.compose.ui.text.font.FontWeight.SemiBold)),
    shapes=Shapes(medium=androidx.compose.foundation.shape.RoundedCornerShape(14.dp),large=androidx.compose.foundation.shape.RoundedCornerShape(20.dp)),content=content) }
