package com.wealthempire.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.*
import com.wealthempire.ui.t
import com.wealthempire.ui.theme.*
import com.wealthempire.core.models.*
import java.math.BigDecimal
import java.text.NumberFormat
import java.util.Locale

fun money(value:BigDecimal):String = "$"+NumberFormat.getNumberInstance(Locale.US).apply {
    minimumFractionDigits=2; maximumFractionDigits=if(value.abs() < d(1) && value != ZERO) 6 else 2
}.format(value)
fun qty(value:BigDecimal):String = value.setScale(8,java.math.RoundingMode.HALF_EVEN).stripTrailingZeros().toPlainString()
fun percent(value:BigDecimal):String = value.setScale(2,java.math.RoundingMode.HALF_EVEN).toPlainString()+"%"
fun parsed(value:String):BigDecimal? = runCatching {
    val normalized=value.trim().map { c -> if(c in '٠'..'٩') ('0'.code+c.code-'٠'.code).toChar() else if(c in '۰'..'۹') ('0'.code+c.code-'۰'.code).toChar() else c }.joinToString("").replace('٫','.')
    val plain=if(normalized.startsWith(".")) "0$normalized" else normalized
    if(plain.length > 40 || !plain.matches(Regex("[0-9]{1,16}(\\.[0-9]{0,28})?"))) null else plain.toBigDecimalOrNull()
}.getOrNull()
@Composable fun ScreenColumn(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement=Arrangement.spacedBy(14.dp),content=content)
}
@Composable fun SectionCard(title:String?=null, content:@Composable ColumnScope.()->Unit) {
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Panel)) {
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            if(title != null) Text(title,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.SemiBold)
            content()
        }
    }
}
@Composable fun Metric(label:String,value:String,positive:Boolean?=null,large:Boolean=false) {
    Column(verticalArrangement=Arrangement.spacedBy(5.dp)) {
        Text(label,color=Muted,style=MaterialTheme.typography.labelMedium)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(value,color=when(positive){true->Up;false->Down;null->MaterialTheme.colorScheme.onSurface},
                style=if(large) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.titleMedium,
                fontWeight=FontWeight.SemiBold)
        }
    }
}
@Composable fun InfoRow(label:String,value:String) {
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
        Text(label,color=Muted,modifier=Modifier.weight(1f),style=MaterialTheme.typography.bodySmall)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(value,style=MaterialTheme.typography.bodySmall)
        }
    }
}
@Composable fun MoneyInput(label:String,value:String,onValue:(String)->Unit,modifier:Modifier=Modifier) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        OutlinedTextField(value=value,onValueChange={ if(it.length<=40) onValue(it) },label={Text(label)},singleLine=true,
            modifier=modifier.fillMaxWidth(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
    }
}
@Composable fun <T> Choice(label:String,values:List<T>,selected:T,onSelect:(T)->Unit,text:@Composable (T)->String) {
    var expanded by remember { mutableStateOf(false) }
    Column { Text(label,color=Muted,style=MaterialTheme.typography.labelSmall)
        Box { OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()) { Text(text(selected)) }
            DropdownMenu(expanded=expanded,onDismissRequest={expanded=false},modifier=Modifier.heightIn(max=330.dp)) {
                values.forEach { item -> DropdownMenuItem(text={Text(text(item))},onClick={onSelect(item);expanded=false}) }
            }
        }
    }
}
@Composable fun walletLabel(wallet:Wallet) = t(when(wallet) {
    Wallet.CASH->"cash_wallet"; Wallet.FUTURES->"futures_wallet"; Wallet.SPOT->"spot_wallet"; Wallet.STOCKS->"stocks_wallet"
})

fun compactMoney(value:BigDecimal):String {
    val units=listOf(d("1000000000000") to "T",d("1000000000") to "B",d("1000000") to "M",d("1000") to "K")
    val unit=units.firstOrNull {value.abs()>=it.first} ?: return money(value)
    return "$"+value.divD(unit.first).setScale(2,java.math.RoundingMode.HALF_EVEN).toPlainString()+unit.second
}
