package com.wealthempire.repository

import com.wealthempire.data.*
import com.wealthempire.core.GameEngine
import com.wealthempire.core.models.*
import com.wealthempire.core.world.*
import com.wealthempire.core.market.*
import com.wealthempire.core.progression.ProgressionEngine
import com.wealthempire.core.statistics.Wealth
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** One owner of mutable state. Commands drain before each bounded simulation quantum. */
class GameRepository(private val dao:SnapshotDao,private val scope:CoroutineScope,catalog:List<AssetSpec>,private val settingsStore:SettingsStore?=null) {
    val engine=GameEngine(MarketEngine(catalog))
    private sealed interface Request
    private data class Action(val kind:String,val block:(GameState)->Unit,val done:CompletableDeferred<Unit>):Request
    private data class Capture(val done:CompletableDeferred<Triple<GameState,Long,Long>?>):Request
    private data class Reset(val mode:GameMode,val done:CompletableDeferred<Unit>):Request
    private val commands=Channel<Request>(128)
    private val pulses=Channel<Long>(Channel.CONFLATED)
    private val checkpointMutex=Mutex() // Snapshot worker only; never held by player actions.
    private var current:GameState?=null
    private var snapshotSeq=0L
    private var epoch=0L
    private var revision=0L
    private var savedRevision=-1L
    private var persistedWorldTime=0L
    private val _state=MutableStateFlow<GameState?>(null);val state=_state.asStateFlow()
    private val _failure=MutableStateFlow<String?>(null);val failure=_failure.asStateFlow()
    private val _catchup=MutableStateFlow(false);val catchup=_catchup.asStateFlow()
    private val _latency=MutableStateFlow(0L);val commandLatencyMs=_latency.asStateFlow()
    private var worldJournalAt=0L
    private var publishedAt=0L
    private data class AwayCapture(val at:Long,val wealth:String,val prices:Map<String,Double>,val stops:Long,val profits:Long,val liquidations:Long,val newsId:Long,val fills:Long,val funding:java.math.BigDecimal,val earn:java.math.BigDecimal)
    private var away:AwayCapture?=null
    private val owner=scope.launch(Dispatchers.Default.limitedParallelism(1)) {
        try {
            val primary=runCatching {dao.current()};val saved=primary.getOrNull()
            val fresh=primary.isSuccess && saved==null;var repaired=false
            var s=if(fresh)engine.newGame(System.currentTimeMillis()) else runCatching {SnapshotCodec.decode(saved!!.payload)}.getOrElse {val backup=dao.backup() ?: throw it;repaired=true;SnapshotCodec.decode(backup.payload)}
            val restart=SaveMigrations.needsEconomyRestart(s)
            snapshotSeq=s.journalSeq
            if(!restart)dao.journal(s.journalSeq).forEach {s=JournalCodec.replay(s,it)}
            s=engine.restore(s,System.currentTimeMillis())
            if(fresh)settingsStore?.settings?.first()?.let {s.marketSpeed=it.marketSpeed;s.alertsEnabled=it.alertsEnabled}
            GameClock.requireSpeed(s.marketSpeed)
            if(restart || fresh || repaired) {withContext(Dispatchers.IO){dao.reset(SnapshotCodec.encode(s),System.currentTimeMillis())};snapshotSeq=s.journalSeq}
            settingsStore?.setSpeed(s.marketSpeed);settingsStore?.setAlerts(s.alertsEnabled)
            current=s;persistedWorldTime=s.marketTime;_state.value=s
        }catch(e:Exception){_failure.value=e.message ?: "storage_error"}
        while(isActive) {
            val high=commands.tryReceive().getOrNull()
            if(high!=null){handle(high);continue}
            val active=current
            if(active!=null && active.pendingWorldMs>0) {
                try {
                    val candidate=GameStateCopy.copy(active,true);engine.advanceOne(candidate)
                    val now=System.currentTimeMillis()
                    // Passive Earn accrual checkpoints with the world; it must not cause 16 full journal frames per real second.
                    val financial=candidate.nextId!=active.nextId || candidate.positions.size!=active.positions.size || candidate.stats.funding!=active.stats.funding
                    if(financial || now-worldJournalAt>=2000 || candidate.pendingWorldMs==0L){persistJournal(candidate,"WORLD_ADVANCED",true);worldJournalAt=now}
                    current=candidate;revision++
                    if(now-publishedAt>=250 || candidate.pendingWorldMs==0L){_state.value=candidate;publishedAt=now}
                    if(candidate.pendingWorldMs==0L)finishAway()
                }catch(e:Exception){_failure.value=e.message ?: "storage_error";current=null}
                yield();continue
            }
            select<Unit> {commands.onReceive {handle(it)};pulses.onReceive {now->pulse(now)}}
        }
    }
    init {scope.launch(Dispatchers.IO){while(isActive){delay(30_000);runCatching {checkpoint()}}}}
    private suspend fun persistJournal(s:GameState,kind:String,world:Boolean) {
        s.journalSeq=(current?.journalSeq ?: s.journalSeq)+1
        val full=world || s.marketTime!=persistedWorldTime
        val payload=JournalCodec.encode(s,full)
        withContext(Dispatchers.IO){dao.appendJournal(JournalEntity(s.journalSeq,kind,payload,System.currentTimeMillis(),JournalCodec.checksum(payload)))}
        if(full)persistedWorldTime=s.marketTime
    }
    private suspend fun handle(request:Request) {
        when(request) {
            is Capture->request.done.complete(current?.let {Triple(it,epoch,revision)})
            is Action->{val start=System.nanoTime()
                try {val candidate=GameStateCopy.copy(requireNotNull(current){"storage_error"},false)
                    request.block(candidate);ProgressionEngine.observe(candidate,engine.market);Wealth.update(candidate,candidate.marketTime)
                    persistJournal(candidate,request.kind,false);current=candidate;revision++;_state.value=candidate
                    _latency.value=(System.nanoTime()-start)/1_000_000;request.done.complete(Unit)
                }catch(e:Exception){request.done.completeExceptionally(e)}}
            is Reset->try {
                val s=engine.newGame(System.currentTimeMillis(),mode=request.mode)
                current?.let {s.marketSpeed=it.marketSpeed;s.alertsEnabled=it.alertsEnabled}
                checkpointMutex.withLock {epoch++;savedRevision=-1;withContext(Dispatchers.IO){dao.reset(SnapshotCodec.encode(s),System.currentTimeMillis())};snapshotSeq=0}
                current=s;revision++;persistedWorldTime=s.marketTime;away=null;_catchup.value=false;_state.value=s;_failure.value=null;request.done.complete(Unit)
            }catch(e:Exception){request.done.completeExceptionally(e)}
        }
    }
    private fun pulse(now:Long) {
        val previous=current ?: return;val s=GameStateCopy.copy(previous,false)
        if(now-previous.marketTickAt>=5*60_000L && away==null){away=AwayCapture(s.marketTime,Wealth.total(s).toPlainString(),s.quotes.associate {it.symbol to it.price.toDouble()},s.stats.stopExecutions,s.stats.takeProfitExecutions,s.stats.liquidations,s.news.firstOrNull()?.id ?: 0,s.stats.filledOrders,s.stats.funding,s.stats.savings);_catchup.value=true}
        engine.queueElapsed(s,now);s.stats.timePlayedMs+=(now-s.lastSeenAt).coerceIn(0,2000);s.lastSeenAt=maxOf(now,s.lastSeenAt)
        current=s;revision++;if(s.pendingWorldMs==0L)_state.value=s
    }
    private suspend fun finishAway() {
        val a=away ?: return;val old=current ?: return
        val s=GameStateCopy.copy(old,false)
        s.awayReport=AwayReport(a.at,s.marketTime,a.wealth,Wealth.total(s).toPlainString(),s.quotes.filter {it.symbol in a.prices}.associate {it.symbol to ((it.price.toDouble()/a.prices.getValue(it.symbol)-1)*100)},s.news.filter {it.time>a.at}.sortedByDescending {kotlin.math.abs(it.impact)}.take(8).map {it.id},(s.stats.filledOrders-a.fills).toInt(),(s.stats.stopExecutions-a.stops).toInt(),(s.stats.takeProfitExecutions-a.profits).toInt(),(s.stats.liquidations-a.liquidations).toInt(),(s.stats.funding-a.funding).toPlainString(),(s.stats.savings-a.earn).toPlainString())
        persistJournal(s,"AWAY_REPORT",true);current=s;revision++;_state.value=s;away=null;_catchup.value=false
    }
    suspend fun command(kind:String="PLAYER_COMMAND",block:(GameState)->Unit){val done=CompletableDeferred<Unit>();commands.send(Action(kind,block,done));done.await()}
    suspend fun session(){while(currentCoroutineContext().isActive){pulses.send(System.currentTimeMillis());delay(1000)}}
    suspend fun checkpoint() {val done=CompletableDeferred<Triple<GameState,Long,Long>?>();commands.send(Capture(done));val ticket=done.await() ?: return
        checkpointMutex.withLock {if(ticket.second!=epoch || ticket.third<=savedRevision)return@withLock
            withContext(Dispatchers.IO){val s=ticket.first;val old=snapshotSeq;dao.save(SnapshotCodec.encode(s),System.currentTimeMillis());dao.pruneJournal(old);snapshotSeq=s.journalSeq;savedRevision=ticket.third}}
    }
    suspend fun setSpeed(value:Int){command("TIME_SPEED_CHANGED"){engine.setSpeed(it,value,System.currentTimeMillis())};settingsStore?.setSpeed(value)}
    suspend fun setAlerts(value:Boolean){command("NOTICES_CHANGED"){it.alertsEnabled=value;if(!value)it.alerts.clear()};settingsStore?.setAlerts(value)}
    suspend fun reset(mode:GameMode=GameMode.PURE_INVESTOR){val done=CompletableDeferred<Unit>();commands.send(Reset(mode,done));done.await()}
}
