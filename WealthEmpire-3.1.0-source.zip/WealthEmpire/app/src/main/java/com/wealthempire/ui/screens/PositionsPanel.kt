package com.wealthempire.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.*
import com.wealthempire.core.trading.FuturesMath
import com.wealthempire.core.trading.LiquidationRange
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.wealthempire.ui.*
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun PositionsPanel(s:GameState,vm:GameViewModel,busy:Boolean) {
    var closeId by remember {mutableStateOf<Long?>(null)}
    var ranges by remember {mutableStateOf<Map<Long,LiquidationRange>>(emptyMap())}
    LaunchedEffect(s.positions,s.futuresCash,s.quotes.map {it.price}) {
        ranges=withContext(Dispatchers.Default) {
            val cross=s.positions.filter {it.mode==MarginMode.CROSS}.distinctBy {it.symbol}.associate {it.symbol to FuturesMath.liquidationRange(s,it)}
            s.positions.associate {it.id to (cross[it.symbol].takeIf {_ -> it.mode==MarginMode.CROSS} ?: FuturesMath.liquidationRange(s,it))}
        }
    }
    var editId by remember { mutableStateOf<Long?>(null) }
    var detailsId by remember {mutableStateOf<Long?>(null)}
    var tp by remember { mutableStateOf("") }; var sl by remember { mutableStateOf("") }
    Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text(t("positions")+" (${s.positions.size})",style=MaterialTheme.typography.titleMedium)
        if(s.positions.isEmpty())Text(t("empty_positions"),color=Muted)
        s.positions.forEach { p ->
            val range=ranges[p.id]
            PositionCard(s,p,range,busy,details={detailsId=p.id},
                brackets={editId=p.id;tp=p.takeProfit?.let(::qty) ?: "";sl=p.stopLoss?.let(::qty) ?: ""},
                partial={closeId=p.id},close={vm.close(p.id)})
        }
    }
    s.positions.firstOrNull {it.id==detailsId}?.let {p ->
        ModalBottomSheet(onDismissRequest={detailsId=null},containerColor=Panel) {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Text("${p.symbol}USDT • "+t("position_details"),style=MaterialTheme.typography.titleMedium)
                val mark=s.quote(p.symbol).price
                val range=ranges[p.id]
                InfoRow(t("liquidation_price"),if(range?.unsafeNow==true)t("liquidation_imminent") else compactLiquidation(range))
                InfoRow("TP / SL",(p.takeProfit?.let(::money) ?: "—")+" / "+(p.stopLoss?.let(::money) ?: "—"))
                InfoRow(t("maintenance"),money(FuturesMath.maintenance(p,mark)));InfoRow(t("funding"),money(p.funding))
                InfoRow(t("entry_fee"),money(p.openFee))
                if(p.mode==MarginMode.CROSS) {
                    InfoRow(t("cross_equity"),money(FuturesMath.crossEquity(s)))
                    InfoRow(t("cross_requirement"),money(FuturesMath.crossRequirement(s)))
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
    s.positions.firstOrNull {it.id==closeId}?.let {PartialCloseDialog(s,it,vm,busy){closeId=null}}
    if(editId!=null) AlertDialog(onDismissRequest={editId=null},title={Text(t("edit_brackets"))},text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            MoneyInput(t("tp_optional"),tp,{tp=it});MoneyInput(t("sl_optional"),sl,{sl=it})
        }
    },confirmButton={TextButton(onClick={
        val target=if(tp.isBlank())null else parsed(tp);val stop=if(sl.isBlank())null else parsed(sl)
        if(tp.isNotBlank() && target==null)vm.events.tryEmit("invalid_tp")
        else if(sl.isNotBlank() && stop==null)vm.events.tryEmit("invalid_sl")
        else {vm.brackets(editId!!,target,stop);editId=null}
    }){Text(t("apply"))}},dismissButton={TextButton(onClick={editId=null}){Text(t("cancel"))}})
}
@Composable fun OrdersPanel(s:GameState,vm:GameViewModel,busy:Boolean,venue:OrderVenue) {
    var tab by remember { mutableIntStateOf(0) };var limit by remember { mutableIntStateOf(20) }
    SectionCard {
        ScrollableTabRow(selectedTabIndex=tab,edgePadding=0.dp) {
            listOf("open_orders","order_history","trade_history").forEachIndexed { i,key -> Tab(selected=tab==i,onClick={tab=i;limit=20},text={Text(t(key))}) }
        }
        if(tab==0) {
            val orders=s.orders.filter { it.venue==venue }
            if(orders.isEmpty()) Text(t("empty_orders"),color=Muted)
            orders.forEach { o -> Text("${o.symbol} ${o.side} • ${o.kind}")
                InfoRow(t("amount"),qty(o.amount));InfoRow(t("trigger_price"),o.trigger?.let(::money) ?: "—")
                InfoRow(t("reserved_orders"),money(o.reserved))
                TextButton(onClick={vm.cancel(o.id)},enabled=!busy){Text(t("cancel_order"))}
            }
        } else if(tab==1) {
            val orders=s.orderHistory.filter { it.venue==venue }
            if(orders.isEmpty())Text(t("no_history"),color=Muted)
            orders.take(limit).forEach { o -> Text("#${o.id}  ${o.symbol} ${o.side} • ${o.kind}")
                Text(t(o.result),color=if(o.status==OrderStatus.FILLED)Up else Muted,style=MaterialTheme.typography.bodySmall)
                HorizontalDivider(color=Muted.copy(alpha=.15f))
            }
            if(orders.size>limit)TextButton(onClick={limit+=20}){Text("+20")}
        } else {
            val trades=s.trades.filter { it.venue==venue }
            if(trades.isEmpty())Text(t("no_history"),color=Muted)
            trades.take(limit).forEach { trade ->
                Text("#${trade.id}  ${trade.symbol} ${trade.side} • ${t(trade.reason)}",color=if(trade.reason=="LIQUIDATED")Down else MaterialTheme.colorScheme.onSurface)
                Metric(t("pnl"),money(trade.pnl),trade.pnl>=ZERO)
                InfoRow(t("entry_price")+" → "+t("current"),money(trade.entry)+" → "+money(trade.exit))
                InfoRow(t("quantity"),qty(trade.quantity));InfoRow(t("total_fees"),money(trade.fees))
                HorizontalDivider(color=Muted.copy(alpha=.15f))
            }
            if(trades.size>limit)TextButton(onClick={limit+=20}){Text("+20")}
        }
    }
}
