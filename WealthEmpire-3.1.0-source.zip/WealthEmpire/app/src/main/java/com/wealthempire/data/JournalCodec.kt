package com.wealthempire.data

import com.wealthempire.core.models.*
import com.wealthempire.core.world.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.security.MessageDigest

@Serializable data class JournalPayload(val sequence:Long,val ledger:GameState,val frame:GameState?=null)
object JournalCodec {
    private val json=Json {encodeDefaults=true;ignoreUnknownKeys=true}
    private fun ledger(s:GameState)=s.copy(quotes=mutableListOf(),world=WorldState(),economy=EconomyState(),effects=mutableListOf(),stories=mutableListOf(),listings=mutableListOf(),news=mutableListOf(),wealthHistory=mutableListOf(),financialHistory=mutableListOf())
    fun encode(s:GameState,world:Boolean):String=json.encodeToString(JournalPayload.serializer(),JournalPayload(s.journalSeq,ledger(s),if(world)s.copy(quotes=s.quotes.map {it.copy(bars=mutableMapOf())}.toMutableList()) else null))
    fun checksum(text:String)=MessageDigest.getInstance("SHA-256").digest(text.toByteArray()).joinToString(""){"%02x".format(it)}
    fun replay(base:GameState,row:JournalEntity):GameState {
        require(checksum(row.payload)==row.checksum){"journal_corrupt"}
        val p=json.decodeFromString<JournalPayload>(row.payload)
        require(p.sequence==row.sequence){"journal_corrupt"}
        if(row.sequence<=base.journalSeq)return base
        require(row.sequence==base.journalSeq+1){"journal_gap"}
        val x=p.ledger
        var s=base.copy(journalSeq=p.sequence,cash=x.cash,futuresCash=x.futuresCash,spotCash=x.spotCash,stocksCash=x.stocksCash,
            initialCapital=x.initialCapital,lastSeenAt=x.lastSeenAt,marketTickAt=x.marketTickAt,marketCarryMs=x.marketCarryMs,pendingWorldMs=x.pendingWorldMs,
            marketSpeed=x.marketSpeed,alertsEnabled=x.alertsEnabled,alerts=x.alerts,rngState=x.rngState,nextId=x.nextId,xp=x.xp,
            gameMode=x.gameMode,progression=x.progression,favorites=x.favorites,awayReport=x.awayReport,
            holdings=x.holdings,positions=x.positions,orders=x.orders,orderHistory=x.orderHistory,trades=x.trades,
            achievements=x.achievements,savings=x.savings,savingsOffers=x.savingsOffers,savingsHistory=x.savingsHistory,stats=x.stats)
        p.frame?.let {f->
            val quotes=f.quotes.map {q->val old=base.quotes.firstOrNull {it.symbol==q.symbol};q.copy(bars=old?.bars ?: mutableMapOf())}.toMutableList()
            s=s.copy(world=f.world,economy=f.economy,quotes=quotes,marketTime=f.marketTime,ticks=f.ticks,regime=f.regime,
                regimeUntil=f.regimeUntil,fundingBucket=f.fundingBucket,news=f.news,listings=f.listings,stories=f.stories,effects=f.effects,
                wealthHistory=f.wealthHistory,financialHistory=f.financialHistory)
        }
        return s
    }
}
