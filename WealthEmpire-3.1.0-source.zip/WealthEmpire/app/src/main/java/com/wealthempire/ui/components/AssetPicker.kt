package com.wealthempire.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.*
import com.wealthempire.ui.t
import com.wealthempire.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AssetPicker(assets:List<AssetSpec>,selected:AssetSpec,s:GameState,onSelect:(String)->Unit) {
    var open by remember {mutableStateOf(false)}
    var search by remember {mutableStateOf("")}
    OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth().testTag("asset_picker")) {
        Text(selected.symbol+if(selected.kind==AssetKind.CRYPTO)"/USDT" else " / USD")
        Spacer(Modifier.width(12.dp));Text(assetName(selected),style=MaterialTheme.typography.labelMedium,color=Muted)
    }
    if(open)ModalBottomSheet(onDismissRequest={open=false},containerColor=Panel) {
        Column(Modifier.fillMaxWidth().padding(horizontal=16.dp)) {
            OutlinedTextField(search,{search=it},label={Text(t("search_asset"))},singleLine=true,modifier=Modifier.fillMaxWidth())
            LazyColumn(Modifier.fillMaxWidth().heightIn(max=420.dp)) {
                items(assets.filter {it.symbol.contains(search,true) || it.name.contains(search,true) || it.nameAr.contains(search)},key={it.symbol}) {a ->
                    Row(Modifier.fillMaxWidth().clickable {onSelect(a.symbol);open=false;search=""}.padding(vertical=14.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                        Column {Text(a.symbol);Text(assetName(a),color=Muted,style=MaterialTheme.typography.labelSmall)}
                        s.quotes.firstOrNull {it.symbol==a.symbol}?.let {q->Text(marketPrice(q.price))}
                    }
                    HorizontalDivider(color=Muted.copy(alpha=.12f))
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
