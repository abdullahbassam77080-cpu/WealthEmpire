package com.wealthempire.navigation

import android.content.res.Configuration
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.unit.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.*
import com.wealthempire.ui.*
import com.wealthempire.ui.screens.*
import com.wealthempire.ui.theme.*
import com.wealthempire.ui.components.MarketClockBanner
import com.wealthempire.ui.components.GameNoticeHost
import kotlinx.coroutines.delay
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun EmpireApp(vm:GameViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val state by vm.state.collectAsStateWithLifecycle()
    val failure by vm.failure.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val catchingUp by vm.repository.catchup.collectAsStateWithLifecycle()
    val originalContext=LocalContext.current
    val originalConfig=LocalConfiguration.current
    val config=remember(originalConfig,settings.language) { Configuration(originalConfig).apply { setLocale(Locale(settings.language)) } }
    val context=remember(config) { originalContext.createConfigurationContext(config) }
    CompositionLocalProvider(LocalContext provides context,LocalConfiguration provides config,
        LocalLayoutDirection provides if(settings.language=="ar")LayoutDirection.Rtl else LayoutDirection.Ltr) {
        EmpireTheme {
            val nav=rememberNavController();val entry by nav.currentBackStackEntryAsState()
            val route=entry?.destination?.route ?: "dashboard"
            val snackbar=remember { SnackbarHostState() }
            val haptic=LocalHapticFeedback.current
            val latestSettings by rememberUpdatedState(settings)
            var liquidation by remember { mutableStateOf(false) }
            var knownTrade by remember { mutableLongStateOf(0) }
            LaunchedEffect(vm,context) {
                vm.events.collect { key ->
                    if(key!="saved") {
                        snackbar.showSnackbar(message(context,key))
                    } else if(latestSettings.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                }
            }
            LaunchedEffect(state?.trades?.firstOrNull()?.id) {
                val trades=state?.trades ?: emptyList()
                if(knownTrade!=0L && trades.any {it.id>knownTrade} && latestSettings.soundEnabled){val tone=android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC,25);tone.startTone(android.media.ToneGenerator.TONE_PROP_ACK,80);delay(100);tone.release()}
                if(knownTrade!=0L && trades.any { it.id>knownTrade && it.reason=="LIQUIDATED" }) {
                    liquidation=true
                    if(settings.haptics)haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    delay(if(settings.reducedMotion)2500 else 5000);liquidation=false
                }
                knownTrade=trades.firstOrNull()?.id ?: knownTrade
            }
            Box(Modifier.fillMaxSize()) {
            Scaffold(containerColor=Background,topBar={
                TopAppBar(title={Column { Text(if(route=="dashboard")"Wealth Empire" else if(route.startsWith("trade/"))t("crypto") else t(route),style=MaterialTheme.typography.titleLarge)
                    Text(state?.let {"LV ${it.level} • XP ${it.xp}"} ?: t("virtual_only"),style=MaterialTheme.typography.labelSmall,color=Gold) }},
                    navigationIcon={if(route in listOf("statistics","news","settings","research") || route.startsWith("trade/"))IconButton(onClick={nav.popBackStack()}){Icon(Icons.AutoMirrored.Filled.ArrowBack,contentDescription=t("dashboard"))}},
                    actions={IconButton(onClick={nav.navigate("settings"){launchSingleTop=true}}){Icon(Icons.Default.Settings,contentDescription=t("settings"))}},
                    colors=TopAppBarDefaults.topAppBarColors(containerColor=Background))
            },bottomBar={
                val routes=listOf("dashboard","crypto","wallet","economy","progress")
                val icons=listOf(Icons.Default.Dashboard,Icons.Default.CandlestickChart,Icons.Default.AccountBalanceWallet,Icons.Default.AccountBalance,Icons.Default.Insights)
                NavigationBar(containerColor=Panel) {
                    routes.forEachIndexed { i,key -> NavigationBarItem(modifier=Modifier.testTag("nav_$key"),selected=route==key,onClick={
                        nav.navigate(key){popUpTo(nav.graph.startDestinationId){saveState=true};launchSingleTop=true;restoreState=true}
                    },icon={Icon(icons[i],contentDescription=t(key))},label={Text(t(key),style=MaterialTheme.typography.labelSmall,maxLines=1)}) }
                }
            },snackbarHost={SnackbarHost(snackbar)}) { padding ->
                Column(Modifier.fillMaxSize().padding(padding)) {
                    state?.let {MarketClockBanner(it)}
                    if(catchingUp){LinearProgressIndicator(modifier=Modifier.fillMaxWidth());Text(t("simulating_away"),color=Muted,style=MaterialTheme.typography.labelSmall,modifier=Modifier.padding(horizontal=16.dp))}
                    AnimatedVisibility(liquidation) {
                        Surface(color=Down.copy(alpha=.16f),modifier=Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {Text(t("liquidated"),color=Down);Text(t("liquidation_notice"),style=MaterialTheme.typography.bodySmall)}
                        }
                    }
                    val game=state
                    if(game==null || failure!=null) {
                        Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center) {
                            if(failure==null){CircularProgressIndicator();Text(t("loading"))}
                            else {Text(t("storage_error"),color=Down);SettingsScreen(settings,vm)}
                        }
                    } else NavHost(navController=nav,startDestination="dashboard",modifier=Modifier.weight(1f)) {
                        composable("dashboard"){DashboardScreen(game,vm.repository.engine.market.assets(game)){nav.navigate(it)}}
                        composable("crypto"){MarketsHub(game,vm){nav.navigate(it)}}
                        composable("stocks"){MarketScreen(game,vm,busy,true)}
                        composable("trade/{symbol}"){MarketScreen(game,vm,busy,initialSymbol=it.arguments?.getString("symbol"))}
                        composable("listings"){ListingsScreen(game){nav.navigate(it)}}
                        composable("savings"){SavingsScreen(game,vm,busy){nav.navigate(it)}}
                        composable("wallet"){WalletScreen(game,vm,busy){nav.navigate(it)}}
                        composable("statistics"){StatisticsScreen(game)}
                        composable("economy"){EconomyScreen(game,vm)}
                        composable("progress"){ProgressScreen(game,vm){nav.navigate(it)}}
                        composable("research"){ResearchScreen(game,vm)}
                        composable("news"){NewsScreen(game)}
                        composable("settings"){SettingsScreen(settings,vm)}
                    }
                }
            }
            state?.takeIf {failure==null && !catchingUp}?.let {AwayReportSheet(it,vm)}
            state?.takeIf {failure==null && !catchingUp}?.let {GameNoticeHost(it,vm,settings.reducedMotion,
                Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(horizontal=16.dp,vertical=8.dp))}
            }
        }
    }
}
