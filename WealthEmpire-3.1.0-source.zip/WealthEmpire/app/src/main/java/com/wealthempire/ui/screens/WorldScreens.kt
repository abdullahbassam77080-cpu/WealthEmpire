package com.wealthempire.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.*
import com.wealthempire.core.world.*
import com.wealthempire.core.progression.ProgressionEngine
import com.wealthempire.core.portfolio.PortfolioAnalytics
import com.wealthempire.core.statistics.Wealth
import com.wealthempire.ui.*
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale

private fun number(v:Double)=String.format(Locale.US,"%.2f",v)
private val dates=DateTimeFormatter.ofPattern("MM-dd HH:mm").withZone(ZoneOffset.UTC)
@Composable fun EconomyScreen(s:GameState,vm:GameViewModel) {
    var region by remember {mutableStateOf("USA")};var skip by remember {mutableStateOf(false)};var details by remember {mutableStateOf(false)}
    val e=s.world.economies[region] ?: return
    ScreenColumn {
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){s.world.economies.keys.forEach {key->FilterChip(region==key,{region=key},label={Text(t(key.lowercase()))})}}
        Text(t("phase_"+e.phase.name.lowercase()),color=Gold,style=MaterialTheme.typography.headlineSmall)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric(t("growth"),number(e.growth)+"%");Metric(t("inflation"),number(e.inflation)+"%");Metric(t("unemployment"),number(e.unemployment)+"%")}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric(t("interest_rate"),number(e.rate)+"%");Metric(t("liquidity"),number(e.liquidity));Metric(t("fear_index"),number(s.world.fear))}
        SectionCard(t("rate_expectations")) {
            InfoRow(t("cut_probability"),number(e.cutProbability*100)+"%");InfoRow(t("hike_probability"),number(e.hikeProbability*100)+"%")
            InfoRow(t("consensus"),number(e.expectedRate)+"%");LinearProgressIndicator(progress={e.cutProbability.toFloat()},modifier=Modifier.fillMaxWidth(),color=ChartBlue)
        }
        if(ProgressionEngine.unlocked(s,"yield_curve"))SectionCard(t("yield_curve")) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("2Y",number(e.yield2)+"%");Metric("10Y",number(e.yield10)+"%")}
            Canvas(Modifier.fillMaxWidth().height(64.dp)){val lo=minOf(e.yield2,e.yield10)-.25;val range=(maxOf(e.yield2,e.yield10)-lo+.25);drawLine(ChartBlue,Offset(20f,(size.height*(1-(e.yield2-lo)/range)).toFloat()),Offset(size.width-20,(size.height*(1-(e.yield10-lo)/range)).toFloat()),3.dp.toPx())}
            Text(t("two_yield_points"),color=Muted,style=MaterialTheme.typography.labelSmall)
        }
        TextButton(onClick={details=!details}){Text(t("macro_details"))}
        if(details)SectionCard {
            listOf("core_inflation" to e.coreInflation,"jobs" to e.jobs,"wages" to e.wages,"consumer_spending" to e.spending,"manufacturing" to e.manufacturing,"services" to e.services,"confidence" to e.confidence,"credit" to e.credit,"global_trade" to s.world.globalTrade,"supply_chains" to s.world.supplyChains).forEach {(key,value)->InfoRow(t(key),number(value))}
        }
        SectionTitle(t("calendar"),t("skip_event")){skip=true}
        val calendar=s.world.calendar.filter {it.region==region && it.time>=s.marketTime-7*86_400_000L}.sortedBy {it.time}.take(18)
        calendar.forEach {r->Surface(color=if(r.actual==null)Panel else Elevated,shape=MaterialTheme.shapes.medium){Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(t("event_"+r.type.lowercase())+if(r.symbol.isBlank())"" else " • ${r.symbol}",color=if(r.actual==null)ChartBlue else Gold);Text(dates.format(Instant.ofEpochMilli(r.time)),color=Muted,style=MaterialTheme.typography.labelSmall)}
            InfoRow(t("forecast")+" / "+t("previous"),number(r.forecast)+" / "+number(r.previous))
            r.actual?.let {InfoRow(t("actual"),number(it));Text(t(if((r.surprise ?: 0.0)>=0)"higher_expected" else "lower_expected")+" • "+number(r.surprise ?: 0.0)+"σ",color=Gold,style=MaterialTheme.typography.labelSmall)}
        }}}
        if(ProgressionEngine.unlocked(s,"sector_heatmap")){SectionTitle(t("sector_heatmap"));s.world.sectors.entries.sortedByDescending {it.value}.forEach {(sector,value)->InfoRow(sectorLabel(sector),number((value-1)*100)+"%")}}
    }
    if(skip)AlertDialog(onDismissRequest={skip=false},title={Text(t("skip_event"))},text={Text(t(if(s.positions.isNotEmpty() || s.orders.isNotEmpty())"skip_exposure_warning" else "skip_world_warning"))},confirmButton={TextButton(onClick={vm.skip();skip=false}){Text(t("advance_time"))}},dismissButton={TextButton(onClick={skip=false}){Text(t("cancel"))}})
}
@Composable fun ProgressScreen(s:GameState,vm:GameViewModel,navigate:(String)->Unit) {
    val market=vm.repository.engine.market
    ScreenColumn {
        Text(t(ProgressionEngine.rank(s,market)),style=MaterialTheme.typography.headlineMedium,color=Gold)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric(t("level"),"${s.level}");Metric("XP","${s.xp}");Metric(t("risk_health"),"${PortfolioAnalytics.health(s,market)}/100")}
        LinearProgressIndicator(progress={((s.xp-100L*(s.level-1)*(s.level-1)).toFloat()/(100L*s.level*s.level-100L*(s.level-1)*(s.level-1)).toFloat()).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth(),color=Violet)
        SectionTitle(t("analysis_tools"),t("statistics")){navigate("statistics")}
        ProgressionEngine.tools.forEach {(tool,level)->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(t(tool),color=if(ProgressionEngine.unlocked(s,tool))ChartBlue else Muted);Text(if(ProgressionEngine.unlocked(s,tool))"✓" else "LV $level",color=Gold)}}
        if(ProgressionEngine.unlocked(s,"research_terminal"))Button(onClick={navigate("research")},modifier=Modifier.fillMaxWidth()){Text(t("research_terminal"))}
        SectionTitle(t("specialties"))
        InfoRow(t("skill_points"),"${s.progression.skillPoints}")
        ProgressionEngine.specialties.forEach {key->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(t(key)+" • ${s.progression.skills[key] ?: 0}/3");TextButton(onClick={vm.specialize(key)},enabled=s.progression.skillPoints>0 && (s.progression.skills[key] ?: 0)<3){Text("+")}}}
        SectionTitle(t("challenges"))
        listOf("diversify","no_extreme_leverage","recession_survivor","safe_year","beat_benchmark","oil_shock","crypto_crash").forEach {key->Text((if(key in s.progression.completed)"✓  " else "○  ")+t("challenge_$key"),color=if(key in s.progression.completed)Gold else Muted)}
        SectionTitle(t("achievements"))
        Wealth.milestones.forEach {value->InfoRow(money(d(value)),if(value in s.achievements)"✓" else "—")}
    }
}
@Composable fun ResearchScreen(s:GameState,vm:GameViewModel) {
    var tab by remember {mutableIntStateOf(0)}
    ScreenColumn {
        if(!ProgressionEngine.unlocked(s,"research_terminal")){Text(t("tool_locked"),color=Gold);return@ScreenColumn}
        TabRow(tab){listOf("companies","crypto_market","liquidity").forEachIndexed {i,key->Tab(tab==i,{tab=i},text={Text(t(key))})}}
        if(tab==0)s.world.companies.values.sortedBy {it.symbol}.forEach {c->SectionCard {
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){AssetBadge(c.symbol,AssetKind.STOCK);Text(c.symbol,style=MaterialTheme.typography.titleLarge)}
            InfoRow("P/E",number(s.quote(c.symbol).price.toDouble()/c.eps));InfoRow(t("revenue_growth"),number(c.revenueGrowth*100)+"%");InfoRow(t("guidance"),number(c.guidance))
            TextButton(onClick={vm.research(c.symbol)},enabled=c.symbol !in s.progression.researched){Text(t("research")+" • 20 XP")}
        }}
        if(tab==1)s.world.networks.entries.sortedBy {it.key}.forEach {(symbol,n)->SectionCard {
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){AssetBadge(symbol,AssetKind.CRYPTO);Text(symbol,style=MaterialTheme.typography.titleLarge)}
            InfoRow(t("network_activity"),number(n.activity));InfoRow(t("reserves"),number(n.reserves));InfoRow(t("developer_activity"),number(n.developers));InfoRow(t("security"),number(n.security))
            TextButton(onClick={vm.research(symbol)},enabled=symbol !in s.progression.researched){Text(t("research")+" • 20 XP")}
        }}
        if(tab==2)s.world.micro.entries.sortedByDescending {it.value.volume}.take(30).forEach {(symbol,m)->SectionCard {
            Text(symbol,color=ChartBlue);InfoRow(t("depth"),money(d(m.depth)));InfoRow(t("spread"),number(m.spread*100)+"%");InfoRow(t("funding"),number(m.funding*100)+"%");InfoRow(t("open_interest"),money(d(m.openInterest)))
        }}
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AwayReportSheet(s:GameState,vm:GameViewModel) {
    val r=s.awayReport ?: return
    ModalBottomSheet(onDismissRequest={vm.dismissAway()},containerColor=Panel) {
        ScreenColumn(Modifier.heightIn(max=640.dp)) {
            Text(t("while_away"),style=MaterialTheme.typography.headlineSmall)
            Metric(t("portfolio_change"),money(d(r.after)-d(r.before)),d(r.after)>=d(r.before),true)
            InfoRow(t("from_wallet"),dates.format(Instant.ofEpochMilli(r.from)));InfoRow(t("to_wallet"),dates.format(Instant.ofEpochMilli(r.to)))
            r.moves.entries.sortedByDescending {kotlin.math.abs(it.value)}.take(5).forEach {(symbol,move)->InfoRow(symbol,number(move)+"%")}
            InfoRow(t("filled_orders"),"${r.filled}");InfoRow("SL / TP","${r.stops} / ${r.profits}");InfoRow(t("liquidated"),"${r.liquidations}")
            InfoRow(t("funding"),money(d(r.funding)));InfoRow(t("savings_profit"),money(d(r.earn)))
            s.news.filter {it.id in r.events}.take(5).forEach {Text(newsHeadline(it),color=Muted,style=MaterialTheme.typography.bodySmall)}
            Button(onClick={vm.dismissAway()},modifier=Modifier.fillMaxWidth()){Text(t("continue_game"))}
        }
    }
}
