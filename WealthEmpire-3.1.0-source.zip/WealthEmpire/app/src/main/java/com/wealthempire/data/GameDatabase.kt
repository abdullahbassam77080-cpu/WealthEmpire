package com.wealthempire.data

import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Entity(tableName="game_snapshots")
data class SnapshotEntity(@PrimaryKey val id: Int = 1, val payload: ByteArray, val updatedAt: Long)
@Entity(tableName="snapshot_chunks",primaryKeys=["snapshotId","part"])
data class SnapshotChunkEntity(val snapshotId:Int,val part:Int,val payload:ByteArray)

@Entity(tableName="event_journal")
data class JournalEntity(@PrimaryKey val sequence:Long,val kind:String,val payload:String,val createdAt:Long,val checksum:String)

@Dao
interface SnapshotDao {
    @Insert suspend fun appendJournal(event:JournalEntity)
    @Query("SELECT * FROM event_journal WHERE sequence > :after ORDER BY sequence") suspend fun journal(after:Long):List<JournalEntity>
    @Query("DELETE FROM event_journal WHERE sequence <= :through") suspend fun pruneJournal(through:Long)
    @Query("DELETE FROM event_journal") suspend fun clearJournal()
    @Query("SELECT * FROM game_snapshots WHERE id = :id") suspend fun raw(id:Int): SnapshotEntity?
    @Query("SELECT * FROM snapshot_chunks WHERE snapshotId = :id ORDER BY part") suspend fun chunks(id:Int):List<SnapshotChunkEntity>
    @Query("DELETE FROM snapshot_chunks WHERE snapshotId = :id") suspend fun deleteChunks(id:Int)
    @Query("INSERT INTO snapshot_chunks (snapshotId,part,payload) SELECT 2,part,payload FROM snapshot_chunks WHERE snapshotId=1") suspend fun copyChunksToBackup()
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insertChunks(chunks:List<SnapshotChunkEntity>)
    @Transaction suspend fun current():SnapshotEntity?=read(1)
    @Transaction suspend fun backup():SnapshotEntity?=read(2)
    private suspend fun read(id:Int):SnapshotEntity? {
        val row=raw(id) ?: return null
        if(row.payload.isNotEmpty())return row // Database v1's inline snapshots remain readable.
        return row.copy(payload=SnapshotChunks.join(chunks(id).map {it.part to it.payload}))
    }
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insert(snapshot: SnapshotEntity)
    @Transaction suspend fun save(payload: ByteArray, now: Long) {
        raw(1)?.let {deleteChunks(2);insert(it.copy(id=2));copyChunksToBackup()}
        deleteChunks(1)
        insertChunks(SnapshotChunks.split(payload).mapIndexed {i,bytes->SnapshotChunkEntity(1,i,bytes)})
        insert(SnapshotEntity(1,byteArrayOf(),now))
    }
    @Query("DELETE FROM game_snapshots") suspend fun deleteAll()
    @Query("DELETE FROM snapshot_chunks") suspend fun deleteAllChunks()
    @Transaction suspend fun reset(payload: ByteArray,now: Long) {
        deleteAll();deleteAllChunks();clearJournal();save(payload,now)
    }
}

@Database(entities=[SnapshotEntity::class,SnapshotChunkEntity::class,JournalEntity::class],version=3,exportSchema=true)
abstract class GameDatabase : RoomDatabase() {
    abstract fun snapshots(): SnapshotDao
    companion object {
        val MIGRATION_2_3=object:Migration(2,3) {override fun migrate(db:SupportSQLiteDatabase){db.execSQL("CREATE TABLE IF NOT EXISTS event_journal (sequence INTEGER NOT NULL, kind TEXT NOT NULL, payload TEXT NOT NULL, createdAt INTEGER NOT NULL, checksum TEXT NOT NULL, PRIMARY KEY(sequence))")}}
        val MIGRATION_1_2=object:Migration(1,2) {
            override fun migrate(db:SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS snapshot_chunks (snapshotId INTEGER NOT NULL, part INTEGER NOT NULL, payload BLOB NOT NULL, PRIMARY KEY(snapshotId,part))")
            }
        }
    }
}
