package com.wealthempire.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.wealthempire.core.models.*
import com.wealthempire.core.trading.*
import com.wealthempire.ui.t
import com.wealthempire.ui.theme.*

fun compactLiquidation(range:LiquidationRange?):String {
    if(range==null)return "…"
    val lower=range.lower;val upper=range.upper
    return when {
    range.unsafeNow -> "!"
    lower!=null && upper!=null -> "↓ ${money(lower)}\n↑ ${money(upper)}"
    lower!=null -> "↓ ${money(lower)}"
    upper!=null -> "↑ ${money(upper)}"
    else -> "—"
}
}

@Composable fun PositionCard(s:GameState,p:Position,range:LiquidationRange?,busy:Boolean,
    details:()->Unit,brackets:()->Unit,partial:()->Unit,close:()->Unit) {
    val mark=s.quote(p.symbol).price;val pnl=FuturesMath.pnl(p,mark)
    val direction=if(p.side==Side.LONG)Up else Down
    Card(Modifier.fillMaxWidth().testTag("position_card_${p.id}"),shape=RoundedCornerShape(14.dp),
        colors=CardDefaults.cardColors(containerColor=Panel)) {
        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                Surface(color=direction.copy(alpha=.14f),shape=RoundedCornerShape(4.dp)) {
                    Text(t(if(p.side==Side.LONG)"long" else "short"),color=direction,
                        style=MaterialTheme.typography.labelSmall,modifier=Modifier.padding(horizontal=7.dp,vertical=5.dp))
                }
                Text("${p.symbol}USDT",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f),style=MaterialTheme.typography.titleSmall)
                Text(t(if(p.mode==MarginMode.CROSS)"cross" else "isolated")+" ${p.leverage}×",color=Muted,style=MaterialTheme.typography.labelSmall)
                IconButton(onClick=details,modifier=Modifier.size(28.dp)) {
                    Icon(Icons.Outlined.Info,contentDescription=t("position_details"),tint=Muted,modifier=Modifier.size(18.dp))
                }
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                CompactField(t("pnl")+" (USDT)",money(pnl),Modifier.weight(1.3f),if(pnl>=ZERO)Up else Down,true)
                CompactField(t("roe"),percent(FuturesMath.roe(p,mark)),Modifier.weight(1f),if(pnl>=ZERO)Up else Down,true)
            }
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                CompactField(t("entry_price"),money(p.entry),Modifier.weight(1f))
                CompactField(t("mark_price"),money(mark),Modifier.weight(1f))
                CompactField(t("liquidation_price"),compactLiquidation(range),Modifier.weight(1f),Gold)
            }
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                CompactField(t("quantity")+" (${p.symbol})",qty(p.quantity),Modifier.weight(1f))
                CompactField(t("margin")+" (USDT)",money(p.margin),Modifier.weight(1f))
                CompactField(t("position_size"),money(FuturesMath.notional(p,mark)),Modifier.weight(1f))
            }
            HorizontalDivider(color=Muted.copy(alpha=.1f))
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick=brackets,enabled=!busy,modifier=Modifier.weight(1f).height(36.dp),contentPadding=PaddingValues(0.dp)) {
                    Text("TP / SL",color=if(p.takeProfit!=null || p.stopLoss!=null)Gold else Muted,style=MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(onClick=partial,enabled=!busy,modifier=Modifier.weight(1f).height(36.dp).testTag("partial_position_${p.id}"),contentPadding=PaddingValues(0.dp)) {
                    Text(t("partial_close_short"),style=MaterialTheme.typography.labelSmall)
                }
                Button(onClick=close,enabled=!busy,modifier=Modifier.weight(1f).height(36.dp).testTag("close_position_${p.id}"),
                    contentPadding=PaddingValues(0.dp),colors=ButtonDefaults.buttonColors(containerColor=Muted.copy(alpha=.12f),contentColor=MaterialTheme.colorScheme.onSurface)) {
                    Text(t("close_short"),style=MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
@Composable private fun CompactField(label:String,value:String,modifier:Modifier=Modifier,
    color:androidx.compose.ui.graphics.Color=MaterialTheme.colorScheme.onSurface,large:Boolean=false) {
    Column(modifier,verticalArrangement=Arrangement.spacedBy(3.dp)) {
        Text(label,color=Muted,style=MaterialTheme.typography.labelSmall,maxLines=2)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(value,color=color,style=if(large)MaterialTheme.typography.titleLarge else MaterialTheme.typography.bodySmall,
                fontWeight=FontWeight.SemiBold,maxLines=2)
        }
    }
}
