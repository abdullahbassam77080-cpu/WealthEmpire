package com.wealthempire.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.wealthempire.core.portfolio.PortfolioAnalytics
import com.wealthempire.core.statistics.Wealth
import com.wealthempire.core.models.*
import com.wealthempire.core.trading.FuturesMath
import com.wealthempire.ui.*
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun WalletScreen(s:GameState,vm:GameViewModel,busy:Boolean,navigate:(String)->Unit) {
    var from by rememberSaveable { mutableStateOf(Wallet.CASH) }
    var to by rememberSaveable { mutableStateOf(Wallet.FUTURES) }
    var amount by rememberSaveable { mutableStateOf("500") }
    var transfer by remember {mutableStateOf(false)}
    ScreenColumn {
        WealthHero(s)
        AllocationDonut(PortfolioAnalytics.allocation(s,vm.repository.engine.market))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric(t("risk_health"),"${PortfolioAnalytics.health(s,vm.repository.engine.market)}/100");Metric(t("realized_pnl"),money(PortfolioAnalytics.realized(s)));Metric(t("unrealized_pnl"),money(PortfolioAnalytics.unrealized(s)))}
        Button(onClick={transfer=true},modifier=Modifier.fillMaxWidth()){Text(t("transfer"))}
        Wallet.entries.forEach { w ->
            SectionCard(walletLabel(w)) {
                Metric(t("free_balance"),money(s.balance(w).positive()),large=true)
                if(w==Wallet.FUTURES) {
                    InfoRow(t("cross_equity"),money(FuturesMath.crossEquity(s)))
                    if(s.futuresCash<ZERO)InfoRow(t("settlement_debit"),money(-s.futuresCash))
                    InfoRow(t("locked_margin"),money(s.positions.fold(ZERO){a,p->a+p.margin}))
                }
                InfoRow(t("reserved_orders"),money(s.orders.filter { it.wallet==w }.fold(ZERO){a,o->a+o.reserved}))
            }
        }
        SectionCard(t("savings")) {
            Metric(t("savings_value"),money(com.wealthempire.core.statistics.Wealth.savingsValue(s)))
            InfoRow(t("savings_profit"),money(s.stats.savings))
            TextButton(onClick={navigate("savings")}){Text(t("my_savings"))}
        }
        SectionTitle(t("sector_exposure"))
        PortfolioAnalytics.sectors(s,vm.repository.engine.market).forEach {(key,value)->InfoRow(sectorLabel(key),money(d(value)))}
        SectionTitle(t("currency_exposure"))
        s.holdings.groupBy {if(vm.repository.engine.market.spec(it.symbol,s).kind==AssetKind.FOREX)it.symbol else "USD"}.forEach {(key,holdings)->
            InfoRow(key,money(holdings.fold(ZERO){v,h->v+h.quantity*s.quote(h.symbol).price}))
        }
        HoldingsPanel(s)
    }
    if(transfer)ModalBottomSheet(onDismissRequest={transfer=false},containerColor=Panel){Column(Modifier.padding(16.dp)){        SectionCard(t("transfer")) {
            Choice(t("from_wallet"),Wallet.entries.toList(),from,{from=it}) { walletLabel(it) }
            Choice(t("to_wallet"),Wallet.entries.toList(),to,{to=it}) { walletLabel(it) }
            MoneyInput(t("amount"),amount,{amount=it})
            Button(onClick={parsed(amount)?.let {vm.transfer(from,to,it)} ?: vm.events.tryEmit("invalid_amount")},
                enabled=!busy,modifier=androidx.compose.ui.Modifier.fillMaxWidth().testTag("wallet_transfer")) {Text(t("transfer_now"))}
            Text(t("cross_note"),color=Muted,style=MaterialTheme.typography.bodySmall)
        }
Spacer(Modifier.height(16.dp))}}
}
@Composable fun HoldingsPanel(s:GameState,symbols:Set<String>?=null) {
    val holdings=s.holdings.filter { symbols==null || it.symbol in symbols }
    SectionCard(t("holdings")) {
        if(holdings.isEmpty()) Text(t("no_holdings"),color=Muted)
        holdings.forEach { h ->
            val price=s.quote(h.symbol).price; val pnl=h.quantity*price-h.cost
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){AssetBadge(h.symbol);Text(h.symbol,style=MaterialTheme.typography.titleMedium)}
            InfoRow(t("quantity"),qty(h.quantity)); InfoRow(t("average"),marketPrice(h.average))
            InfoRow(t("current"),marketPrice(price))
            Metric(t("pnl"),money(pnl)+" • "+percent(if(h.cost>ZERO)pnl.divD(h.cost)*d(100) else ZERO),pnl>=ZERO)
            HorizontalDivider(color=Muted.copy(alpha=.15f))
        }
    }
}
