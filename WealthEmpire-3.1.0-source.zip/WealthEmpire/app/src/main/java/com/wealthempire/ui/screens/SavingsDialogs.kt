package com.wealthempire.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.*
import com.wealthempire.core.savings.SavingsRules
import com.wealthempire.ui.*
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable internal fun SavingsSubscription(s:GameState,symbol:String,busy:Boolean,vm:GameViewModel,navigate:(String)->Unit,dismiss:()->Unit) {
    var quantity by remember(symbol) {mutableStateOf("")};var days by remember {mutableIntStateOf(0)}
    var compound by remember {mutableStateOf(true)}
    val offer=s.savingsOffers.first {it.symbol==symbol};val available=SavingsRules.available(s,symbol)
    val amount=parsed(quantity) ?: ZERO
    val apr=when(days){30->offer.locked30Apr;90->offer.locked90Apr;else->SavingsRules.flexibleApr(s,symbol,amount)}
    ModalBottomSheet(onDismissRequest=dismiss,containerColor=Panel) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Text(t("subscribe")+" • "+symbol,style=MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {listOf(0,30,90).forEach {d->FilterChip(days==d,{days=d},label={Text(if(d==0)t("flexible") else "$d "+t("game_days"))})}}
            InfoRow(t("available_to_save"),tokenAmount(available)+" "+symbol)
            MoneyInput(t("quantity")+" ($symbol)",quantity,{quantity=it},Modifier.testTag("savings_quantity"))
            TextButton(onClick={quantity=available.stripTrailingZeros().toPlainString()}) {Text("MAX")}
            Metric(if(days==0)t("variable_apr") else t("fixed_apr"),percent(apr),true)
            InfoRow(t("estimated_daily_reward"),tokenAmount(SavingsRules.dailyEstimate(s,symbol,amount,days))+" "+symbol)
            if(days==0) {
                InfoRow(t("base_apr"),percent(offer.baseApr));InfoRow(t("bonus_apr"),percent(offer.bonusApr)+" / "+tokenAmount(offer.bonusQuota)+" "+symbol)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {Text(t("auto_compound"));Switch(compound,{compound=it})}
            }
            Text(t(if(days==0)"flexible_rules" else "locked_rules"),color=Muted,style=MaterialTheme.typography.bodySmall)
            Text(t("annual_apr_note"),color=Gold,style=MaterialTheme.typography.labelSmall)
            Button(onClick={vm.subscribeSavings(symbol,amount,days,compound);dismiss()},enabled=!busy && amount>ZERO && amount<=available,modifier=Modifier.fillMaxWidth().testTag("confirm_savings")) {Text(t("confirm"))}
            if(available==ZERO)TextButton(onClick={dismiss();navigate(if(symbol=="USDT")"wallet" else "trade/$symbol")}) {Text(t(if(symbol=="USDT")"transfer" else "buy_asset_first"))}
            Spacer(Modifier.height(24.dp))
        }
    }
}
@Composable internal fun SavingsRedemption(p:SavingsPosition,busy:Boolean,vm:GameViewModel,dismiss:()->Unit) {
    var fraction by remember {mutableStateOf(ONE)}
    AlertDialog(onDismissRequest=dismiss,title={Text(t("redeem")+" • "+p.symbol)},text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            if(p.days==0)Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {listOf("0.25","0.5","1").forEach {value->val f=d(value);FilterChip(fraction==f,{fraction=f},label={Text(percent(f*d(100)))})}}
            InfoRow(t("returned_quantity"),tokenAmount(if(p.days==0)(p.principal+p.rewards)*fraction else (p.principal-p.distributed).positive())+" "+p.symbol)
            if(p.days>0) {Text(t("early_redemption_rules"),color=Gold);InfoRow(t("forfeited_rewards"),tokenAmount(p.rewards+p.distributed)+" "+p.symbol)}
        }
    },confirmButton={TextButton(onClick={vm.redeemSavings(p.id,fraction);dismiss()},enabled=!busy,modifier=Modifier.testTag("confirm_redeem")) {Text(t("confirm"))}},dismissButton={TextButton(onClick=dismiss){Text(t("cancel"))}})
}
