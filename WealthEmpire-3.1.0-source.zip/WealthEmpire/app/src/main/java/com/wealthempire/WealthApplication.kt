package com.wealthempire

import android.app.Application
import androidx.room.Room
import com.wealthempire.data.*
import com.wealthempire.repository.GameRepository
import kotlinx.coroutines.*
import kotlinx.serialization.json.Json
import com.wealthempire.core.models.AssetSpec

class WealthApplication : Application() {
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.IO)
    val database by lazy { Room.databaseBuilder(this,GameDatabase::class.java,"wealth-empire.db").addMigrations(GameDatabase.MIGRATION_1_2,GameDatabase.MIGRATION_2_3).build() }
    val repository by lazy {
        val catalog=Json.decodeFromString<List<AssetSpec>>(assets.open("markets.json").bufferedReader().use { it.readText() })
        GameRepository(database.snapshots(),scope,catalog,settings)
    }
    val settings by lazy { SettingsStore(this) }
}
