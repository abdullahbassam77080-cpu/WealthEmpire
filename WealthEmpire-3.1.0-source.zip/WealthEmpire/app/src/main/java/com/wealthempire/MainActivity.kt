package com.wealthempire

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.wealthempire.ui.GameViewModel
import com.wealthempire.navigation.EmpireApp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo=(application as WealthApplication).repository
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                try {
                    runCatching {repo.session()}.onFailure {if(it is kotlinx.coroutines.CancellationException)throw it}
                } finally {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {runCatching {repo.checkpoint()}}
                }
            }
        }
        setContent { val vm:GameViewModel=viewModel();EmpireApp(vm) }
    }
}
