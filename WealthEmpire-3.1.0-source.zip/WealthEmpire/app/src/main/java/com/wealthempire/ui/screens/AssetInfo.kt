package com.wealthempire.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import com.wealthempire.core.models.*
import com.wealthempire.core.progression.ProgressionEngine
import com.wealthempire.ui.GameViewModel
import com.wealthempire.ui.t
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*
import java.util.Locale

@Composable fun AssetInfo(s:GameState,a:AssetSpec,vm:GameViewModel) {
    fun n(v:Double)=String.format(Locale.US,"%.2f",v)
    SectionCard(t("market_details")) {
        InfoRow(t("market_cap"),money(a.marketCap*s.quote(a.symbol).price.divD(a.initialPrice)))
        s.world.companies[a.symbol]?.let {c->
            listOf("revenue" to c.revenue,"eps" to c.eps,"margin" to c.margin*100,"debt" to c.debt,"company_cash" to c.cash,"guidance" to c.guidance,"market_share" to c.marketShare*100,"revenue_growth" to c.revenueGrowth*100).forEach {(key,value)->InfoRow(t(key),when(key){"revenue","debt","company_cash"->compactMoney(d(value)*d(1000000));"eps"->money(d(value));"margin","market_share","revenue_growth","staking","btc_dominance"->n(value)+"%";else->n(value)})}
            InfoRow("P/E",n(s.quote(a.symbol).price.toDouble()/c.eps));InfoRow(t("sector"),sectorLabel(c.sector))
            if(ProgressionEngine.unlocked(s,"earnings")){InfoRow(t("forecast_eps"),n(c.forecastEps));InfoRow(t("forecast_revenue"),compactMoney(d(c.forecastRevenue)*d(1000000)));c.actualEps?.let {InfoRow(t("actual_eps"),n(it))};c.actualRevenue?.let {InfoRow(t("actual_revenue"),compactMoney(d(it)*d(1000000)))}}
        }
        s.world.networks[a.symbol]?.let {network->
            listOf("network_activity" to network.activity,"developer_activity" to network.developers,"security" to network.security,"reserves" to network.reserves,"staking" to network.staking*100,"unlock_pressure" to network.unlockPressure,"institutional_demand" to network.institutional,"btc_dominance" to s.world.btcDominance*100,"stablecoin_liquidity" to s.world.stablecoinLiquidity,"etf_flows" to s.world.etfFlows,"regulation" to s.world.regulation).forEach {(key,value)->InfoRow(t(key),when(key){"revenue","debt","company_cash"->compactMoney(d(value)*d(1000000));"eps"->money(d(value));"margin","market_share","revenue_growth","staking","btc_dominance"->n(value)+"%";else->n(value)})}
        }
        if(a.kind==AssetKind.COMMODITY){val c=s.world.commodities
            val metrics=when(a.sector){"energy"->listOf("supply" to c.oilSupply,"demand" to c.oilDemand,"inventories" to c.inventories,"production" to c.production,"shipping" to c.shipping);"gas"->listOf("storage" to c.gasStorage,"production" to c.gasProduction,"winter_demand" to c.winterDemand,"lng_exports" to c.lng);else->listOf("gold_demand" to c.goldDemand,"fear_index" to s.world.fear,"real_yield" to ((s.world.economies["USA"]?.yield10 ?: 0.0)-(s.world.economies["USA"]?.inflation ?: 0.0)))}
            metrics.forEach {(key,value)->InfoRow(t(key),when(key){"revenue","debt","company_cash"->compactMoney(d(value)*d(1000000));"eps"->money(d(value));"margin","market_share","revenue_growth","staking","btc_dominance"->n(value)+"%";else->n(value)})}
        }
        if(a.kind==AssetKind.FOREX || a.kind==AssetKind.BOND){s.world.economies.values.forEach {e->InfoRow(t(e.region.lowercase()),n(e.rate)+"% • "+n(e.growth)+"%")}}
        s.world.micro[a.symbol]?.let {m->
            InfoRow(t("spread"),n(m.spread*100)+"%");InfoRow(t("depth"),money(d(m.depth)));InfoRow(t("volume"),money(d(m.volume)))
            if(ProgressionEngine.unlocked(s,"funding"))InfoRow(t("funding"),n(m.funding*100)+"%")
            if(ProgressionEngine.unlocked(s,"open_interest")){InfoRow(t("open_interest"),money(d(m.openInterest)));InfoRow(t("long_share"),n(m.longFraction*100)+"%");InfoRow(t("basis"),n(m.basis*100)+"%");InfoRow(t("liquidation_cluster"),marketPrice(d(m.liquidationCluster)))}
        }
        TextButton(onClick={vm.research(a.symbol)},enabled=a.symbol !in s.progression.researched){Text(t("research")+" • 20 XP")}
    }
}
