package com.wealthempire.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.wealthempire.core.models.*
import com.wealthempire.core.market.GameClock
import com.wealthempire.core.savings.SavingsRules
import com.wealthempire.core.statistics.Wealth
import com.wealthempire.ui.*
import com.wealthempire.ui.components.*
import com.wealthempire.ui.theme.*
import java.time.*
import java.time.format.DateTimeFormatter

@Composable fun SavingsScreen(s:GameState,vm:GameViewModel,busy:Boolean,navigate:(String)->Unit) {
    var tab by remember {mutableIntStateOf(0)}
    var subscription by remember {mutableStateOf<String?>(null)}
    var redemption by remember {mutableStateOf<Long?>(null)}
    val formatter=remember {DateTimeFormatter.ofPattern("MM-dd HH:mm 'UTC'").withZone(ZoneOffset.UTC)}
    val now=GameClock.visualTime(s,System.currentTimeMillis())
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {SectionCard {
            Metric(t("savings_value"),money(Wealth.savingsValue(s)),large=true)
            InfoRow(t("savings_profit"),money(s.stats.savings))
            Text(t("savings_virtual_note"),color=Muted,style=MaterialTheme.typography.labelSmall)
            TabRow(tab) {listOf("earn_products","my_savings","earn_history").forEachIndexed {i,key->Tab(tab==i,{tab=i},text={Text(t(key))},modifier=Modifier.testTag("savings_tab_$i"))}}
        }}
        if(tab==0) {
            item {Text(t("annual_apr_note"),color=Muted,style=MaterialTheme.typography.bodySmall)}
            items(s.savingsOffers,key={it.symbol}) {offer ->
                SectionCard {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){AssetBadge(offer.symbol,AssetKind.CRYPTO);Text(offer.symbol,style=MaterialTheme.typography.titleLarge)}
                        Metric(t("up_to_apr"),percent(maxOf(offer.baseApr+offer.bonusApr,offer.locked30Apr,offer.locked90Apr)),true)
                    }
                    InfoRow(t("available_to_save"),tokenAmount(SavingsRules.available(s,offer.symbol))+" "+offer.symbol)
                    InfoRow(t("flexible"),percent(offer.baseApr)+" + "+percent(offer.bonusApr))
                    InfoRow("30 / 90 "+t("game_days"),percent(offer.locked30Apr)+" / "+percent(offer.locked90Apr))
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {Text(t("flexible")+" • 30d • 90d",color=Muted,style=MaterialTheme.typography.labelSmall)}
                    Button(onClick={subscription=offer.symbol},enabled=!busy,modifier=Modifier.fillMaxWidth().testTag("subscribe_${offer.symbol}")) {Text(t("subscribe"))}
                }
            }
        } else if(tab==1) {
            if(s.savings.isEmpty())item {Text(t("no_savings"),color=Muted)}
            items(s.savings,key={it.id}) {p ->
                SectionCard {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(p.symbol,style=MaterialTheme.typography.titleLarge)
                        Text(if(p.status==SavingsStatus.REDEEMING)t("redemption_pending") else if(p.days==0)t("flexible") else "${p.days} "+t("game_days"),color=Gold)
                    }
                    InfoRow(t("principal"),tokenAmount(p.principal)+" "+p.symbol)
                    InfoRow(t("accrued_rewards"),tokenAmount(p.rewards)+" "+p.symbol)
                    if(p.days>0)InfoRow(t("distributed_rewards"),tokenAmount(p.distributed)+" "+p.symbol)
                    Metric(t("current_value"),money((p.principal+p.rewards)*s.quote(p.symbol).price))
                    InfoRow("APR",percent(if(p.days==0)SavingsRules.flexibleApr(s,p.symbol) else p.fixedApr))
                    if(p.status==SavingsStatus.REDEEMING)InfoRow(t("remaining_game_time"),durationLabel(p.redeemAt-now))
                    else {
                        if(p.days>0)LinearProgressIndicator(progress={((now-p.subscribedAt).toDouble()/(p.maturesAt-p.subscribedAt)).toFloat().coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth())
                        if(p.days>0)InfoRow(t("matures_at"),formatter.format(Instant.ofEpochMilli(p.maturesAt)))
                        OutlinedButton(onClick={redemption=p.id},enabled=!busy,modifier=Modifier.fillMaxWidth().testTag("redeem_${p.id}")) {Text(t("redeem"))}
                    }
                }
            }
        } else {
            if(s.savingsHistory.isEmpty())item {Text(t("no_history"),color=Muted)}
            items(s.savingsHistory,key={it.id}) {record ->
                SectionCard {
                    Text(record.symbol+" • "+t("earn_"+record.action.lowercase()),color=if(record.action=="FORFEIT")Down else Gold)
                    Text(tokenAmount(record.quantity)+" "+record.symbol)
                    Text(formatter.format(Instant.ofEpochMilli(record.time)),color=Muted,style=MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
    subscription?.let {SavingsSubscription(s,it,busy,vm,navigate){subscription=null}}
    s.savings.firstOrNull {it.id==redemption}?.let {p->SavingsRedemption(p,busy,vm){redemption=null}}
}
