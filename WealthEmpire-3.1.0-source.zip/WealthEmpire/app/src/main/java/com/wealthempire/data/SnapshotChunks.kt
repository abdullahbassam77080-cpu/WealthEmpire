package com.wealthempire.data

/** Keep each Room cursor row below the smallest supported Android CursorWindow size. */
object SnapshotChunks {
    const val SIZE=256*1024
    fun split(payload:ByteArray):List<ByteArray> {
        require(payload.isNotEmpty()){"empty_snapshot"}
        return (payload.indices step SIZE).map {start->payload.copyOfRange(start,minOf(start+SIZE,payload.size))}
    }
    fun join(parts:List<Pair<Int,ByteArray>>):ByteArray {
        require(parts.isNotEmpty() && parts.map {it.first}==parts.indices.toList()){"snapshot_chunks_missing"}
        require(parts.all {it.second.isNotEmpty() && it.second.size<=SIZE}){"snapshot_chunks_invalid"}
        val output=ByteArray(parts.sumOf {it.second.size});var offset=0
        parts.forEach {(_,bytes)->bytes.copyInto(output,offset);offset+=bytes.size}
        return output
    }
}
