package com.wealthempire.ui.components

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.*
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.*
import com.wealthempire.core.market.Indicators
import com.wealthempire.core.models.Candle
import com.wealthempire.ui.t
import com.wealthempire.ui.theme.*
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.*

@Composable fun CandleChart(bars: List<Candle>, enabled: Set<String>, chartKey: String = "default") {
    var viewport by remember(chartKey) { mutableStateOf(ChartViewport()) }
    var selectedTime by remember(chartKey) { mutableStateOf<Long?>(null) }
    var canvasWidth by remember { mutableIntStateOf(0) }
    val times = remember(bars) { bars.map { it.time } }
    val range = viewport.range(times)
    val visible = bars.subList(range.start, range.end)
    val values = remember(bars) { Indicators.closes(bars) }
    val ema20 = remember(values,"EMA20" in enabled) { if("EMA20" in enabled)Indicators.ema(values, 20) else emptyList() }
    val ema50 = remember(values,"EMA50" in enabled) { if("EMA50" in enabled)Indicators.ema(values, 50) else emptyList() }
    val ema200 = remember(values,"EMA200" in enabled) { if("EMA200" in enabled)Indicators.ema(values, 200) else emptyList() }
    val boll = remember(values,"Bollinger" in enabled) { if("Bollinger" in enabled)Indicators.bollinger(values) else emptyList<Double?>() to emptyList() }
    val rsi = remember(values,"RSI" in enabled) { if("RSI" in enabled)Indicators.rsi(values) else emptyList() }
    val macd = remember(values,"MACD" in enabled) { if("MACD" in enabled)Indicators.macd(values) else Indicators.Macd(emptyList(),emptyList(),emptyList()) }
    val density = LocalDensity.current
    val selected = selectedTime?.let { time -> visible.firstOrNull { it.time == time } }
    val candle = selected ?: bars.lastOrNull()
    val min = visible.minOfOrNull { it.low.toDouble() } ?: 0.0
    val max = visible.maxOfOrNull { it.high.toDouble() } ?: 1.0
    val pad = kotlin.math.max((max - min) * .08, abs(max) * .00005).coerceAtLeast(.000000000001)
    val low = min - pad
    val spread = max - min + pad * 2
    val decimals = chartPriceDecimals(max, spread / 4)
    val axisLabels = (0..4).map { chartPrice(low + spread * (1 - it / 4.0), decimals) }
    val axisPaint = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Muted.toArgb(); textSize = with(density) { 10.sp.toPx() } }
    }
    val axisWidth = with(density) { kotlin.math.max(64.dp.toPx(), axisLabels.maxOf { axisPaint.measureText(it) } + 12.dp.toPx()).toDp() }
    val plotWidth = (canvasWidth - with(density) { axisWidth.toPx() }).coerceAtLeast(1f)
    val hint = t("chart_hint")
    val inspectionFormatter = remember { DateTimeFormatter.ofPattern("MM-dd HH:mm", Locale.US).withZone(ZoneOffset.UTC) }
    val viewportLabel = t(if(viewport.rightEdgeTime==null) "chart_live" else "chart_history") +
        (visible.lastOrNull()?.let { " • " + inspectionFormatter.format(Instant.ofEpochMilli(it.time)) } ?: "")
    val volumeEnabled = "Volume" in enabled
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        // Inspect OHLC on demand; the normal view keeps space for candles and positions.
        if (candle != null) {
            if(selected!=null) Text(inspectionFormatter.format(Instant.ofEpochMilli(selected.time))+" UTC",color=Muted,style=MaterialTheme.typography.labelSmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                val color = if (candle.close >= candle.open) Up else Down
                listOf("O" to candle.open, "H" to candle.high, "L" to candle.low, "C" to candle.close).forEach { (label, value) ->
                    Column { Text(label, color = Muted, style = MaterialTheme.typography.labelSmall)
                        Text(chartPrice(value.toDouble(), decimals), color = color, style = MaterialTheme.typography.labelSmall) }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                val legend = listOf("EMA20" to Gold, "EMA50" to ChartBlue, "EMA200" to Color(0xFFC28EFF))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    legend.filter { it.first in enabled }.forEach { (label, color) -> Text(label, color = color, style = MaterialTheme.typography.labelSmall) }
                    if ("Bollinger" in enabled) Text("BOLL", color = Muted, style = MaterialTheme.typography.labelSmall)
                }
                Text("VOL ${chartVolume(candle.volume.toDouble())}", color = Muted, style = MaterialTheme.typography.labelSmall)
            }
        }
        Canvas(Modifier.fillMaxWidth().height(if (volumeEnabled) 264.dp else 224.dp)
            .testTag("candle_chart").semantics { contentDescription = hint; stateDescription = viewportLabel }
            .onSizeChanged { canvasWidth = it.width }
            .chartGestures(chartKey, onTransform = { pan, zoom, focus ->
                selectedTime = null
                viewport = viewport.transform(times, pan, plotWidth, zoom, focus / plotWidth)
            }, onTap = { point ->
                if (point.x in 0f..plotWidth && visible.isNotEmpty()) {
                    val index = (point.x / plotWidth * visible.size).toInt().coerceIn(0, visible.lastIndex)
                    val time = visible[index].time
                    selectedTime = if (selectedTime == time) null else time
                }
            })) {
            if (visible.isEmpty()) return@Canvas
            val w = (size.width - axisWidth.toPx()).coerceAtLeast(1f)
            val timeHeight = 22.dp.toPx()
            val volumeHeight = if (volumeEnabled) 40.dp.toPx() else 0f
            val h = size.height - timeHeight - volumeHeight - 8.dp.toPx()
            val step = w / visible.size
            fun y(value: Double) = h - ((value - low) / spread * h).toFloat()
            val dashed = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 4.dp.toPx()))
            repeat(5) { n ->
                val yy = 4.dp.toPx() + n * (h - 8.dp.toPx()) / 4
                drawLine(Muted.copy(alpha = .12f), Offset(0f, yy), Offset(w, yy), 1f)
                val value = low + spread * (1 - yy / h)
                drawContext.canvas.nativeCanvas.drawText(chartPrice(value, decimals), w + 6.dp.toPx(), yy + 3.dp.toPx(), axisPaint)
            }
            clipRect(0f, 0f, w, h) {
                visible.forEachIndexed { i, c ->
                    val x = step * (i + .5f)
                    val color = if (c.close >= c.open) Up else Down
                    drawLine(color, Offset(x, y(c.high.toDouble())), Offset(x, y(c.low.toDouble())), 1.dp.toPx())
                    val top = minOf(y(c.open.toDouble()), y(c.close.toDouble()))
                    val bottom = maxOf(y(c.open.toDouble()), y(c.close.toDouble()))
                    drawRect(color, Offset(x - step * .32f, top), Size(step * .64f, (bottom - top).coerceAtLeast(1.dp.toPx())))
                }
                fun line(series: List<Double?>, color: Color) {
                    var previous: Offset? = null
                    for (i in range.start until range.end) {
                        val value = series.getOrNull(i)
                        if (value == null) { previous = null; continue }
                        val point = Offset(step * (i - range.start + .5f), y(value))
                        previous?.let { drawLine(color, it, point, 1.dp.toPx()) }
                        previous = point
                    }
                }
                if ("EMA20" in enabled) line(ema20, Gold)
                if ("EMA50" in enabled) line(ema50, ChartBlue)
                if ("EMA200" in enabled) line(ema200, Color(0xFFC28EFF))
                if ("Bollinger" in enabled) { line(boll.first, Muted); line(boll.second, Muted) }
                selected?.let {
                    val x = step * (visible.indexOf(it) + .5f)
                    drawLine(Muted, Offset(x, 0f), Offset(x, h), 1f, pathEffect = dashed)
                    drawLine(Muted, Offset(0f, y(it.close.toDouble())), Offset(w, y(it.close.toDouble())), 1f, pathEffect = dashed)
                }
            }
            val latest = bars.last()
            val markY = y(latest.close.toDouble())
            if (markY in 0f..h) {
                val color = if (latest.close >= latest.open) Up else Down
                drawLine(color.copy(alpha = .6f), Offset(0f, markY), Offset(w, markY), 1f, pathEffect = dashed)
                val labelY = markY.coerceIn(10.dp.toPx(), h - 10.dp.toPx())
                drawRoundRect(color, Offset(w + 2.dp.toPx(), labelY - 9.dp.toPx()), Size(axisWidth.toPx() - 2.dp.toPx(), 18.dp.toPx()), androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()))
                val labelPaint = Paint(axisPaint).apply { this.color = Background.toArgb() }
                drawContext.canvas.nativeCanvas.drawText(chartPrice(latest.close.toDouble(), decimals), w + 6.dp.toPx(), labelY + 3.dp.toPx(), labelPaint)
            }
            if (volumeEnabled) {
                val baseline = size.height - timeHeight
                val maxVolume = visible.maxOf { it.volume.toDouble() }.coerceAtLeast(1.0)
                drawLine(Muted.copy(alpha = .15f), Offset(0f, h + 5.dp.toPx()), Offset(w, h + 5.dp.toPx()), 1f)
                visible.forEachIndexed { i, c ->
                    val vh = (c.volume.toDouble() / maxVolume * (volumeHeight - 4.dp.toPx())).toFloat()
                    drawRect((if (c.close >= c.open) Up else Down).copy(alpha = .35f), Offset(step * (i + .18f), baseline - vh), Size(step * .64f, vh))
                }
            }
            val pattern = when {
                chartKey.endsWith(":1440") -> "MM-dd"
                visible.last().time-visible.first().time >= 86_400_000 -> "MM-dd HH:mm"
                else -> "HH:mm"
            }
            val formatter = DateTimeFormatter.ofPattern(pattern, Locale.US).withZone(ZoneOffset.UTC)
            val labelWidth = axisPaint.measureText(formatter.format(Instant.ofEpochMilli(visible.last().time)))
            val labelIndices = (if(labelWidth*3+24.dp.toPx()>w) listOf(0,visible.lastIndex) else listOf(0,visible.lastIndex/2,visible.lastIndex)).distinct()
            labelIndices.forEach { index ->
                val text = formatter.format(Instant.ofEpochMilli(visible[index].time))
                val x = (step * (index + .5f) - axisPaint.measureText(text) / 2).coerceIn(0f, (w - axisPaint.measureText(text)).coerceAtLeast(0f))
                drawContext.canvas.nativeCanvas.drawText(text, x, size.height - 4.dp.toPx(), axisPaint)
            }
        }
        if ("RSI" in enabled) IndicatorChart(rsi.subList(range.start, range.end), "RSI 14", Gold, axisWidth, 0.0, 100.0)
        if ("MACD" in enabled) IndicatorChart(macd.line.subList(range.start, range.end), "MACD 12/26/9", ChartBlue, axisWidth,
            second = macd.signal.subList(range.start, range.end), histogram = macd.histogram.subList(range.start, range.end))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { viewport = viewport.copy(rightEdgeTime = null, panRemainder = 0.0); selectedTime = null }, modifier = Modifier.testTag("chart_latest")) { Text(t("chart_latest")) }
            Row {
                IconButton(onClick = { viewport = viewport.transform(times, 0f, plotWidth, .8f); selectedTime = null }) { Icon(Icons.Outlined.Remove, t("chart_zoom_out")) }
                IconButton(onClick = { viewport = viewport.transform(times, 0f, plotWidth, 1.25f); selectedTime = null }) { Icon(Icons.Outlined.Add, t("chart_zoom_in")) }
            }
        }
    }
}
