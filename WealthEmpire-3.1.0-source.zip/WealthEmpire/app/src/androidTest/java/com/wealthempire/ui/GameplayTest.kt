package com.wealthempire.ui

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.wealthempire.MainActivity
import com.wealthempire.WealthApplication
import com.wealthempire.core.models.d
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.runner.RunWith

/** End-to-end user path, exercising UI -> ViewModel -> repository -> Room -> engine. */
@RunWith(AndroidJUnit4::class)
class GameplayTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    private fun label(key:String)=message(compose.activity.createConfigurationContext(android.content.res.Configuration(compose.activity.resources.configuration).apply {setLocale(java.util.Locale.ENGLISH)}),key)
    @Test fun transferEnterTradeCloseAndPersist() {
        val repo=(compose.activity.application as WealthApplication).repository
        compose.waitUntil(90000) {repo.state.value != null}
        runBlocking {repo.reset();repo.setSpeed(0);(compose.activity.application as WealthApplication).settings.setLanguage("en")}
        compose.waitForIdle()
        compose.onNodeWithTag("nav_mining").assertDoesNotExist()
        Assert.assertEquals(d(20000),repo.state.value!!.cash)
        compose.onNodeWithTag("nav_wallet").performClick()
        compose.onNodeWithText(label("transfer")).performScrollTo().performClick()
        compose.onNodeWithTag("wallet_transfer").performClick()
        compose.waitUntil(30000) {repo.state.value?.futuresCash == d("500.00000000")}
        Assert.assertTrue(androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().uiAutomation.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK))
        compose.waitForIdle()
        compose.onNodeWithTag("nav_crypto").performClick()
        compose.onNodeWithText("BTC").performClick()
        compose.onNodeWithText(label("futures")).performScrollTo().performClick()
        compose.onNodeWithText(label("trade")).performScrollTo().performClick()
        compose.onNodeWithTag("submit_order").performScrollTo().performClick()
        compose.waitUntil(30000) {repo.state.value?.positions?.size == 1}
        val position=repo.state.value!!.positions.single()
        compose.onNodeWithText(label("positions")).performScrollTo().performClick()
        Assert.assertEquals(5,position.leverage)
        compose.onNodeWithTag("partial_position_${position.id}").performScrollTo().performClick()
        compose.onNodeWithTag("confirm_partial_close").performClick()
        compose.waitUntil(30000) {repo.state.value?.stats?.trades == 1}
        Assert.assertTrue((repo.state.value!!.positions.single().quantity-position.quantity*d("0.75")).abs()<d("0.000000001"))
        compose.onNodeWithTag("close_position_${position.id}").performScrollTo().performClick()
        compose.waitUntil(30000) {repo.state.value?.positions?.isEmpty() == true}
        Assert.assertEquals(2,repo.state.value!!.stats.trades)
        val saved=runBlocking {repo.checkpoint();(compose.activity.application as WealthApplication).database.snapshots().current()!!}
        val reloaded=com.wealthempire.data.SnapshotCodec.decode(saved.payload)
        Assert.assertTrue(reloaded.positions.isEmpty())
        Assert.assertEquals(2,reloaded.stats.trades)
    }
}
