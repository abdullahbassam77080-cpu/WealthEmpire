package com.wealthempire.ui

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.wealthempire.MainActivity
import com.wealthempire.WealthApplication
import com.wealthempire.core.models.*
import com.wealthempire.core.wallet.WalletRules
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ExpansionGameplayTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    private fun label(key:String)=message(compose.activity.createConfigurationContext(android.content.res.Configuration(compose.activity.resources.configuration).apply {setLocale(java.util.Locale.ENGLISH)}),key)
    @Test fun tokenSavingsSubscriptionPartialReturnAndNewNavigation() {
        val repo=(compose.activity.application as WealthApplication).repository
        compose.waitUntil(90000){repo.state.value!=null}
        runBlocking {
            repo.reset();repo.setSpeed(0);(compose.activity.application as WealthApplication).settings.setLanguage("en")
            repo.command {s->WalletRules.transfer(s,Wallet.CASH,Wallet.SPOT,d(500));repo.engine.trading.submit(s,"BTC",OrderVenue.SPOT,OrderKind.MARKET,Side.LONG,d(100))}
        }
        compose.onNodeWithTag("nav_lucky").assertDoesNotExist()
        compose.onNodeWithTag("nav_dashboard").performClick()
        compose.onNodeWithText(label("savings")).performScrollTo().performClick()
        compose.onNodeWithTag("subscribe_BTC").performScrollTo().performClick()
        compose.onNodeWithTag("savings_quantity").performTextInput("0.001")
        compose.onNodeWithTag("confirm_savings").performScrollTo().performClick()
        compose.waitUntil(30000){repo.state.value?.savings?.size==1}
        val id=repo.state.value!!.savings.single().id
        compose.onNodeWithTag("savings_tab_1").performScrollTo().performClick()
        compose.onNodeWithTag("redeem_$id").performScrollTo().performClick()
        compose.onNodeWithText("25.00%").performClick()
        compose.onNodeWithTag("confirm_redeem").performClick()
        compose.waitUntil(30000){repo.state.value?.savings?.single()?.principal==d("0.00075")}
        compose.onNodeWithTag("nav_crypto").performClick()
        compose.onNodeWithTag("category_commodities").performClick()
        compose.onNodeWithText("XAU").performClick()
        compose.onNodeWithTag("asset_picker").assertIsDisplayed()
        compose.onNodeWithTag("nav_dashboard").performClick()
        compose.onNodeWithText(label("listings")).performScrollTo().performClick()
        Assert.assertTrue(repo.state.value!!.listings.isNotEmpty())
        val saved=runBlocking {repo.checkpoint();(compose.activity.application as WealthApplication).database.snapshots().current()!!}
        Assert.assertEquals(d("0.00075"),com.wealthempire.data.SnapshotCodec.decode(saved.payload).savings.single().principal)
    }
}
