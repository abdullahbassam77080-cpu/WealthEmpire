package com.wealthempire.ui

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.wealthempire.core.models.*
import com.wealthempire.ui.components.CandleChart
import com.wealthempire.ui.theme.EmpireTheme
import org.junit.*
import org.junit.runner.RunWith

/** Real pointer dispatch through the chart nested inside the same vertical-scroll container. */
@RunWith(AndroidJUnit4::class)
class ChartScrollTest {
    @get:Rule val compose = createComposeRule()
    private lateinit var scroll: ScrollState
    private var candles by mutableStateOf(history())
    private fun history() = (0L until 200L).map { i ->
        val open = d(62000 + i * 2)
        Candle(i * 60_000,open,open+d(4),open-d(2),open+d(2),d(1000))
    }
    private fun mount() {
        compose.setContent { EmpireTheme {
            scroll = rememberScrollState()
            Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
                CandleChart(candles,setOf("EMA20","Volume"),"BTC:1")
                Spacer(Modifier.height(600.dp))
                Text("Positions",modifier=Modifier.testTag("positions"))
                Spacer(Modifier.height(600.dp))
            }
        } }
    }
    private fun viewportLabel() = compose.onNodeWithTag("candle_chart").fetchSemanticsNode().config[SemanticsProperties.StateDescription]
    @Test fun swipeOverCandlesScrollsParentWithoutMovingChart() {
        mount()
        val initial = viewportLabel()
        compose.onNodeWithTag("candle_chart").performTouchInput { swipeUp() }
        compose.runOnIdle { Assert.assertTrue("Vertical chart swipe must scroll the page",scroll.value > 0) }
        Assert.assertEquals(initial,viewportLabel())
    }
    @Test fun horizontalSwipePansCandlesWithoutScrollingParentAndLatestRestores() {
        mount()
        val initial = viewportLabel()
        compose.onNodeWithTag("candle_chart").performTouchInput {
            swipe(Offset(width*.2f,height*.5f),Offset(width*.65f,height*.5f))
        }
        compose.runOnIdle { Assert.assertEquals(0,scroll.value) }
        Assert.assertNotEquals(initial,viewportLabel())
        compose.onNodeWithTag("chart_latest").performClick()
        Assert.assertEquals(initial,viewportLabel())
    }
    @Test fun marketTickDoesNotCancelAnActiveDrag() {
        mount()
        val initial = viewportLabel()
        compose.onNodeWithTag("candle_chart").performTouchInput {
            down(Offset(width*.2f,height*.5f));moveTo(Offset(width*.35f,height*.5f))
        }
        val afterFirstMove = viewportLabel()
        compose.runOnIdle { candles = candles + candles.last().copy(time=candles.last().time+60_000) }
        compose.onNodeWithTag("candle_chart").performTouchInput { moveTo(Offset(width*.65f,height*.5f));up() }
        Assert.assertNotEquals(initial,viewportLabel())
        Assert.assertNotEquals("Drag must continue after a market tick",afterFirstMove,viewportLabel())
        compose.runOnIdle { Assert.assertEquals(0,scroll.value) }
    }
}
