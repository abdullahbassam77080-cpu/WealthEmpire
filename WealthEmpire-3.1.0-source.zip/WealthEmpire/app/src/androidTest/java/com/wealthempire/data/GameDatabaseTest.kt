package com.wealthempire.data

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.wealthempire.core.GameEngine
import com.wealthempire.core.models.d
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import org.junit.*
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class GameDatabaseTest {
    private lateinit var db:GameDatabase
    @Before fun create() {db=Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(),GameDatabase::class.java).build()}
    @After fun close(){db.close()}
    @Test fun roomPersistsCurrentBackupAndResetAtomically()=runBlocking {
        val state=GameEngine().newGame(1000,42);val dao=db.snapshots()
        dao.save(SnapshotCodec.encode(state),1000)
        state.cash=d("1234.56789012");dao.save(SnapshotCodec.encode(state),2000)
        Assert.assertEquals(state.cash,SnapshotCodec.decode(dao.current()!!.payload).cash)
        Assert.assertEquals(d(20000),SnapshotCodec.decode(dao.backup()!!.payload).cash)
        dao.reset(SnapshotCodec.encode(GameEngine().newGame(3000,43)),3000)
        Assert.assertNull(dao.backup());Assert.assertEquals(d(20000),SnapshotCodec.decode(dao.current()!!.payload).cash)
    }
    @Test fun multiMegabyteCurrentAndBackupStayInBoundedRows()=runBlocking {
        val dao=db.snapshots();val a=ByteArray(3*1024*1024+19){(it*17).toByte()}
        val b=ByteArray(a.size){(it*31).toByte()}
        dao.save(a,1);dao.save(b,2)
        Assert.assertArrayEquals(b,dao.current()!!.payload);Assert.assertArrayEquals(a,dao.backup()!!.payload)
        Assert.assertTrue(dao.chunks(1).all {it.payload.size<=SnapshotChunks.SIZE})
        dao.reset(a,3);Assert.assertNull(dao.backup());Assert.assertTrue(dao.chunks(2).isEmpty())
    }
    @Test fun migrationRetainsVersionOneInlineSnapshot()=runBlocking {
        val context=ApplicationProvider.getApplicationContext<android.content.Context>()
        val name="wealth_migration_test.db";context.deleteDatabase(name)
        val payload=SnapshotCodec.encode(GameEngine().newGame(1000,42))
        val sqlite=android.database.sqlite.SQLiteDatabase.openOrCreateDatabase(context.getDatabasePath(name),null)
        sqlite.execSQL("CREATE TABLE game_snapshots (id INTEGER NOT NULL PRIMARY KEY, payload BLOB NOT NULL, updatedAt INTEGER NOT NULL)")
        sqlite.execSQL("INSERT INTO game_snapshots VALUES (1,?,1000)",arrayOf(payload));sqlite.version=1;sqlite.close()
        val migrated=Room.databaseBuilder(context,GameDatabase::class.java,name).addMigrations(GameDatabase.MIGRATION_1_2,GameDatabase.MIGRATION_2_3).build()
        try {
            Assert.assertArrayEquals(payload,migrated.snapshots().current()!!.payload)
            migrated.snapshots().save(payload,2000)
            Assert.assertArrayEquals(payload,migrated.snapshots().backup()!!.payload)
            Assert.assertTrue(migrated.snapshots().raw(1)!!.payload.isEmpty())
        }finally {migrated.close();context.deleteDatabase(name)}
    }
    @Test fun repositoryRestartsOldEconomyOnceAndPersistsTheNewProgress()=runBlocking {
        val dao=db.snapshots();val old=GameEngine().newGame(1000,42);old.schema=4;old.cash=d(9000000)
        dao.save(SnapshotCodec.encode(old),1000)
        val scope=kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob()+kotlinx.coroutines.Dispatchers.IO)
        try {
            val repository=com.wealthempire.repository.GameRepository(dao,scope,com.wealthempire.core.market.AssetCatalog.defaults)
            val loaded=kotlinx.coroutines.withTimeout(90000) {repository.state.first {it!=null}!!}
            Assert.assertEquals(d(20000),loaded.cash);Assert.assertNull(dao.backup())
            repository.command {it.cash=d(18000)}
            val second=com.wealthempire.repository.GameRepository(dao,scope,com.wealthempire.core.market.AssetCatalog.defaults)
            val reloaded=kotlinx.coroutines.withTimeout(90000) {second.state.first {it!=null}!!}
            Assert.assertEquals(d(18000),reloaded.cash)
            Assert.assertEquals(com.wealthempire.core.models.SaveMigrations.CURRENT_SCHEMA,reloaded.schema)
        } finally {scope.cancel()}
    }
}
