package com.wealthempire.data
import org.junit.Test
import org.junit.Assert.*

class SnapshotChunksTest {
    @Test fun multiMegabyteSnapshotsRoundTripWithBoundedRows() {
        val bytes=ByteArray(3*1024*1024+17){(it*31).toByte()}
        val parts=SnapshotChunks.split(bytes);assertEquals(13,parts.size)
        assertTrue(parts.all {it.size<=256*1024})
        assertArrayEquals(bytes,SnapshotChunks.join(parts.mapIndexed {i,b->i to b}))
    }
    @Test fun incompleteOrReorderedChunksCannotSilentlyLoad() {
        val parts=SnapshotChunks.split(ByteArray(SnapshotChunks.SIZE+1)).mapIndexed {i,b->i to b}
        for(invalid in listOf(parts.reversed(),parts.drop(1),listOf(0 to ByteArray(SnapshotChunks.SIZE+1)))) {
            try {SnapshotChunks.join(invalid);fail("Invalid snapshot accepted")}catch(expected:IllegalArgumentException){assertNotNull(expected.message)}
        }
    }
}
