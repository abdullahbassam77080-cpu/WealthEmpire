package com.wealthempire.ui

import com.wealthempire.ui.components.marketDateLabel
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant

class MarketDateLabelTest {
    @Test fun weekdayAndDateAreLocalizedAndRollAtMidnight() {
        val monday=Instant.parse("2026-10-05T23:59:59Z").toEpochMilli()
        assertTrue(marketDateLabel(monday,"ar").contains("الاثنين"))
        assertTrue(marketDateLabel(monday+1000,"ar").contains("الثلاثاء"))
        assertTrue(marketDateLabel(monday,"en").contains("Monday"))
        assertTrue(marketDateLabel(monday+1000,"en").contains("2026-10-06"))
    }
}
