package com.wealthempire.ui
import com.wealthempire.ui.components.marketPrice
import org.junit.Test
import org.junit.Assert.*

class MarketPriceTest {
    @Test fun forexAndSmallListingPricesRemainReadableAndDistinct() {
        assertEquals("$0.00690000",marketPrice("0.0069".toBigDecimal()))
        assertEquals("$0.13900000",marketPrice("0.139".toBigDecimal()))
        assertNotEquals(marketPrice("0.00001234".toBigDecimal()),marketPrice("0.00001235".toBigDecimal()))
        assertEquals("$65,000.12",marketPrice("65000.1234".toBigDecimal()))
    }
}
