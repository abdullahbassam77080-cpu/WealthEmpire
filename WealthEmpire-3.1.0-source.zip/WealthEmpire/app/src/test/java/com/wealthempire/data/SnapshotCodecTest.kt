package com.wealthempire.data

import com.wealthempire.core.GameEngine
import com.wealthempire.core.models.*
import org.junit.Test
import org.junit.Assert.*

class SnapshotCodecTest {
    @Test fun completeExpandedSnapshotRoundtripInBoundedChunks() {
        val state=GameEngine().newGame(1000,42)
        state.cash=d("1000000000000.12345678")
        val payload=SnapshotCodec.encode(state)
        val parts=SnapshotChunks.split(payload)
        assertTrue(parts.all {it.size<=SnapshotChunks.SIZE})
        assertArrayEquals(payload,SnapshotChunks.join(parts.mapIndexed {i,it->i to it}))
        assertEquals(state,SnapshotCodec.decode(payload))
    }
    @Test fun partialPositionAndAlertsKeepExactValues() {
        val s=GameEngine().newGame(1000,42)
        val exact="0.123456789012345678901234567890123456789".toBigDecimal()
        s.positions.add(Position(s.id(),"BTC",Side.LONG,MarginMode.CROSS,10,d(65000),exact,d(75),d(75),funding=d("-0.75"),openFee=d("0.375"),openedAt=s.marketTime))
        s.alerts.add(GameAlert(s.id(),AlertType.NEWS,"regulation","CRYPTO",s.marketTime));s.marketTickAt=1234
        assertEquals(s,SnapshotCodec.decode(SnapshotCodec.encode(s)))
    }
    @Test fun clockAndFinancialHistoryPersistTogether() {
        val s=GameEngine().newGame(1000,42)
        s.cash=d(10000);s.marketSpeed=16;s.marketCarryMs=12345;s.alertsEnabled=false
        s.financialHistory.add(WealthPoint(4321,d("9988.12345678")))
        s.stats.financialDayStart=d("9000.12345678")
        val loaded=SnapshotCodec.decode(SnapshotCodec.encode(s))
        assertEquals(s,loaded)
        assertEquals(s.rngState,loaded.rngState)
        assertEquals(s.cash,loaded.cash)
    }
    @Test fun corruptionCannotSilentlyCreateNewGame() {
        try {SnapshotCodec.decode(byteArrayOf(1,2,3));fail("Expected corrupt save failure")}
        catch(expected:java.io.IOException) {assertNotNull(expected)}
    }
    @Test fun legacyRemovedFieldsAreIgnoredAndEconomyRestartsWithTwentyThousand() {
        val old="""{"schema":4,"cash":"9999999","initialCapital":"1000","marketSpeed":12,"miningLevel":20,"miningRigs":[{"id":2,"level":20}],"miningCostBasis":"52550","stats":{"mining":"9000000","casino":"5"},"lastSlot":{"symbols":[1,1,1]}}"""
        val bytes=java.io.ByteArrayOutputStream()
        java.util.zip.GZIPOutputStream(bytes).use {it.write(old.toByteArray(Charsets.UTF_8))}
        val decoded=SnapshotCodec.decode(bytes.toByteArray());assertEquals(4,decoded.schema)
        val e=GameEngine();val restarted=e.restore(decoded,1000,42)
        assertEquals(d(20000),restarted.cash);assertEquals(12,restarted.marketSpeed)
        assertEquals(SaveMigrations.CURRENT_SCHEMA,restarted.schema)
        val saved=SnapshotCodec.decode(SnapshotCodec.encode(restarted));saved.cash=d(19800)
        assertSame(saved,e.restore(saved,2000,43));assertEquals(d(19800),saved.cash)
    }
    @Test fun currentPayloadDoesNotIncludeRemovedSections() {
        val bytes=SnapshotCodec.encode(GameEngine().newGame(1000,42))
        val json=java.util.zip.GZIPInputStream(java.io.ByteArrayInputStream(bytes)).bufferedReader().use {it.readText()}
        for(key in listOf("miningRigs","miningLevel","miningCostBasis","miningLastAt","lastOfflineProfit","lastSlot","casino")) {
            assertFalse(json.contains("\"$key\""))
        }
    }
    @Test fun expandedStateAndTypedCopyRetainIndependentMutableState() {
        val e=GameEngine();val s=e.newGame(1000,42)
        s.holdings.add(Holding("BTC",d("0.02"),d(1200)))
        com.wealthempire.core.savings.SavingsRules.subscribe(s,e.market,"BTC",d("0.01"),30,false,s.marketTime)
        e.market.news.publish(s,"token_hack","SOL",-.1,86400000L,1.0,"اختراق","Hack")
        val loaded=SnapshotCodec.decode(SnapshotCodec.encode(s));assertEquals(s,loaded)
        val copy=SnapshotCodec.copy(s);assertEquals(s,copy)
        copy.savings.single().principal=d(1);copy.savingsOffers.first().baseApr=d(99)
        copy.economy.lastNewsKeys.add("different");copy.quotes.first().bars[1]!![0]=copy.quotes.first().bars[1]!!.first().copy(close=d(1))
        copy.listings.first().status=ListingStatus.LIVE
        assertEquals(s,loaded);assertNotEquals(s,copy)
    }
}
