package com.wealthempire.ui

import com.wealthempire.ui.components.*
import org.junit.Assert.*
import org.junit.Test

class ChartViewportTest {
    private val times = (0L until 400L).map { it * 60_000 }

    @Test fun verticalAndDiagonalSwipesBelongToPage() {
        for ((x,y) in listOf(0f to -80f, 10f to 80f, -35f to -40f, 40f to 40f))
            assertEquals(ChartDragOwner.PAGE, chartDragOwner(x,y,12f))
        assertEquals(ChartDragOwner.CHART, chartDragOwner(80f,10f,12f))
        assertEquals(ChartDragOwner.CHART, chartDragOwner(-80f,-10f,12f))
    }
    @Test fun fingerJitterBelowTouchSlopDoesNotCaptureScroll() {
        for ((x,y) in listOf(0f to 0f, 9f to 11f, -12f to 0f))
            assertEquals(ChartDragOwner.WAITING, chartDragOwner(x,y,12f))
    }
    @Test fun historyRemainsOnSameCandlesWhenMarketAppendsOrPrunesBars() {
        val view = ChartViewport().transform(times,100f,300f)
        val original = view.range(times)
        val appended = times + listOf(400L * 60_000,401L * 60_000)
        val next = view.range(appended)
        assertEquals(times[original.start],appended[next.start])
        assertEquals(times[original.end-1],appended[next.end-1])
        val capped = appended.drop(2)
        val bounded = view.range(capped)
        assertEquals(times[original.start],capped[bounded.start])
        assertEquals(times[original.end-1],capped[bounded.end-1])
    }
    @Test fun liveViewportFollowsNewCandlesAndResetRestoresIt() {
        assertEquals(400,ChartViewport().range(times).end)
        assertEquals(401,ChartViewport().range(times + 24_000_000L).end)
        val historical = ChartViewport().transform(times,100f,300f)
        assertTrue(historical.range(times).end < 400)
        assertEquals(400,historical.copy(rightEdgeTime=null,panRemainder=0.0).range(times).end)
    }
    @Test fun manySmallDragEventsEqualOneLargeDrag() {
        var incremental = ChartViewport()
        repeat(100) { incremental = incremental.transform(times,1f,300f) }
        val single = ChartViewport().transform(times,100f,300f)
        assertEquals(single.range(times),incremental.range(times))
        assertEquals(single.panRemainder,incremental.panRemainder,.00001)
    }
    @Test fun pinchKeepsCandleUnderFingerWhileChangingVisibleCount() {
        val view = ChartViewport().transform(times,200f,300f)
        val old = view.range(times)
        val next = view.transform(times,0f,300f,1.5f,.5f).range(times)
        assertTrue(next.size < old.size)
        assertEquals(old.end-old.size*.5,next.end-next.size*.5,1.0)
    }
    @Test fun viewportClampsAtHistoryEdgesAndZoomLimits() {
        val older = ChartViewport().transform(times,100_000f,300f)
        assertEquals(0,older.range(times).start)
        val latest = older.transform(times,-100_000f,300f)
        assertNull(latest.rightEdgeTime)
        assertEquals(400,latest.range(times).end)
        assertEquals(20,latest.transform(times,0f,300f,100f).range(times).size)
        assertEquals(120,latest.transform(times,0f,300f,.001f).range(times).size)
    }
    @Test fun emptyAndShortHistoryAndInvalidTransformAreSafe() {
        val view = ChartViewport()
        assertEquals(ChartRange(0,0),view.range(emptyList()))
        assertEquals(ChartRange(0,3),view.range(times.take(3)))
        for (zoom in listOf(0f,-1f,Float.NaN,Float.POSITIVE_INFINITY))
            assertEquals(view,view.transform(times,20f,300f,zoom))
        assertEquals(view,view.transform(times,Float.NaN,300f))
        assertEquals(view,view.transform(times,20f,0f))
    }
    @Test fun axisRoundsPricesRatherThanTruncatingRawDecimals() {
        assertEquals("62,564.13",chartPrice(62564.130513,chartPriceDecimals(62564.0)))
        assertEquals("62,564.14",chartPrice(62564.136,chartPriceDecimals(62564.0)))
        assertEquals("0.1234",chartPrice(.1234,chartPriceDecimals(.1234)))
        assertEquals("0.000012345",chartPrice(.000012345,chartPriceDecimals(.000012345)))
        assertFalse(chartPrice(1e-9,chartPriceDecimals(1e-9)).contains('E'))
    }
    @Test fun tightPriceRangesKeepDistinctAxisLabelsAndVolumeIsCompact() {
        val precision = chartPriceDecimals(62000.0,.0005)
        assertNotEquals(chartPrice(62000.0,precision),chartPrice(62000.0005,precision))
        assertEquals("1.25K",chartVolume(1250.0))
        assertEquals("2.50M",chartVolume(2_500_000.0))
        assertEquals("1.00B",chartVolume(1_000_000_000.0))
    }
}
