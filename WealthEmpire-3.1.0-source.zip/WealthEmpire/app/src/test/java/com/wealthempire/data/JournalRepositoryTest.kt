package com.wealthempire.data
import com.wealthempire.core.GameEngine
import com.wealthempire.core.models.*
import com.wealthempire.core.market.AssetCatalog
import com.wealthempire.core.wallet.WalletRules
import com.wealthempire.repository.GameRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import org.junit.Test
import org.junit.Assert.*
import java.io.File
import java.util.concurrent.ConcurrentSkipListMap
class JournalRepositoryTest {
 private class MemoryDao:SnapshotDao {
  val rows=ConcurrentSkipListMap<Int,SnapshotEntity>();val parts=ConcurrentSkipListMap<Pair<Int,Int>,SnapshotChunkEntity>(compareBy<Pair<Int,Int>>{it.first}.thenBy{it.second});val events=ConcurrentSkipListMap<Long,JournalEntity>()
  var failJournal=false;var slowSnapshot=0L;var saves=0
  override suspend fun appendJournal(event:JournalEntity){if(failJournal)error("storage_error");check(events.putIfAbsent(event.sequence,event)==null)}
  override suspend fun journal(after:Long)=events.values.filter{it.sequence>after}
  override suspend fun pruneJournal(through:Long){events.keys.filter{it<=through}.forEach{events.remove(it)}}
  override suspend fun clearJournal(){events.clear()}
  override suspend fun raw(id:Int)=rows[id]
  override suspend fun chunks(id:Int)=parts.values.filter{it.snapshotId==id}
  override suspend fun deleteChunks(id:Int){parts.keys.filter{it.first==id}.forEach{parts.remove(it)}}
  override suspend fun copyChunksToBackup(){chunks(1).forEach{parts[2 to it.part]=it.copy(snapshotId=2)}}
  override suspend fun insertChunks(chunks:List<SnapshotChunkEntity>){chunks.forEach{parts[it.snapshotId to it.part]=it}}
  override suspend fun insert(snapshot:SnapshotEntity){rows[snapshot.id]=snapshot}
  override suspend fun deleteAll(){rows.clear()}
  override suspend fun deleteAllChunks(){parts.clear()}
  override suspend fun save(payload:ByteArray,now:Long){saves++;if(slowSnapshot>0)delay(slowSnapshot);rows[1]?.let{rows[2]=it};rows[1]=SnapshotEntity(1,payload,now)}
 }
 @Test fun journalReplayIsCheckedAndIdempotent(){val s=GameEngine().newGame(1000,42);val x=GameStateCopy.copy(s,false);x.journalSeq=1;WalletRules.transfer(x,Wallet.CASH,Wallet.FUTURES,d(500));val payload=JournalCodec.encode(x,false);assertFalse(payload.contains("\"bars\""));val row=JournalEntity(1,"TRANSFER",payload,0,JournalCodec.checksum(payload));val restored=JournalCodec.replay(s,row);assertEquals(x.futuresCash,restored.futuresCash);assertSame(restored,JournalCodec.replay(restored,row));try{JournalCodec.replay(s,row.copy(checksum="bad"));fail("checksum")}catch(_:IllegalArgumentException){};val gap=JournalCodec.encode(x.copy(journalSeq=2),false);try{JournalCodec.replay(s,JournalEntity(2,"TRANSFER",gap,0,JournalCodec.checksum(gap)));fail("gap")}catch(expected:IllegalArgumentException){assertEquals("journal_gap",expected.message)}}
 @Test fun commandsAreDurableWithoutFullSnapshotAndFailedWriteIsAtomic()=runBlocking {
  val scope=CoroutineScope(SupervisorJob()+Dispatchers.Default);try{val dao=MemoryDao();val repo=GameRepository(dao,scope,AssetCatalog.defaults);withTimeout(10000){repo.state.filterNotNull().first()};val baseline=dao.saves;repo.command("TRANSFER"){WalletRules.transfer(it,Wallet.CASH,Wallet.FUTURES,d(700))};assertEquals(baseline,dao.saves);assertEquals(1,dao.events.size);dao.failJournal=true;try{repo.command{WalletRules.transfer(it,Wallet.CASH,Wallet.FUTURES,d(100))};fail("expected IO failure")}catch(_:IllegalStateException){};assertEquals(0,d(700).compareTo(repo.state.value!!.futuresCash));assertEquals(0,d(19300).compareTo(repo.state.value!!.cash))}finally{scope.cancel()}
 }
 @Test fun acknowledgedCommandReplaysAfterRestart()=runBlocking {
  val dao=MemoryDao();val scope=CoroutineScope(SupervisorJob()+Dispatchers.Default);val repo=GameRepository(dao,scope,AssetCatalog.defaults);withTimeout(10000){repo.state.filterNotNull().first()};repo.command("TRANSFER"){WalletRules.transfer(it,Wallet.CASH,Wallet.FUTURES,d(700))};scope.cancel();val scope2=CoroutineScope(SupervisorJob()+Dispatchers.Default);try{val loaded=GameRepository(dao,scope2,AssetCatalog.defaults);val s=withTimeout(10000){loaded.state.filterNotNull().first()};assertEquals(0,d(700).compareTo(s.futuresCash));assertEquals(0,d(19300).compareTo(s.cash));assertEquals(1L,s.journalSeq)}finally{scope2.cancel()}
 }
 @Test fun playerCommandsStayResponsiveDuring16xCatchupAndCompression()=runBlocking {
  val now=System.currentTimeMillis();val engine=GameEngine();val initial=engine.newGame(now-86400000,42);initial.cash-=d(650);initial.holdings.add(Holding("BTC",d(".01"),d(650)));com.wealthempire.core.savings.SavingsRules.subscribe(initial,engine.market,"BTC",d(".01"),0,false,initial.marketTime);initial.marketSpeed=16
  val dao=MemoryDao();dao.rows[1]=SnapshotEntity(1,SnapshotCodec.encode(initial),now-86400000)
  val scope=CoroutineScope(SupervisorJob()+Dispatchers.Default);try{val repo=GameRepository(dao,scope,AssetCatalog.defaults);withTimeout(10000){repo.state.filterNotNull().first()};repo.command("TRANSFER"){WalletRules.transfer(it,Wallet.CASH,Wallet.FUTURES,d(1000))};val session=scope.launch{repo.session()};withTimeout(10000){repo.catchup.first{it}};dao.slowSnapshot=400;val save=scope.launch{repo.checkpoint()};val times=mutableListOf<Double>();repeat(60){i->val start=System.nanoTime();repo.command(if(i%4<2)"TRANSFER" else if(i%4==2)"ORDER_OPENED" else "POSITION_CLOSED"){state->when(i%4){
   0->WalletRules.transfer(state,Wallet.CASH,Wallet.FUTURES,ONE)
   1->WalletRules.transfer(state,Wallet.FUTURES,Wallet.CASH,ONE)
   2->repo.engine.trading.submit(state,"BTC",OrderVenue.FUTURES,OrderKind.MARKET,if(i%8<4)Side.LONG else Side.SHORT,d(10),2,MarginMode.CROSS)
   else->repo.engine.trading.close(state,state.positions.last().id)
  }};times.add((System.nanoTime()-start)/1e6)};times.sort();val p95=times[(times.size*.95).toInt()-1];File("build/reports").mkdirs();File("build/reports/command-latency.json").writeText("{\"environment\":\"JVM memory journal, real GZIP snapshot, 400ms delayed save, active BTC Earn, 16x offline catchup\",\"commandMix\":\"30 transfers, 15 futures opens, 15 closes\",\"samples\":60,\"p50Ms\":${times[29]},\"p95Ms\":$p95,\"maxMs\":${times.last()}}");assertTrue("p95=$p95 ms",p95<150);assertEquals(0,d(18350).compareTo(repo.state.value!!.cash));assertTrue(repo.state.value!!.positions.isEmpty());save.join();session.cancel()}finally{scope.cancel()}
 }
 @Test fun resetCannotBeOverwrittenByOlderSnapshot()=runBlocking {
  val dao=MemoryDao();val scope=CoroutineScope(SupervisorJob()+Dispatchers.Default);try{val repo=GameRepository(dao,scope,AssetCatalog.defaults);withTimeout(10000){repo.state.filterNotNull().first()};repo.command{it.cash=d(123)};dao.slowSnapshot=400;val old=scope.launch{repo.checkpoint()};delay(50);repo.reset(com.wealthempire.core.world.GameMode.HARDCORE);old.join();assertEquals(0,d(8000).compareTo(repo.state.value!!.cash));assertEquals(0,d(8000).compareTo(SnapshotCodec.decode(dao.current()!!.payload).cash));assertTrue(dao.events.isEmpty())}finally{scope.cancel()}
 }
 @Test fun validBackupAndJournalRepairCorruptPrimary()=runBlocking {
  val dao=MemoryDao();val s=GameEngine().newGame(System.currentTimeMillis(),42);dao.rows[1]=SnapshotEntity(1,byteArrayOf(1,2,3),0);dao.rows[2]=SnapshotEntity(2,SnapshotCodec.encode(s),0);val x=GameStateCopy.copy(s,false);WalletRules.transfer(x,Wallet.CASH,Wallet.FUTURES,d(700));x.journalSeq=1;val text=JournalCodec.encode(x,false);dao.events[1]=JournalEntity(1,"TRANSFER",text,0,JournalCodec.checksum(text));val scope=CoroutineScope(SupervisorJob()+Dispatchers.Default);try{val repo=GameRepository(dao,scope,AssetCatalog.defaults);val loaded=withTimeout(10000){repo.state.filterNotNull().first()};assertEquals(0,d(19300).compareTo(loaded.cash));assertEquals(0,d(700).compareTo(SnapshotCodec.decode(dao.current()!!.payload).futuresCash));assertTrue(dao.events.isEmpty())}finally{scope.cancel()}
 }

}
