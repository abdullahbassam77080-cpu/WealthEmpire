package com.wealthempire.ui

import com.wealthempire.ui.components.parsed
import com.wealthempire.core.models.d
import org.junit.Test
import org.junit.Assert.*

class FinancialInputTest {
    @Test fun ArabicDigitsAndFractionalAssetAmountsAreSupported() {
        assertEquals(d("1234.50"),parsed("١٢٣٤٫٥٠"))
        assertEquals(d("0.00000012345678901234"),parsed(".00000012345678901234"))
        assertEquals(d("2500"),parsed("۲۵۰۰"))
    }
    @Test fun UnsafeExponentAndInvalidFormatsAreRejected() {
        for(input in listOf("1e2147483647","NaN","Infinity","-1","10,000","", "1.2.3", "9".repeat(40))) assertNull(input,parsed(input))
    }
}
