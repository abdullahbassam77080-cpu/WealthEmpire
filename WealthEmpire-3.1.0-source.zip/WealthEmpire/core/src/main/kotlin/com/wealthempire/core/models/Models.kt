@file:UseSerializers(DecimalSerializer::class)
package com.wealthempire.core.models

import java.math.BigDecimal
import kotlinx.serialization.Serializable
import kotlinx.serialization.UseSerializers

@Serializable enum class Wallet { CASH, FUTURES, SPOT, STOCKS }
@Serializable enum class AssetKind { CRYPTO, STOCK, COMMODITY, FOREX, BOND }
@Serializable enum class Side { LONG, SHORT }
@Serializable enum class MarginMode { ISOLATED, CROSS }
@Serializable enum class OrderKind { MARKET, LIMIT, STOP_MARKET }
@Serializable enum class OrderVenue { FUTURES, SPOT, STOCK }
@Serializable enum class OrderStatus { OPEN, FILLED, CANCELLED, REJECTED }
@Serializable enum class Regime { BULL, BEAR, SIDEWAYS }
@Serializable data class AssetSpec(
    val symbol: String, val name: String, val kind: AssetKind,
    val initialPrice: BigDecimal, val volatility: Double, val marketCap: BigDecimal,
    val risk: Int, val sector: String = "crypto", val unit: String = "token",
    val nameAr:String = name, val stable:Boolean=false, val legacy:Boolean=false,
    val referenceSymbol:String?=null, val dailyLeverage:Int=1
)
val AssetSpec.isEtf:Boolean get()=referenceSymbol!=null || symbol in setOf("SPY","QQQ","SOXX") || sector.startsWith("etf")
@Serializable data class Candle(val time: Long, val open: BigDecimal, val high: BigDecimal,
    val low: BigDecimal, val close: BigDecimal, val volume: BigDecimal)
@Serializable data class Quote(val symbol: String, var price: BigDecimal, var dayOpen: BigDecimal,
    var trend: Double = 0.0, var eventBias: Double = 0.0,
    var dayBucket: Long = 0, val bars: MutableMap<Int, MutableList<Candle>> = mutableMapOf(),
    var fundamentalAnchor:Double=1.0, var varianceScale:Double=1.0, var pendingJump:Double=0.0)
@Serializable data class Holding(val symbol: String, var quantity: BigDecimal = ZERO,
    var cost: BigDecimal = ZERO) {
    val average: BigDecimal get() = if (quantity > ZERO) cost.divD(quantity) else ZERO
}
@Serializable data class Position(val id: Long, val symbol: String, val side: Side,
    val mode: MarginMode, val leverage: Int, val entry: BigDecimal, val quantity: BigDecimal,
    var margin: BigDecimal, val originalMargin: BigDecimal,
    var takeProfit: BigDecimal? = null, var stopLoss: BigDecimal? = null,
    var funding: BigDecimal = ZERO, val openFee: BigDecimal = ZERO, val openedAt: Long)
@Serializable data class Order(val id: Long, val symbol: String, val venue: OrderVenue,
    val kind: OrderKind, val side: Side, val marginMode: MarginMode,
    val leverage: Int, val amount: BigDecimal, val trigger: BigDecimal?,
    val takeProfit: BigDecimal?, val stopLoss: BigDecimal?, val wallet: Wallet,
    val reserved: BigDecimal, val createdAt: Long,
    var status: OrderStatus = OrderStatus.OPEN, var result: String = "")
@Serializable data class Trade(val id: Long, val symbol: String, val side: Side,
    val venue: OrderVenue, val entry: BigDecimal, val exit: BigDecimal,
    val quantity: BigDecimal, val pnl: BigDecimal, val fees: BigDecimal,
    val reason: String, val time: Long)
@Serializable data class News(val id: Long, val key: String, val target: String,
    val impact: Double, val time: Long, val titleAr:String="",val titleEn:String="",
    val detailAr:String="",val detailEn:String="",val sourceAr:String="",val sourceEn:String="",
    val storyId:Long=0)
@Serializable data class WealthPoint(val time: Long, val value: BigDecimal)
@Serializable data class Statistics(
    var futures: BigDecimal = ZERO,
    var spot: BigDecimal = ZERO, var stocks: BigDecimal = ZERO,
    var fees: BigDecimal = ZERO,
    var savings:BigDecimal=ZERO,
    var funding: BigDecimal = ZERO, var bestTrade: BigDecimal = ZERO,
    var worstTrade: BigDecimal = ZERO, var largestLiquidation: BigDecimal = ZERO,
    var highestWealth: BigDecimal = GameDefaults.STARTING_CAPITAL, var trades: Int = 0,
    var wins: Int = 0, var timePlayedMs: Long = 0,
    var filledOrders:Long=0, var stopExecutions:Long=0, var takeProfitExecutions:Long=0, var liquidations:Long=0,
    var dayStartWealth: BigDecimal = GameDefaults.STARTING_CAPITAL, var day: Long = 0,
    var financialDayStart:BigDecimal?=null, var financialDay:Long=0
)
@Serializable data class GameState(
    var schema: Int = 1,
    var journalSeq:Long=0, var pendingWorldMs:Long=0,
    var gameMode:com.wealthempire.core.world.GameMode=com.wealthempire.core.world.GameMode.PURE_INVESTOR,
    val world:com.wealthempire.core.world.WorldState=com.wealthempire.core.world.WorldState(),
    val progression:com.wealthempire.core.world.Progression=com.wealthempire.core.world.Progression(),
    val favorites:MutableList<String> = mutableListOf("BTC","ETH","NVDA","XAU"),
    var awayReport:com.wealthempire.core.world.AwayReport?=null,
    var cash: BigDecimal = GameDefaults.STARTING_CAPITAL, var futuresCash: BigDecimal = ZERO,
    var spotCash: BigDecimal = ZERO, var stocksCash: BigDecimal = ZERO,
    var initialCapital:BigDecimal=GameDefaults.STARTING_CAPITAL,
    var lastSeenAt: Long = 0, var marketTime: Long = 0,
    var marketTickAt:Long=0,
    var marketSpeed:Int=1, var marketCarryMs:Long=0,
    var alertsEnabled:Boolean=true,
    val alerts:MutableList<GameAlert> = mutableListOf(),
    var rngState: Long = 42, var nextId: Long = 1, var ticks: Long = 0,
    var regime: Regime = Regime.SIDEWAYS, var regimeUntil: Long = 120,
    var fundingBucket: Long = 0, var xp: Long = 0,
    val quotes: MutableList<Quote> = mutableListOf(),
    val holdings: MutableList<Holding> = mutableListOf(),
    val positions: MutableList<Position> = mutableListOf(),
    val orders: MutableList<Order> = mutableListOf(),
    val orderHistory: MutableList<Order> = mutableListOf(),
    val trades: MutableList<Trade> = mutableListOf(),
    val news: MutableList<News> = mutableListOf(),
    val wealthHistory: MutableList<WealthPoint> = mutableListOf(),
    val financialHistory:MutableList<WealthPoint> = mutableListOf(),
    val achievements: MutableList<String> = mutableListOf(),
    val economy:EconomyState=EconomyState(),
    val effects:MutableList<MarketEffect> = mutableListOf(),
    val stories:MutableList<MarketStory> = mutableListOf(),
    val listings:MutableList<AssetListing> = mutableListOf(),
    val savings:MutableList<SavingsPosition> = mutableListOf(),
    val savingsOffers:MutableList<SavingsOffer> = mutableListOf(),
    val savingsHistory:MutableList<SavingsRecord> = mutableListOf(),
    val stats: Statistics = Statistics()
) {
    val level: Int get() = 1 + kotlin.math.sqrt(xp.toDouble() / 100.0).toInt()
    fun quote(symbol: String): Quote = quotes.first { it.symbol == symbol }
    fun balance(wallet: Wallet): BigDecimal = when (wallet) {
        Wallet.CASH -> cash; Wallet.FUTURES -> futuresCash
        Wallet.SPOT -> spotCash; Wallet.STOCKS -> stocksCash
    }
    fun credit(wallet: Wallet, delta: BigDecimal) {
        when (wallet) {
            Wallet.CASH -> cash = (cash + delta).money()
            Wallet.FUTURES -> futuresCash = (futuresCash + delta).money()
            Wallet.SPOT -> spotCash = (spotCash + delta).money()
            Wallet.STOCKS -> stocksCash = (stocksCash + delta).money()
        }
    }
    fun id(): Long = nextId++
}
