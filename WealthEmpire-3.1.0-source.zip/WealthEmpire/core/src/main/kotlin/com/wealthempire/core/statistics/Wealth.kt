package com.wealthempire.core.statistics

import com.wealthempire.core.models.*
import com.wealthempire.core.trading.FuturesMath
import java.math.BigDecimal

object Wealth {
    val milestones = listOf("50000", "100000", "250000", "1000000", "10000000", "100000000", "1000000000")
    fun holdingsValue(s: GameState, symbols: Set<String>? = null): BigDecimal =
        s.holdings.filter { symbols == null || it.symbol in symbols }
            .fold(ZERO) { sum,h -> sum + h.quantity * s.quote(h.symbol).price }
    fun savingsValue(s:GameState):BigDecimal=s.savings.fold(ZERO){sum,p->sum+(p.principal+p.rewards)*s.quote(p.symbol).price}
    fun total(s: GameState): BigDecimal = s.cash+s.futuresCash+s.spotCash+s.stocksCash+
        holdingsValue(s)+savingsValue(s)+
        s.positions.fold(ZERO) { acc,p -> acc + p.margin + FuturesMath.pnl(p,s.quote(p.symbol).price) }+
        s.orders.filter { it.status == OrderStatus.OPEN }.fold(ZERO) { acc,o -> acc+o.reserved }
    /** Current financial equity. Realized profits are already in wallets. */
    fun availableCash(s:GameState)=s.cash+s.futuresCash+s.spotCash+s.stocksCash
    fun financialInvested(s:GameState):BigDecimal=holdingsValue(s)+savingsValue(s)+
        s.positions.fold(ZERO) {sum,p -> sum+p.margin+FuturesMath.pnl(p,s.quote(p.symbol).price)}+
        s.orders.filter {it.status==OrderStatus.OPEN}.fold(ZERO) {sum,o -> sum+o.reserved}
    fun financialTotal(s:GameState)=availableCash(s)+financialInvested(s)
    fun update(s: GameState, now: Long) {
        val total = total(s)
        val financial=financialTotal(s)
        if(s.stats.financialDayStart==null || s.stats.financialDay!=now/86400000L) {
            s.stats.financialDay=now/86400000L;s.stats.financialDayStart=financial
        }
        if(s.financialHistory.lastOrNull()?.time?.let {now-it>=60000}!=false) {
            s.financialHistory.add(WealthPoint(now,financial))
            while(s.financialHistory.size>360)s.financialHistory.removeAt(0)
        }
        s.stats.highestWealth = maxOf(s.stats.highestWealth,total)
        if(s.stats.day != now/86400000L) { s.stats.day = now/86400000L; s.stats.dayStartWealth = total }
        milestones.forEach { threshold ->
            if(total >= d(threshold) && threshold !in s.achievements) { s.achievements.add(threshold); s.xp += 250 }
        }
        if(s.wealthHistory.lastOrNull()?.time?.let { now-it >= 60000 } != false) {
            s.wealthHistory.add(WealthPoint(now,total)); while(s.wealthHistory.size > 360) s.wealthHistory.removeAt(0)
        }
    }
}
