package com.wealthempire.core.market

import com.wealthempire.core.models.Candle
import kotlin.math.sqrt

object Indicators {
    fun ema(values: List<Double>, period: Int): List<Double?> {
        require(period > 0)
        var average = 0.0
        return values.mapIndexed { i, v ->
            if (i < period - 1) null
            else if (i == period - 1) { average = values.take(period).average(); average }
            else { average += 2.0 / (period+1) * (v - average); average }
        }
    }
    fun rsi(values: List<Double>, period: Int = 14): List<Double?> {
        var gain = 0.0; var loss = 0.0
        return values.mapIndexed { i, v ->
            if(i == 0) null else {
                val delta = v - values[i-1]
                val up = delta.coerceAtLeast(0.0); val down = (-delta).coerceAtLeast(0.0)
                if(i <= period) { gain += up / period; loss += down / period }
                else { gain = (gain*(period-1)+up)/period; loss = (loss*(period-1)+down)/period }
                if(i < period) null else if(loss == 0.0) (if(gain == 0.0) 50.0 else 100.0)
                else 100.0 - 100.0/(1 + gain/loss)
            }
        }
    }
    data class Macd(val line: List<Double?>, val signal: List<Double?>, val histogram: List<Double?>)
    fun macd(values: List<Double>): Macd {
        val fast = ema(values,12); val slow = ema(values,26)
        val line = values.indices.map { i -> if(fast[i] != null && slow[i] != null) fast[i]!! - slow[i]!! else null }
        val valid = line.filterNotNull(); val rawSignal = ema(valid,9)
        val signal = List<Double?>(values.size - valid.size) { null } + rawSignal
        return Macd(line,signal,line.indices.map { i -> if(line[i] != null && signal[i] != null) line[i]!!-signal[i]!! else null })
    }
    fun bollinger(values: List<Double>, period: Int = 20): Pair<List<Double?>,List<Double?>> {
        val upper = mutableListOf<Double?>(); val lower = mutableListOf<Double?>()
        values.indices.forEach { i ->
            if(i < period-1) { upper.add(null); lower.add(null) }
            else { val window = values.subList(i-period+1,i+1); val mean = window.average()
                val deviation = sqrt(window.sumOf { (it-mean)*(it-mean) }/period)
                upper.add(mean+2*deviation); lower.add(mean-2*deviation) }
        }
        return upper to lower
    }
    fun closes(bars: List<Candle>) = bars.map { it.close.toDouble() }
}
