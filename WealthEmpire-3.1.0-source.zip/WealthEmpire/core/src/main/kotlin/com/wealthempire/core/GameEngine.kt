package com.wealthempire.core

import com.wealthempire.core.models.*
import com.wealthempire.core.market.*
import com.wealthempire.core.statistics.Wealth
import com.wealthempire.core.trading.TradingEngine
import com.wealthempire.core.savings.SavingsRules
import com.wealthempire.core.world.*
import com.wealthempire.core.events.EventEngine
import com.wealthempire.core.progression.ProgressionEngine
import java.time.*

class GameEngine(val market:MarketEngine=MarketEngine()) {
    val trading=TradingEngine(market)
    fun newGame(now:Long,seed:Long=now,mode:GameMode=GameMode.PURE_INVESTOR):GameState {
        val start=LocalDate.of(2026,10,5).atTime(10,0).toInstant(ZoneOffset.UTC).toEpochMilli()
        val capital=if(mode==GameMode.HARDCORE)d(8000) else GameDefaults.STARTING_CAPITAL
        val s=GameState(schema=SaveMigrations.CURRENT_SCHEMA,cash=capital,initialCapital=capital,gameMode=mode,
            marketTickAt=now,lastSeenAt=now,marketTime=start,rngState=seed,fundingBucket=start/28800000L)
        market.seed(s);SavingsRules.seed(s,market);Wealth.update(s,start);ProgressionEngine.advance(s,market)
        return s
    }
    fun restore(s:GameState,now:Long,seed:Long=now):GameState {
        if(SaveMigrations.needsEconomyRestart(s))return newGame(now,seed).also {it.marketSpeed=s.marketSpeed.takeIf {v->v in GameClock.speeds} ?: 1;it.alertsEnabled=s.alertsEnabled}
        if(s.schema==5){s.quotes.forEach {it.bars.clear()};s.financialHistory.clear();s.wealthHistory.clear()}
        s.schema=SaveMigrations.CURRENT_SCHEMA;market.seed(s);return s
    }
    /** Accumulate ALL elapsed time; never discard backlog. Commands do not call this method. */
    fun queueElapsed(s:GameState,now:Long) {
        GameClock.requireSpeed(s.marketSpeed)
        val at=if(s.marketTickAt==0L)s.lastSeenAt else s.marketTickAt
        val elapsed=(now-at).coerceAtLeast(0).coerceAtMost((Long.MAX_VALUE-s.pendingWorldMs-s.marketCarryMs)/maxOf(1,s.marketSpeed))
        val due=s.marketCarryMs+elapsed*s.marketSpeed
        s.pendingWorldMs+=due/GameClock.SIM_STEP_MS*GameClock.SIM_STEP_MS
        s.marketCarryMs=due%GameClock.SIM_STEP_MS;s.marketTickAt=maxOf(now,at)
    }
    fun advanceOne(s:GameState):Boolean {
        if(s.pendingWorldMs<=0)return false
        val pending=s.pendingWorldMs
        val adaptive=when {pending<=60_000L->1000L;pending<=3_600_000L->60_000L;s.positions.isNotEmpty() || s.orders.isNotEmpty()->3_600_000L;else->6*3_600_000L}
        var end=s.marketTime+minOf(pending,adaptive)
        val boundary=minOf(EventEngine.nextBoundary(s),
            (s.marketTime/86_400_000L+1)*86_400_000L,(s.marketTime/28_800_000L+1)*28_800_000L,
            MarketSessions.nextTransition(s.marketTime).time,
            s.listings.filter {it.status==ListingStatus.UPCOMING}.minOfOrNull {it.opensAt} ?: Long.MAX_VALUE)
        if(boundary>s.marketTime)end=minOf(end,boundary)
        val duration=(end-s.marketTime).coerceAtLeast(1)
        var previous=s.quotes.associate {it.symbol to it.price};var couponAt=s.marketTime
        market.stepDuration(s,duration) {
            val elapsed=s.marketTime-couponAt
            for(h in s.holdings) {
                val spec=market.spec(h.symbol,s)
                if(spec.kind==AssetKind.BOND) {
                    val rate=if(h.symbol=="US2Y").043 else .041
                    s.credit(Wallet.SPOT,h.quantity*d(100)*d(rate)*d(elapsed).divD(d(31_536_000_000L)))
                } else if(spec.kind==AssetKind.STOCK && h.quantity>ZERO) {
                    // Simulated cash dividends accrue continuously on owned shares/ETFs.
                    // Rates are annualized and intentionally conservative for this game economy.
                    val annualYield=when {
                        spec.isEtf -> .014
                        spec.sector=="banks" -> .027
                        spec.sector=="utilities" -> .032
                        spec.sector=="retail" -> .018
                        spec.sector=="tech" || spec.sector=="chips" -> .006
                        else -> .015
                    }
                    val mark=s.quote(h.symbol).price
                    val dividend=mark*h.quantity*d(annualYield)*d(elapsed).divD(d(31_536_000_000L))
                    if(dividend>ZERO)s.credit(Wallet.STOCKS,dividend)
                }
            }
            couponAt=s.marketTime;SavingsRules.advance(s,market,s.marketTime)
            trading.processPath(s,previous);trading.funding(s);previous=s.quotes.associate {it.symbol to it.price}
        }
        s.pendingWorldMs-=duration
        ProgressionEngine.advance(s,market);Wealth.update(s,s.marketTime)
        return true
    }
    fun tick(s:GameState,now:Long) {
        val elapsed=(now-s.lastSeenAt).coerceIn(0,10_000)
        queueElapsed(s,now);repeat(8){if(!advanceOne(s))return@repeat}
        s.stats.timePlayedMs+=elapsed;s.lastSeenAt=maxOf(now,s.lastSeenAt)
    }
    fun resume(s:GameState,now:Long) {
        val before=Wealth.total(s);val from=s.marketTime;val prices=s.quotes.associate {it.symbol to it.price.toDouble()}
        val lastTrade=s.trades.firstOrNull()?.id ?: 0;val lastNews=s.news.firstOrNull()?.id ?: 0
        val fills=s.stats.filledOrders;val stops=s.stats.stopExecutions;val profits=s.stats.takeProfitExecutions;val liquidations=s.stats.liquidations;val funding=s.stats.funding;val earn=s.stats.savings
        queueElapsed(s,now);while(advanceOne(s)){}
        s.lastSeenAt=maxOf(s.lastSeenAt,now)
        if(s.marketTime-from>=5*60_000L) {
            val trades=s.trades.filter {it.id>lastTrade}
            s.awayReport=AwayReport(from,s.marketTime,before.toPlainString(),Wealth.total(s).toPlainString(),s.quotes.filter {it.symbol in prices}.associate {it.symbol to ((it.price.toDouble()/prices.getValue(it.symbol)-1)*100)},
                s.news.filter {it.time>from}.sortedByDescending {kotlin.math.abs(it.impact)}.take(8).map {it.id},(s.stats.filledOrders-fills).toInt(),(s.stats.stopExecutions-stops).toInt(),(s.stats.takeProfitExecutions-profits).toInt(),(s.stats.liquidations-liquidations).toInt(),(s.stats.funding-funding).toPlainString(),(s.stats.savings-earn).toPlainString())
        }
    }
    fun setSpeed(s:GameState,speed:Int,now:Long) {GameClock.requireSpeed(speed);queueElapsed(s,now);s.marketSpeed=speed}
    fun skip(s:GameState) {
        val next=minOf(s.world.calendar.filter {it.actual==null}.minOfOrNull {it.time} ?: Long.MAX_VALUE,s.listings.filter {it.status==ListingStatus.UPCOMING}.minOfOrNull {it.opensAt} ?: Long.MAX_VALUE)
        require(next!=Long.MAX_VALUE){"no_event"};s.pendingWorldMs=maxOf(s.pendingWorldMs,next-s.marketTime)
    }
}
