package com.wealthempire.core.market

import com.wealthempire.core.models.*
import com.wealthempire.core.world.*
import kotlin.math.*

object PriceEngine {
    fun fair(s:GameState,a:AssetSpec):Double {
        val w=s.world;val us=w.economies["USA"] ?: return a.initialPrice.toDouble()
        val p=a.initialPrice.toDouble();val c=w.commodities
        val value=when(a.kind){
            AssetKind.STOCK->{val co=w.companies[a.symbol]
                if(a.isEtf) {
                    val basket=w.companies.values.filter {when(a.symbol){"SOXX"->it.sector in listOf("chips","semiconductors");"QQQ"->it.sector in listOf("tech","chips","media","retail");else->true}}
                    val ratio=if(basket.isEmpty())1.0 else basket.map {it.eps*it.valuation*it.guidance*(w.sectors[it.sector] ?: 1.0)/max(it.referencePrice,1e-8)}.average()
                    p*ratio*exp(-.075*(us.yield10-4.1)+.09*(us.credit-1))
                } else if(co==null)p*(w.sectors[a.sector] ?: 1.0)*(1+.05*(us.growth-2))
                else co.eps*co.valuation*co.guidance*(w.sectors[a.sector] ?: 1.0)*exp(-.075*(us.yield10-4.1)+.09*(us.credit-1)+.025*(co.cash-co.debt)/max(co.revenue,1.0)+co.sentiment*.2)}
            AssetKind.CRYPTO->{if(a.stable)return p
                val n=w.networks[a.symbol] ?: Network();val beta=if(a.symbol=="BTC")1.0 else if(a.symbol=="ETH")1.15 else 1.6
                p*exp(beta*(.7*ln(w.stablecoinLiquidity.coerceAtLeast(.1))+.7*(w.riskAppetite-.5)-.18*w.regulation)+
                    .5*w.etfFlows*n.institutional+.2*(w.institutionalDemand-1)*n.institutional+
                    .35*ln(n.activity.coerceAtLeast(.1))+.2*(n.developers-1)-.65*(1-n.security)-.3*n.unlockPressure-.15*(n.reserves-1)+
                    (if(a.symbol=="BTC")-.04*(n.energyCost-1) else if(a.symbol=="ETH").12*(n.staking-.3) else -.2*(w.btcDominance-.54)) +
                    (w.tokens[a.symbol]?.let { .18*(it.team-.5)+.12*(it.hype-.5)+.1*(it.investorInterest-.5)-.45*ln((it.circulating/(it.supply*.1)).coerceAtLeast(.1)) } ?: 0.0))}
            AssetKind.COMMODITY->when(a.sector){
                "energy"->p*exp(1.7*(c.oilDemand-c.oilSupply)-.55*(c.inventories-1)+.7*c.disruption+.25*(1-c.shipping))
                "gas"->p*exp(.65*(c.winterDemand-1)-.8*(c.gasStorage-1)-.4*(c.gasProduction-1)+.25*(c.lng-1)+.5*c.disruption)
                "metals"->p*exp(-.12*((us.yield10-us.inflation)-(4.1-2.8))-.08*(us.yield2-4.3)+.12*(c.goldDemand-1)+.18*c.disruption)
                else->p*exp(.1*(w.globalGrowth-2)+.15*(w.globalTrade-1))
            }
            AssetKind.FOREX->{val region=when(a.symbol){"EUR","GBP"->"Europe";"CNY","AUD"->"China";"JPY"->"Japan";else->"USA"};val e=w.economies.getValue(region)
                val baseRate=when(region){"Europe"->3.25;"China"->3.0;"Japan"->.5;else->4.5}
                p*exp(.09*((e.yield2-us.yield2)-(baseRate-4.5))+.025*(e.growth-us.growth)+.03*(us.inflation-e.inflation)+
                    (if(a.symbol=="JPY" || a.symbol=="CHF").08*(w.fear-18)/20 else if(a.symbol=="CAD").12*(c.oilDemand-c.oilSupply) else if(a.symbol=="AUD").1*(w.riskAppetite-.5) else 0.0))}
            AssetKind.BOND->p*exp(-(if(a.symbol=="US2Y")1.8 else 7.5)*((if(a.symbol=="US2Y")us.yield2-4.3 else us.yield10-4.1)/100))
        }
        return value.coerceIn(p*.04,p*10000)
    }
    fun move(s:GameState,a:AssetSpec,q:Quote,dt:Long,common:Double,rng:RandomSource):Double {
        val fair=fair(s,a);val oldAnchor=q.fundamentalAnchor.takeIf {it>0} ?: 1.0
        val anchor=fair/a.initialPrice.toDouble();val reprice=(ln(anchor/oldAnchor)*.42).coerceIn(-.3,.3)
        q.fundamentalAnchor=anchor
        val annual=when(a.kind){AssetKind.CRYPTO->if(a.symbol=="BTC").5 else if(a.symbol=="ETH").62 else .9+a.risk*.08;AssetKind.STOCK->.22+a.risk*.035;AssetKind.COMMODITY->if(a.sector=="gas").65 else .32;AssetKind.FOREX->.1;AssetKind.BOND->.045}
        val years=dt/31_536_000_000.0
        val convergence=(ln(fair/q.price.toDouble())*(1-exp(-dt/1_209_600_000.0))).coerceIn(-.12,.12)
        val stress=1+s.world.newsStress*.9
        val random=annual*sqrt(years)*stress*(common*.65+rng.normal()*.65)
        val shock=q.pendingJump+q.eventBias*min(1.0,dt/60_000.0)*.15
        q.pendingJump=0.0;q.eventBias*=exp(-dt/300_000.0)
        val result=(reprice+convergence+random+shock).coerceIn(-.4,.35)
        val cap=a.marketCap.toDouble()*(q.price.toDouble()/a.initialPrice.toDouble())
        val m=s.world.micro.getOrPut(a.symbol){Microstructure()}
        m.depth=(cap*.0015*(.35+s.world.globalLiquidity)/(1+s.world.newsStress*2)).coerceAtLeast(5000.0)
        m.spread=(.00012+1200/max(m.depth,1.0)+.0002*s.world.newsStress+a.risk*.000025).coerceIn(.0001,.035)
        m.volume=max(100.0,cap*.15*years*(1+abs(result)*100))
        m.longFraction=(.5+.13*(s.world.riskAppetite-.5)+result*2).coerceIn(.15,.85)
        m.openInterest=(cap*(.03+.04*abs(m.longFraction-.5))).coerceAtLeast(1000.0)
        m.basis=((m.longFraction-.5)*.002+result*.01).coerceIn(-.004,.004)
        m.funding=((m.longFraction-.5)*.00025+m.basis*.03+ln(m.openInterest/max(cap*.03,1.0))*.00001).coerceIn(-.0007,.0007)
        m.volatility=annual*stress;m.liquidationCluster=(q.price.toDouble()*(1-.018*sign(m.longFraction-.5))).coerceAtLeast(.00000001)
        return result
    }
    fun slippage(s:GameState,symbol:String,size:Double):Double {
        val m=s.world.micro[symbol] ?: return .0002
        return (m.spread/2+.0015*(size/max(m.depth,1.0)).pow(.65)).coerceIn(0.0,.06)
    }
}
