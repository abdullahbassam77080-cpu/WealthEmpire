package com.wealthempire.core.wallet

import com.wealthempire.core.models.*
import com.wealthempire.core.trading.FuturesMath
import java.math.BigDecimal

object WalletRules {
    fun transfer(s: GameState,from: Wallet,to: Wallet,amount: BigDecimal) {
        require(from != to && amount > ZERO) { "invalid_amount" }
        require(s.balance(from) >= amount) { "insufficient_balance" }
        if(from == Wallet.FUTURES) {
            val requirement=FuturesMath.crossRequirement(s)
            require(FuturesMath.crossEquity(s)-amount > requirement || requirement == ZERO) { "cross_collateral" }
        }
        s.credit(from,-amount); s.credit(to,amount)
    }
}
