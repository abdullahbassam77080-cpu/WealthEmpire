package com.wealthempire.core.trading
import com.wealthempire.core.models.*
import java.math.BigDecimal
data class LiquidationRange(val lower:BigDecimal?,val upper:BigDecimal?,val unsafeNow:Boolean=false)
internal object LiquidationSolver {
    fun bounds(mark:BigDecimal,searchUpper:Boolean=true,safety:(BigDecimal)->BigDecimal):LiquidationRange {
        require(mark>ZERO)
        if(safety(mark)<=ZERO)return LiquidationRange(mark,mark,true)
        val lower=if(safety(ZERO)<ZERO)bisect(ZERO,mark,true,safety) else null
        if(!searchUpper)return LiquidationRange(lower,null)
        var upper:BigDecimal?=null;var edge=mark*d(2)
        repeat(128){if(upper==null){if(safety(edge)<=ZERO)upper=bisect(mark,edge,false,safety) else edge*=d(2)}}
        return LiquidationRange(lower,upper)
    }
    private fun bisect(left:BigDecimal,right:BigDecimal,leftUnsafe:Boolean,safety:(BigDecimal)->BigDecimal):BigDecimal {
        var a=left;var b=right
        repeat(100){val m=(a+b).divD(d(2));if((safety(m)<=ZERO)==leftUnsafe)a=m else b=m}
        return (a+b).divD(d(2))
    }
}
