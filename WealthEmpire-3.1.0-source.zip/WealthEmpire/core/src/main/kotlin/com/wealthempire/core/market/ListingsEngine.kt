package com.wealthempire.core.market

import com.wealthempire.core.models.*
import kotlin.math.exp

class ListingsEngine(private val market:MarketEngine) {
    private val projects=listOf(
        Triple("ORBIT","Orbit Network","شبكة أوربت"),Triple("LUMEN","Lumen Compute","لومن للحوسبة"),
        Triple("NOVA","Nova Layers","طبقات نوفا"),Triple("VAULT","Vault Storage","فولت للتخزين"),
        Triple("AERO","Aero Payments","إيرو للمدفوعات"),Triple("FLUX","Flux Protocol","بروتوكول فلكس"),
        Triple("PULSE","Pulse Data","بولس للبيانات"),Triple("VERA","Vera Finance","فيرا فاينانس"),
        Triple("AXIS","Axis Mesh","شبكة أكسيس"),Triple("PRISM","Prism AI","بريزم للذكاء الاصطناعي"),
        Triple("ROOT","Root Chain","روت تشين"),Triple("ECHO","Echo Labs","إيكو لابز")
    )
    fun initialize(s:GameState) {
        if(s.listings.isNotEmpty())return
        val rng=RandomSource(s)
        listOf(30*60_000L,6*NewsEngine.HOUR,2*NewsEngine.DAY).forEach {create(s,rng,s.marketTime+it)}
    }
    private fun create(s:GameState,rng:RandomSource,opens:Long) {
        val base=projects[rng.index(projects.size)]
        val serial=s.listings.size+1;val symbol=base.first+serial
        val sectors=listOf("AI infrastructure","DeFi credit","data availability","decentralized storage","payments","Layer 2")
        val narrative=sectors[rng.index(sectors.size)]
        val price=d(exp(-3.0+rng.next()*5.0)).money()
        val spec=AssetSpec(symbol,base.second+" $serial",AssetKind.CRYPTO,price,.0025+rng.next()*.0035,
            d(8_000_000+rng.next()*200_000_000).money(),5,"emerging","token",base.third+" $serial")
        val listing=AssetListing(s.id(),spec,s.marketTime,opens,narrative=narrative)
        s.listings.add(listing)
        s.world.tokens[symbol]=com.wealthempire.core.world.Tokenomics(symbol,.25+rng.next()*.7,1e9,1e8,.2+rng.next()*.8,rng.next(),opens+30*NewsEngine.DAY)
        market.news.publish(s,"listing_announced",symbol,0.0,NewsEngine.DAY,.0,
            "إدراج مرتقب: ${spec.nameAr} (${spec.symbol})", "Upcoming listing: ${spec.name} (${spec.symbol})",
            "مشروع افتراضي جديد؛ لا توجد أسعار تنفيذ قبل الافتتاح. السعر الافتتاحي والسيولة قد يختلفان عن التقدير الأولي.",
            "New fictional project; execution is unavailable before opening. Opening price and liquidity may differ from initial estimates.")
    }
    fun step(s:GameState,rng:RandomSource) {
        for(listing in s.listings.filter {it.status==ListingStatus.UPCOMING && it.opensAt<=s.marketTime}) {
            listing.status=ListingStatus.LIVE
            s.world.networks[listing.spec.symbol]=com.wealthempire.core.world.Network(institutional=.1)
            val opening=(listing.spec.initialPrice*d(exp((rng.normal()*.15).coerceIn(-.45,.45)))).money().max(d("0.00000001"))
            market.seedAsset(s,listing.spec.copy(initialPrice=opening),false)
            market.news.publish(s,"listing_live",listing.spec.symbol,0.0,NewsEngine.DAY,1.0,
                "بدأ تداول ${listing.spec.symbol}: سيولة أولية وتقلب مرتفع", "${listing.spec.symbol} trading opens with thin liquidity and high volatility",
                "التداول الفوري متاح. قد تكون الحركة في الاتجاهين حادة؛ لا يضمن الإدراج صعود السعر.",
                "Spot trading is available. Sharp moves can occur in either direction; a listing does not guarantee appreciation.")
        }
        if(s.marketTime>=s.economy.nextListingAt && s.listings.size<64) {
            create(s,rng,s.marketTime+(6+rng.index(43))*NewsEngine.HOUR)
            s.economy.nextListingAt=s.marketTime+(5+rng.index(10))*NewsEngine.DAY
        }
    }
}
