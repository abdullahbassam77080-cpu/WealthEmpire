package com.wealthempire.core.market

import com.wealthempire.core.models.*
import java.time.Instant
import java.time.ZoneOffset
import java.util.Locale
import kotlin.math.*

class NewsEngine(private val market:MarketEngine) {
    companion object {const val HOUR=3_600_000L;const val DAY=24*HOUR}
    fun initialize(s:GameState) {
        val e=s.economy;if(e.initialized)return
        val rng=RandomSource(s);e.initialized=true
        e.nextRandomNewsAt=s.marketTime+(5+rng.index(16))*60_000L
        e.nextPolicyAt=s.marketTime+7*DAY;e.nextInflationAt=s.marketTime+2*DAY
        e.nextJobsAt=s.marketTime+4*DAY;e.nextInventoryAt=s.marketTime+DAY
        e.nextEarningsAt=s.marketTime+(3+rng.index(9))*HOUR
        e.nextListingAt=s.marketTime+3*DAY
    }
    fun step(s:GameState,rng:RandomSource) {
        initialize(s)
        val e=s.economy
        if(s.marketTime>=e.nextPolicyAt) { policy(s,rng); e.nextPolicyAt+=42*DAY }
        if(s.marketTime>=e.nextInflationAt) { inflation(s,rng);e.nextInflationAt+=30*DAY }
        if(s.marketTime>=e.nextJobsAt) { jobs(s,rng);e.nextJobsAt+=30*DAY }
        if(s.marketTime>=e.nextInventoryAt) {inventory(s,rng);e.nextInventoryAt+=7*DAY }
        if(s.marketTime>=e.nextEarningsAt) {
            emit(s,if(rng.next()<.53)"earnings_surprise" else "profit_warning",rng)
            e.nextEarningsAt=s.marketTime+(12+rng.index(36))*HOUR
        }
        for(story in s.stories.filter {it.nextAt<=s.marketTime}.toList()) {
            s.stories.remove(story);followUp(s,story,rng)
        }
        if(s.marketTime>=e.nextRandomNewsAt) {
            val available=NewsTemplates.all.filter {it.key !in e.lastNewsKeys && canTarget(s,it.scope)}
            if(available.isNotEmpty()) {
                val month=Instant.ofEpochMilli(s.marketTime).atZone(ZoneOffset.UTC).monthValue
                fun weight(t:NewsTemplate)=t.weight*if(t.key=="gas_cold" && month in listOf(11,12,1,2))1.8 else 1.0
                var draw=rng.next()*available.sumOf(::weight)
                val chosen=available.firstOrNull {draw-=weight(it);draw<=0} ?: available.last()
                emit(s,chosen.key,rng)
                e.lastNewsKeys.add(chosen.key);while(e.lastNewsKeys.size>6)e.lastNewsKeys.removeAt(0)
            }
            // Saved exponential waiting time: not a fixed 90-tick headline cycle.
            val wait=(-ln((1-rng.next()).coerceAtLeast(1e-9))*180).toLong().coerceIn(8,1080)
            e.nextRandomNewsAt=s.marketTime+wait*60_000
        }
        s.effects.removeAll {it.expiresAt<=s.marketTime}
        e.riskAppetite*=.9998;e.dollarPressure*=.99998;e.energySupply*=.99995;e.cryptoTrust*=.9999
    }
    private fun canTarget(s:GameState,scope:String)=when(scope) {
        "CRYPTO_ONE"->market.assets(s).any {it.kind==AssetKind.CRYPTO && !it.stable}
        "STOCK_ONE"->market.assets(s).any {it.kind==AssetKind.STOCK && !it.legacy && it.referenceSymbol==null}
        else->true
    }
    fun emit(s:GameState,key:String,rng:RandomSource=RandomSource(s),symbol:String?=null,randomSign:Boolean=false) {
        val t=NewsTemplates.all.first {it.key==key}
        val candidates=market.assets(s).filter {
            when(t.scope) {"CRYPTO_ONE"->it.kind==AssetKind.CRYPTO && !it.stable
                "STOCK_ONE"->it.kind==AssetKind.STOCK && !it.legacy && it.referenceSymbol==null
                else->false}
        }
        val target=symbol ?: if(candidates.isNotEmpty())candidates[rng.index(candidates.size)].symbol else t.scope
        val spec=market.assets(s).firstOrNull {it.symbol==target}
        val variant=rng.index(t.ar.size)
        val severity=.55+rng.next()*1.15
        val sign=if(randomSign || t.shock==0.0)if(rng.next()<.5)-1 else 1 else 1
        val impact=(if(t.shock==0.0).02 else t.shock)*severity*sign
        val duration=(t.hours*HOUR*(.6+rng.next()*.9)).toLong()
        val detailAr=when(t.family) {
            NewsFamily.SECURITY->"التقديرات أولية، وقد تؤكد التحقيقات اللاحقة الضرر أو تقلّصه. يتحقق السوق من السيولة واستمرار الخدمات."
            NewsFamily.COMPANY->"يوازن المستثمرون النتائج مع التوقعات السابقة وهوامش الربح والتوجيهات المقبلة. قد تختلف استجابة الشركات الأخرى."
            NewsFamily.ENERGY->"تتفاعل الأسعار مع المخزون والطلب والإمدادات؛ وقد تغير تقارير لاحقة تقدير حجم الاضطراب."
            NewsFamily.POLICY->"يعتمد رد السوق على المفاجأة مقارنة بالتوقعات، وقد يظل الأثر الاقتصادي ممتدًا خلال جلسات لاحقة."
            else->"تصل التدفقات إلى الأسواق بسرعات مختلفة. لا يضمن هذا التقرير استمرار اتجاه السعر، وقد تصدر معلومات جديدة."
        }
        val detailEn=when(t.family) {
            NewsFamily.SECURITY->"Estimates are preliminary. Further investigation may confirm or reduce the damage; liquidity and service continuity are being assessed."
            NewsFamily.COMPANY->"Investors compare results with prior expectations, margins and future guidance. Other companies may react differently."
            NewsFamily.ENERGY->"Storage, demand and supply interact. Later reports may revise the estimated disruption."
            NewsFamily.POLICY->"The reaction depends on the surprise relative to expectations, with economic effects continuing across later sessions."
            else->"Flows reach markets at different speeds. The report does not guarantee a continuing price direction; new information may follow."
        }
        val storyId=if(t.family in listOf(NewsFamily.SECURITY,NewsFamily.CREDIT,NewsFamily.GEOPOLITICS) && rng.next()<.72)s.id() else 0L
        publish(s,key,target,impact,duration,t.vol,
            t.ar[variant].replace("{asset}",spec?.nameAr ?: target),t.en[variant].replace("{asset}",spec?.name ?: target),detailAr,detailEn,storyId)
        if(storyId!=0L && s.stories.size<20)s.stories.add(MarketStory(storyId,t.family,target,
            s.marketTime+(3+rng.index(94))*HOUR,severity))
        when(t.family) {
            NewsFamily.CREDIT->s.economy.riskAppetite=(s.economy.riskAppetite+impact*3).coerceIn(-1.0,1.0)
            NewsFamily.SECURITY->s.economy.cryptoTrust=(s.economy.cryptoTrust+impact*.5).coerceIn(-1.0,1.0)
            NewsFamily.ENERGY->s.economy.energySupply=(s.economy.energySupply-impact).coerceIn(-1.0,1.0)
            else->Unit
        }
    }
    private fun followUp(s:GameState,story:MarketStory,rng:RandomSource) {
        val resolved=rng.next()<(.6-story.severity*.12).coerceIn(.25,.7)
        val spec=market.assets(s).firstOrNull {it.symbol==story.symbol}
        val nameAr=spec?.nameAr ?: "الأسواق";val nameEn=spec?.name ?: "markets"
        val impact=(if(resolved).04 else -.065)*(.5+rng.next())
        publish(s,if(resolved)"story_recovery" else "story_escalation",story.symbol,impact,(2+rng.index(12))*DAY,
            if(resolved).25 else 1.3,
            if(resolved)"متابعة: معلومات جديدة تخفف مخاوف $nameAr" else "متابعة: التحقيق يكشف مخاطر إضافية على $nameAr",
            if(resolved)"Follow-up: new information eases $nameEn concerns" else "Follow-up: investigation reveals additional $nameEn risks",
            if(resolved)"الضرر أقل من التقديرات الأولى، لكن التعافي يعتمد على عودة الثقة والسيولة." else "اتساع نطاق المشكلة يغير تقدير المستثمرين؛ لا تزال بعض التفاصيل غير محسومة.",
            if(resolved)"Damage is below initial estimates; recovery depends on returning confidence and liquidity." else "A broader problem changes investor estimates; some details remain unresolved.",story.id)
        if(!resolved && story.stage<2 && rng.next()<.55)s.stories.add(story.copy(nextAt=s.marketTime+(1+rng.index(9))*DAY,stage=story.stage+1))
    }
    private fun policy(s:GameState,rng:RandomSource) {
        val old=s.economy.policyRate
        val expected=when {s.economy.inflation>3.2->.25;s.economy.growth<.8->-.25;else->0.0}
        val options=listOf(-.5,-.25,0.0,0.0,.25,.5)
        val actual=options[rng.index(options.size)]
        s.economy.policyRate=(old+actual).coerceIn(0.0,12.0)
        val change=s.economy.policyRate-old;val surprise=change-expected
        s.economy.dollarPressure=(s.economy.dollarPressure+surprise*.35).coerceIn(-1.0,1.0)
        val number=String.format(Locale.US,"%.2f",s.economy.policyRate)
        val exp=String.format(Locale.US,"%+.2f",expected);val move=String.format(Locale.US,"%+.2f",change)
        publish(s,"policy_decision","USD_POLICY",-surprise*.09,42*DAY,.7,
            "قرار فائدة الدولار: $number% بعد تغيير $move نقطة", "USD policy decision: $number% after a $move point change",
            "توقع السوق تغييرًا بمقدار $exp نقطة. تقارن الأسعار القرار والتوجيهات بالتوقعات؛ تستمر آثار التمويل والدولار إلى القرارات المقبلة.",
            "The market expected a $exp point change. Prices compare the decision and guidance with expectations; funding and dollar effects persist into future decisions.")
    }
    private fun inflation(s:GameState,rng:RandomSource) {
        val expected=s.economy.inflation;val actual=(expected+rng.normal()*.45).coerceIn(-.5,10.0)
        s.economy.inflation=actual
        val surprise=actual-expected;s.economy.dollarPressure=(s.economy.dollarPressure+surprise*.08).coerceIn(-1.0,1.0)
        publish(s,"inflation_report","USD_POLICY",-surprise*.04,30*DAY,.55,
            "تقرير التضخم: ${fmt(actual)}% مقابل توقع ${fmt(expected)}%", "Inflation report: ${fmt(actual)}% versus ${fmt(expected)}% expected",
            "تغير مفاجأة التضخم توقعات الفائدة والقوة الشرائية؛ تتباين استجابة الذهب والعملات وأسهم النمو.",
            "The inflation surprise changes rate and purchasing-power expectations; gold, currencies and growth stocks respond differently.")
    }
    private fun jobs(s:GameState,rng:RandomSource) {
        val surprise=rng.normal();s.economy.growth=(s.economy.growth+surprise*.35).coerceIn(-3.0,6.0)
        publish(s,"jobs_report","GLOBAL",surprise*.012,20*DAY,.3,
            "بيانات التوظيف ${if(surprise>0)"تتجاوز" else "دون"} التوقعات؛ مراجعة آفاق النمو",
            "Jobs data ${if(surprise>0)"beats" else "misses"} expectations; growth outlook revised",
            "قد يدعم النشاط القوي الأرباح لكنه يرفع احتمالات تشدد الفائدة؛ وزن العاملين يتغير مع سياق الاقتصاد.",
            "Strong activity can support earnings while raising tightening expectations; their balance depends on the economic context.")
    }
    private fun inventory(s:GameState,rng:RandomSource) {
        val expected=rng.normal()*1.2;val actual=expected+rng.normal()*2.4
        val surprise=actual-expected
        publish(s,"oil_inventory","OIL",-surprise*.015,7*DAY,.6,
            "مخزون النفط: تغير ${fmt(actual)} مليون برميل مقابل توقع ${fmt(expected)}",
            "Oil inventory: ${fmt(actual)} million barrel change versus ${fmt(expected)} expected",
            "تُقارن الزيادة أو السحب بتوقعات المحللين والطلب على المصافي؛ قد تختلف استجابة الغاز الطبيعي.",
            "The build or draw is compared with expectations and refinery demand; natural gas can respond differently.")
    }
    private fun fmt(v:Double)=String.format(Locale.US,"%.2f",v)
    fun publish(s:GameState,key:String,target:String,impact:Double,duration:Long,vol:Double,
        ar:String,en:String,detailAr:String="",detailEn:String="",storyId:Long=0) {
        val id=s.id()
        s.news.add(0,News(id,key,target,impact,s.marketTime,ar,en,detailAr,detailEn,"نشرة المحاكاة المالية","Simulation Market Wire",storyId))
        while(s.news.size>160)s.news.removeAt(s.news.lastIndex)
        if(abs(impact)>=.035)GameAlerts.enqueue(s,GameAlert(id,AlertType.NEWS,key,target,s.marketTime))
        val halfLife=(duration/3).coerceAtLeast(60_000L)
        val decay=exp(-60_000.0/halfLife)
        val totalWeights=(1-exp(-duration.toDouble()/halfLife))/(1-decay)
        for(q in s.quotes) {
            val spec=market.spec(q.symbol,s);if(spec.stable || spec.referenceSymbol!=null)continue
            val exposure=exposure(spec,target,key)
            if(exposure==0.0)continue
            q.pendingJump+=(impact*exposure*.65).coerceIn(-.5,.5)
            s.effects.add(MarketEffect(id,q.symbol,s.marketTime,s.marketTime+duration,
                impact*exposure*.35/totalWeights,vol*abs(exposure),halfLife,storyId))
        }
        while(s.effects.size>1200)s.effects.removeAt(0)
    }
    internal fun exposure(a:AssetSpec,target:String,key:String):Double {
        if(a.symbol==target)return 1.0
        return when(target) {
            "USD_POLICY"->when {a.kind==AssetKind.FOREX->if(a.symbol=="JPY" || a.symbol=="CHF").8 else 1.0
                a.symbol=="XAU"->1.2;a.kind==AssetKind.CRYPTO->1.1
                a.kind==AssetKind.STOCK->if(a.sector=="banks")-.15 else if(a.sector=="tech" || a.sector=="chips")1.2 else .65
                a.kind==AssetKind.COMMODITY->.35;else->0.0}
            "CRYPTO"->if(a.kind==AssetKind.CRYPTO)1.0 else if(a.symbol=="XAU")-.15 else 0.0
            "CHIPS"->if(a.sector=="chips")1.0 else if(a.sector=="tech").25 else 0.0
            "BANKS"->if(a.sector=="banks")1.0 else if(a.kind==AssetKind.STOCK).25 else if(a.symbol=="XAU")-.6 else 0.0
            "OIL"->if(a.symbol in listOf("WTI","BRENT"))1.0 else if(a.kind==AssetKind.STOCK && a.sector=="energy").55 else if(a.sector=="industrial")-.15 else 0.0
            "GAS"->if(a.symbol=="NATGAS")1.0 else if(a.symbol in listOf("WTI","BRENT")) .1 else 0.0
            "GOLD"->if(a.symbol=="XAU")1.0 else if(a.symbol=="XAG").4 else 0.0
            "METALS"->if(a.sector=="metals" || a.symbol=="COPPER")1.0 else 0.0
            "INDUSTRIAL"->if(a.sector=="industrial" || a.symbol in listOf("WTI","BRENT"))1.0 else if(a.kind==AssetKind.STOCK).2 else 0.0
            "GLOBAL","ALL"->when {
                a.symbol=="XAU"->-.8;a.symbol=="CHF" || a.symbol=="JPY"->-.45
                key=="geopolitical_risk" && a.symbol in listOf("WTI","BRENT","NATGAS")->-.8
                a.kind==AssetKind.CRYPTO->1.15;a.kind==AssetKind.STOCK->1.0
                a.kind==AssetKind.COMMODITY->.5;a.kind==AssetKind.FOREX->.25;else->0.0}
            else->0.0
        }
    }
}
