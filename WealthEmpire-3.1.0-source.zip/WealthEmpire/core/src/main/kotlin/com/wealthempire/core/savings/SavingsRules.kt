package com.wealthempire.core.savings

import com.wealthempire.core.market.*
import com.wealthempire.core.models.*
import java.math.BigDecimal

/** APR is annual; rewards and principal are denominated in the subscribed token, never dollars. */
object SavingsRules {
    const val DAY=86_400_000L
    val YEAR=d(365L*DAY)
    fun seed(s:GameState,market:MarketEngine) {
        for(a in market.assets(s).filter {it.kind==AssetKind.CRYPTO}) {
            if(s.savingsOffers.any {it.symbol==a.symbol})continue
            if(s.listings.any {it.spec.symbol==a.symbol && s.marketTime<it.opensAt+7*DAY})continue
            val base=when(a.symbol){"BTC"->d("0.5");"ETH"->d("3.2");"SOL"->d("5.5");"BNB"->d("1.8");"USDT"->d("2.5");else->d("1.5")}
            val quota=when(a.symbol){"USDT"->d(500);else->d(1000).divD(a.initialPrice)}
            s.savingsOffers.add(SavingsOffer(a.symbol,base,d("1.5"),quota,base+d("1.2"),base+d("2.2"),(s.marketTime/DAY+1)*DAY))
        }
    }
    fun available(s:GameState,symbol:String):BigDecimal {
        if(symbol=="USDT")return s.spotCash.positive()
        val held=s.holdings.firstOrNull {it.symbol==symbol}?.quantity ?: ZERO
        val reserved=s.orders.filter {it.symbol==symbol && it.venue==OrderVenue.SPOT && it.side==Side.SHORT}
            .fold(ZERO){sum,it->sum+it.amount}
        return (held-reserved).positive()
    }
    fun flexibleApr(s:GameState,symbol:String,extra:BigDecimal=ZERO):BigDecimal {
        val offer=s.savingsOffers.first {it.symbol==symbol}
        val total=s.savings.filter {it.symbol==symbol && it.days==0 && it.status==SavingsStatus.ACTIVE}
            .fold(extra){sum,p->sum+p.principal+if(p.autoCompound)p.distributed else ZERO}
        return if(total<=ZERO)offer.baseApr+offer.bonusApr else
            offer.baseApr+offer.bonusApr*minOf(total,offer.bonusQuota).divD(total)
    }
    fun dailyEstimate(s:GameState,symbol:String,quantity:BigDecimal,days:Int):BigDecimal {
        val offer=s.savingsOffers.first {it.symbol==symbol}
        val apr=when(days){0->flexibleApr(s,symbol,quantity);30->offer.locked30Apr;90->offer.locked90Apr;else->throw IllegalArgumentException("invalid_savings_term")}
        return quantity*apr.divD(d(100L*365))
    }
    fun subscribe(s:GameState,market:MarketEngine,symbol:String,quantity:BigDecimal,days:Int,compound:Boolean,now:Long) {
        require(days in listOf(0,30,90)){"invalid_savings_term"}
        require(quantity>ZERO && quantity<=d("1000000000000")){"invalid_amount"}
        require(s.savingsOffers.any {it.symbol==symbol}){"savings_unavailable"}
        require(available(s,symbol)>=quantity){"insufficient_holding"}
        advance(s,market,now)
        val offer=s.savingsOffers.first {it.symbol==symbol}
        val basis=if(symbol=="USDT") {s.credit(Wallet.SPOT,-quantity);quantity} else {
            val holding=s.holdings.first {it.symbol==symbol}
            val cost=holding.cost*quantity.divD(holding.quantity)
            holding.quantity-=quantity;holding.cost-=cost
            if(holding.quantity<=ZERO)s.holdings.remove(holding)
            cost
        }
        val rate=when(days){30->offer.locked30Apr;90->offer.locked90Apr;else->ZERO}
        val p=SavingsPosition(s.id(),symbol,quantity,basis,days,rate,subscribedAt=now,
            maturesAt=if(days==0)Long.MAX_VALUE else now+days*DAY,lastAccruedAt=now,nextPayoutAt=(now/DAY+1)*DAY,autoCompound=days==0 && compound)
        s.savings.add(p);record(s,p,"SUBSCRIBE",quantity,if(days==0)flexibleApr(s,symbol) else rate,now)
    }
    /** Settle old-rate intervals before daily offer changes; no rounding gain from rapid ticks. */
    fun advance(s:GameState,market:MarketEngine,now:Long) {
        seed(s,market)
        while(true) {
            val boundaries=s.savingsOffers.map {it.nextRateAt}+
                s.savings.map {if(it.status==SavingsStatus.REDEEMING)it.redeemAt else minOf(it.maturesAt,it.nextPayoutAt)}
            val end=minOf(now,boundaries.minOrNull() ?: now)
            val apr=s.savingsOffers.associate {it.symbol to flexibleApr(s,it.symbol)}
            for(p in s.savings.toList()) {
                if(p.status==SavingsStatus.REDEEMING) {
                    if(p.redeemAt<=end) {restore(s,p.symbol,p.principal,p.costBasis);record(s,p,"REDEEM",p.principal,p.fixedApr,end);s.savings.remove(p)}
                    continue
                }
                val elapsed=(end-p.lastAccruedAt).coerceAtLeast(0)
                val rate=if(p.days==0)apr[p.symbol]!! else p.fixedApr
                val base=p.principal+if(p.days==0 && p.autoCompound)p.distributed else ZERO
                val reward=(base*rate*d(elapsed)).divD(YEAR*d(100))
                p.rewards+=reward;p.historyReward+=reward;p.lastAccruedAt=maxOf(p.lastAccruedAt,end)
                if(p.days==0)s.stats.savings+=reward*s.quote(p.symbol).price
                if(p.nextPayoutAt<=end) {
                    if(p.days>0)payLocked(s,p,end)
                    else {p.distributed=p.rewards;record(s,p,"REWARD",p.historyReward,rate,end);p.historyReward=ZERO}
                    p.nextPayoutAt+=DAY;p.lastHistoryAt=end
                }
                if(p.maturesAt<=end) {
                    payLocked(s,p,end)
                    restore(s,p.symbol,p.principal,p.costBasis)
                    record(s,p,"MATURED",p.principal,p.fixedApr,end);s.savings.remove(p)
                }
            }
            val rng=RandomSource(s)
            for(offer in s.savingsOffers.filter {it.nextRateAt<=end}) {
                val anchor=when(offer.symbol){"BTC"->.5;"ETH"->3.2;"SOL"->5.5;"BNB"->1.8;"USDT"->s.economy.policyRate*.6;else->1.5}
                val rate=(offer.baseApr.toDouble()*.9+anchor*.1+rng.normal()*.04).coerceIn(.05,10.0)
                offer.baseApr=d(rate).setScale(3,java.math.RoundingMode.HALF_EVEN)
                offer.bonusApr=d((1.5+s.economy.riskAppetite*.3).coerceIn(.5,2.5))
                offer.locked30Apr=offer.baseApr+d("1.2");offer.locked90Apr=offer.baseApr+d("2.2")
                offer.nextRateAt+=DAY
            }
            if(end>=now)break
        }
    }
    private fun payLocked(s:GameState,p:SavingsPosition,time:Long) {
        if(p.rewards<=ZERO)return
        val reward=p.rewards
        restore(s,p.symbol,reward,ZERO);val value=reward*s.quote(p.symbol).price
        p.distributed+=reward;p.distributedUsd+=value;s.stats.savings+=value
        record(s,p,"REWARD",reward,p.fixedApr,time);p.rewards=ZERO;p.historyReward=ZERO
    }
    fun redeem(s:GameState,market:MarketEngine,id:Long,fraction:BigDecimal,now:Long) {
        require(fraction>ZERO && fraction<=ONE){"invalid_fraction"}
        val original=s.savings.firstOrNull {it.id==id} ?: throw IllegalArgumentException("savings_missing")
        require(original.status==SavingsStatus.ACTIVE){"redemption_pending"}
        require(original.days==0 || fraction==ONE){"locked_full_redemption"}
        advance(s,market,now)
        val p=s.savings.firstOrNull {it.id==id} ?: return // Matured automatically during settlement.
        if(p.days==0) {
            val returned=(p.principal+p.rewards)*fraction;val basis=p.costBasis*fraction
            restore(s,p.symbol,returned,basis);record(s,p,"REDEEM",returned,flexibleApr(s,p.symbol),now)
            if(fraction==ONE)s.savings.remove(p) else {
                p.principal-=p.principal*fraction;p.rewards-=p.rewards*fraction
                p.distributed-=p.distributed*fraction;p.costBasis-=basis;p.historyReward-=p.historyReward*fraction
            }
        } else {
            val forfeited=p.rewards+p.distributed
            p.principal=(p.principal-p.distributed).positive();p.rewards=ZERO
            s.stats.savings-=p.distributedUsd
            // Original cost basis stays with the reduced returned principal: no artificial sale profit.
            p.status=SavingsStatus.REDEEMING;p.redeemAt=now+3*DAY
            record(s,p,"FORFEIT",forfeited,p.fixedApr,now)
        }
    }
    private fun restore(s:GameState,symbol:String,quantity:BigDecimal,cost:BigDecimal) {
        if(symbol=="USDT") {s.credit(Wallet.SPOT,quantity);return}
        val h=s.holdings.firstOrNull {it.symbol==symbol} ?: Holding(symbol).also {s.holdings.add(it)}
        h.quantity+=quantity;h.cost+=cost
    }
    private fun record(s:GameState,p:SavingsPosition,action:String,quantity:BigDecimal,apr:BigDecimal,time:Long) {
        if(quantity==ZERO && action=="REWARD")return
        s.savingsHistory.add(0,SavingsRecord(s.id(),p.id,p.symbol,action,quantity,apr,time))
        while(s.savingsHistory.size>400)s.savingsHistory.removeAt(s.savingsHistory.lastIndex)
    }
}
