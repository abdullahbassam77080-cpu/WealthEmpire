package com.wealthempire.core.events

import com.wealthempire.core.models.*
import com.wealthempire.core.world.*
import com.wealthempire.core.market.*
import com.wealthempire.core.economy.EconomicEngine
import kotlin.math.*
import java.util.Locale

/** Domain events update fundamentals first. Headlines are projections of saved events. */
object EventEngine {
    private const val DAY=86_400_000L
    fun initialize(s:GameState) {
        if(s.world.calendar.isNotEmpty())return
        s.world.economies.values.forEachIndexed {i,e->
            listOf("CPI" to 2,"JOBS" to 4,"GDP" to 12,"RATE" to 7).forEach {(type,days)->schedule(s,type,e.region,s.marketTime+days*DAY+i*3_600_000L)}
        }
        schedule(s,"OIL_INVENTORY","USA",s.marketTime+DAY)
        s.world.companies.values.forEach {c->s.world.calendar.add(Release(s.id(),"EARNINGS","USA",c.nextEarnings,c.eps/4,c.forecastEps,.05,c.symbol))}
    }
    private fun schedule(s:GameState,type:String,region:String,time:Long) {
        val e=s.world.economies.getValue(region)
        val prior=when(type){"CPI"->e.inflation;"JOBS"->e.jobs;"GDP"->e.growth;"RATE"->e.rate;else->s.world.commodities.inventories}
        val forecast=if(type=="RATE")e.expectedRate else prior
        val uncertainty=when(type){"CPI"->.18;"JOBS"->45.0;"GDP"->.25;"RATE"->.25;"EARNINGS"->.05;else->.03}
        s.world.calendar.add(Release(s.id(),type,region,time,prior,forecast,uncertainty))
    }
    fun nextBoundary(s:GameState):Long = minOf(
        s.world.calendar.filter {it.actual==null}.minOfOrNull {it.time} ?: Long.MAX_VALUE,
        s.world.stories.minOfOrNull {it.nextAt} ?: Long.MAX_VALUE,s.world.nextUnexpected.takeIf {it>0} ?: Long.MAX_VALUE,
        s.world.tokens.values.filter {it.unlocks<8}.minOfOrNull {it.nextUnlock} ?: Long.MAX_VALUE)
    fun step(s:GameState) {
        val w=s.world;val rng=RandomSource(s,"macro")
        w.calendar.filter {it.actual==null && it.time<=s.marketTime}.toList().forEach {r->release(s,r,rng)}
        w.stories.filter {it.nextAt<=s.marketTime}.toList().forEach {story->follow(s,story,rng)}
        if(s.marketTime>=w.nextUnexpected) {
            unexpected(s,rng)
            w.nextUnexpected=s.marketTime+(-ln((1-rng.next()).coerceAtLeast(1e-9))*3*DAY).toLong().coerceIn(3_600_000L,14*DAY)
        }
        w.tokens.values.filter {it.unlocks<8 && it.nextUnlock<=s.marketTime}.forEach {t->
            val unlocked=t.supply*.04;t.circulating+=unlocked;t.unlocks++;t.nextUnlock+=30*DAY
            w.networks[t.symbol]?.unlockPressure=(w.networks[t.symbol]?.unlockPressure ?: 0.0)+unlocked/t.circulating
            publish(s,WorldEvent(s.id(),"TOKEN_UNLOCK","GLOBAL",s.marketTime,unlocked/t.circulating,symbol=t.symbol))
        }
        w.calendar.removeAll {it.actual!=null && it.time<s.marketTime-100*DAY}
        while(w.events.size>300)w.events.removeAt(0)
    }
    private fun release(s:GameState,r:Release,rng:RandomSource) {
        val w=s.world;val e=w.economies.getValue(r.region)
        val actual=when(r.type){
            "CPI"->(e.inflation+rng.normal()*.16).coerceIn(-.5,10.0)
            "JOBS"->e.jobs+rng.normal()*40
            "GDP"->(e.growth+rng.normal()*.2).coerceIn(-7.0,8.0)
            "RATE"->{val gap=EconomicEngine.policyTarget(e)-e.rate+rng.normal()*.12; (e.rate+when {gap>.8->.5;gap>.18->.25;gap<-.8->-.5;gap<-.18->-.25;else->0.0}).coerceIn(0.0,10.0)}
            "EARNINGS"->{val c=w.companies.getValue(r.symbol)
                c.revenueGrowth=(.04+.018*e.growth+.08*(w.sectors[c.sector] ?: 1.0)-.08+.04*(c.marketShare-.2)+rng.normal()*.04).coerceIn(-.3,.35)
                c.revenue*=1+c.revenueGrowth/4
                c.margin=(c.margin+.015*(e.growth-2)-.01*(e.rate-4)+rng.normal()*.012).coerceIn(.025,.55)
                val eps=((c.revenue*c.margin-c.debt*e.rate/100)/max(c.shares,1.0)).coerceAtLeast(.04)
                c.eps=eps;c.actualEps=eps/4;c.actualRevenue=c.revenue/4
                c.guidance=(1+.4*c.revenueGrowth+.035*(e.growth-2)+rng.normal()*.055).coerceIn(.6,1.45)
                c.sentiment=(c.actualEps!!-r.forecast)/max(abs(r.forecast),.01)+.5*(c.guidance-1)
                c.forecastEps=c.eps/4*(1+c.revenueGrowth/4);c.forecastRevenue=c.revenue/4*(1+c.revenueGrowth/4)
                c.nextEarnings=r.time+90*DAY;c.actualEps!!}
            else->(w.commodities.inventories+rng.normal()*.025).coerceIn(.6,1.5)
        }
        val surprise=(actual-r.forecast)/max(r.uncertainty,1e-9)
        r.actual=actual;r.surprise=surprise
        when(r.type){
            "CPI"->{e.inflation=actual;e.coreInflation+=.1*(actual-r.forecast);e.expectedRate+=(actual-r.forecast)*.6;e.yield2+=(actual-r.forecast)*.35;e.yield10+=(actual-r.forecast)*.2;e.liquidity=(e.liquidity-(actual-r.forecast)*.06).coerceIn(.45,1.7)}
            "JOBS"->{e.jobs=actual;e.unemployment=(e.unemployment-(actual-r.forecast)*.0008).coerceIn(2.3,13.0);e.spending+=(actual-r.forecast)*.0015}
            "GDP"->{e.growth=actual;e.confidence+=(actual-r.forecast)*2}
            "RATE"->{val delta=actual-r.forecast;e.rate=actual;e.expectedRate=actual;e.yield2+=delta*.7;e.yield10+=delta*.3;e.liquidity=(e.liquidity-.09*delta).coerceIn(.45,1.7)}
            "OIL_INVENTORY"->w.commodities.inventories=actual
        }
        w.newsStress=(w.newsStress+min(2.0,abs(surprise))*(if(r.type=="EARNINGS").003 else .035)).coerceAtMost(1.2)
        EconomicEngine.syncLegacy(s)
        publish(s,WorldEvent(r.id,r.type,r.region,r.time,min(3.0,abs(surprise))/3,surprise,r.symbol))
        if(r.type=="EARNINGS") {
            val c=w.companies.getValue(r.symbol);w.calendar.add(Release(s.id(),r.type,r.region,c.nextEarnings,actual,c.forecastEps,max(c.forecastEps*.08,.01),r.symbol))
        }else schedule(s,r.type,r.region,r.time+when(r.type){"RATE"->42*DAY;"OIL_INVENTORY"->7*DAY;else->30*DAY})
    }
    private fun unexpected(s:GameState,rng:RandomSource) {
        val w=s.world;val type=listOf("GEOPOLITICS","SECURITY","REGULATION","ADOPTION","TRADE","CREDIT","WEATHER","AI")[rng.index(8)]
        val magnitude=.2+rng.next()*.6
        val crypto=w.networks.keys.toList();val symbol=if(type in listOf("SECURITY","ADOPTION") && crypto.isNotEmpty())crypto[rng.index(crypto.size)] else ""
        var storyId=0L
        when(type){
            "GEOPOLITICS"->{storyId=s.id();w.stories.add(Story(storyId,type,"Middle East",0,magnitude*100,s.marketTime+DAY));w.commodities.disruption+=magnitude*.12}
            "SECURITY"->{w.networks[symbol]?.let {it.security=(it.security-magnitude*.35).coerceAtLeast(.35);it.activity*=1-magnitude*.12};storyId=s.id();w.stories.add(Story(storyId,type,"GLOBAL",0,magnitude*100,s.marketTime+2*DAY,symbol))}
            "REGULATION"->w.regulation=(w.regulation+magnitude*.3).coerceAtMost(1.0)
            "ADOPTION"->w.networks[symbol]?.let {it.activity+=magnitude*.25;it.developers+=magnitude*.08}
            "TRADE"->{storyId=s.id();w.stories.add(Story(storyId,type,"USA / China",0,magnitude*100,s.marketTime+3*DAY));w.globalTrade-=magnitude*.04}
            "CREDIT"->{w.economies.values.forEach {it.credit=(it.credit-magnitude*.15).coerceAtLeast(.4)};storyId=s.id();w.stories.add(Story(storyId,type,"USA",0,magnitude*100,s.marketTime+2*DAY))}
            "WEATHER"->{w.commodities.gasStorage=(w.commodities.gasStorage-magnitude*.08).coerceAtLeast(.5);w.commodities.gasProduction-=magnitude*.04}
            "AI"->{w.sectors.keys.filter {it in listOf("tech","chips","technology","semiconductors")}.forEach {w.sectors[it]=(w.sectors[it] ?: 1.0)+magnitude*.15}}
        }
        w.newsStress=(w.newsStress+magnitude*.1).coerceAtMost(1.2)
        publish(s,WorldEvent(s.id(),type,if(type=="GEOPOLITICS")"Middle East" else "GLOBAL",s.marketTime,magnitude,symbol=symbol,storyId=storyId))
    }
    private fun follow(s:GameState,story:Story,rng:RandomSource) {
        val w=s.world;val resolved=rng.next()<(.35+.12*story.stage)
        story.stage++
        if(resolved) {
            story.tension*=.35
            if(story.type=="GEOPOLITICS")w.commodities.disruption*=.65
            if(story.type=="TRADE")w.globalTrade+=.04
            if(story.type=="SECURITY")w.networks[story.symbol]?.security=(w.networks[story.symbol]?.security ?: .5)+.1
            if(story.type=="CREDIT")w.economies.values.forEach {it.credit=(it.credit+.04).coerceAtMost(1.4)}
        } else {
            story.tension=(story.tension+15+rng.next()*10).coerceAtMost(100.0)
            if(story.type=="GEOPOLITICS") {w.commodities.disruption=(w.commodities.disruption+.08).coerceAtMost(.6);w.commodities.shipping=(w.commodities.shipping-.035).coerceAtLeast(.6)}
            if(story.type=="TRADE"){w.globalTrade=(w.globalTrade-.035).coerceAtLeast(.6);w.supplyChains-=.025}
            if(story.type=="SECURITY")w.networks[story.symbol]?.activity=(w.networks[story.symbol]?.activity ?: 1.0)*.96
            if(story.type=="CREDIT")w.economies.values.forEach {it.credit=(it.credit-.02).coerceAtLeast(.4)}
        }
        publish(s,WorldEvent(s.id(),story.type+if(resolved)"_RESOLVED" else "_ESCALATION",story.region,s.marketTime,story.tension/100,symbol=story.symbol,storyId=story.id))
        if(resolved || story.stage>=5)w.stories.remove(story) else story.nextAt=s.marketTime+(1+rng.index(6))*DAY
    }
    fun publish(s:GameState,event:WorldEvent) {
        s.world.events.add(event)
        val pair=when(event.type.substringBefore("_ESCALATION").substringBefore("_RESOLVED")){
            "CPI"->"صدور بيانات التضخم" to "Inflation release"
            "JOBS"->"صدور تقرير الوظائف" to "Employment report"
            "GDP"->"تقرير النمو الاقتصادي" to "GDP report"
            "RATE"->"قرار البنك المركزي" to "Central bank decision"
            "EARNINGS"->"نتائج الشركة وتوجيهاتها" to "Company earnings and guidance"
            "OIL_INVENTORY"->"تقرير مخزونات النفط" to "Oil inventory report"
            "GEOPOLITICS"->"تطورات التوترات وإمدادات الطاقة" to "Regional tensions and energy supply"
            "SECURITY"->"تحقيق أمني في الشبكة" to "Network security investigation"
            "TRADE"->"مفاوضات التجارة وسلاسل الإمداد" to "Trade talks and supply chains"
            "CREDIT"->"تطورات شروط الائتمان" to "Credit conditions update"
            "REGULATION"->"مراجعة تنظيم الأصول الرقمية" to "Digital asset regulation review"
            "ADOPTION"->"توسع استخدام الشبكة" to "Network adoption expands"
            "WEATHER"->"الطقس يضغط على مخزون الغاز" to "Weather pressures gas storage"
            "AI"->"استثمارات جديدة في الذكاء الاصطناعي" to "New AI infrastructure investment"
            "TOKEN_UNLOCK"->"بدء تحرير معروض العملة" to "Token supply unlock"
            else->event.type to event.type
        }
        val release=s.world.calendar.firstOrNull {it.id==event.id}
        fun f(x:Double)=String.format(Locale.US,"%.2f",x)
        val stageAr=if(event.type.endsWith("RESOLVED"))" • اتفاق وتراجع المخاوف" else if(event.type.endsWith("ESCALATION"))" • تصعيد جديد" else ""
        val stageEn=if(event.type.endsWith("RESOLVED"))" • agreement and easing concerns" else if(event.type.endsWith("ESCALATION"))" • renewed escalation" else ""
        val ar=if(release!=null)"الفعلي ${f(release.actual!!)} • المتوقع ${f(release.forecast)} • السابق ${f(release.previous)} • المفاجأة ${f(event.surprise)}σ. تتداخل السيولة والعوائد والتوجيهات؛ اتجاه السعر غير مضمون."
            else "تغيرت عوامل العالم المرتبطة بهذا الحدث. تستمر المتابعة وقد تؤكد التطورات التالية الأثر أو تعكسه."
        val en=if(release!=null)"Actual ${f(release.actual!!)} • forecast ${f(release.forecast)} • previous ${f(release.previous)} • surprise ${f(event.surprise)}σ. Liquidity, yields and guidance interact; price direction is uncertain."
            else "The event changed underlying world factors. Follow-up developments may reinforce or reverse the effect."
        val target=event.symbol.ifBlank {event.region}
        s.news.add(0,News(event.id,event.type,target,event.magnitude,event.time,pair.first+stageAr+" • $target",pair.second+stageEn+" • $target",ar,en,"مكتب اقتصاد العالم","World Economy Desk",event.storyId))
        while(s.news.size>160)s.news.removeAt(s.news.lastIndex)
        if(event.magnitude>.65)GameAlerts.enqueue(s,GameAlert(event.id,AlertType.NEWS,event.type,target,event.time))
    }
}
