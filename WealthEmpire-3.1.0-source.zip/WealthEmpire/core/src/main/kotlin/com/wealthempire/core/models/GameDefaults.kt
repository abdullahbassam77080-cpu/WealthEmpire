package com.wealthempire.core.models

/** Starting equity is funded once, on a new game or the authorized economy restart. */
object GameDefaults {
    val STARTING_CAPITAL=d(20_000)
}
