package com.wealthempire.core.market
import java.time.*
data class SessionTransition(val time:Long,val opens:Boolean)
object MarketSessions {
    private fun weekday(date:LocalDate)=date.dayOfWeek !in listOf(DayOfWeek.SATURDAY,DayOfWeek.SUNDAY)
    fun isOpen(time:Long):Boolean {
        val t=Instant.ofEpochMilli(time).atZone(ZoneOffset.UTC)
        return weekday(t.toLocalDate()) && t.toLocalTime()>=LocalTime.of(9,30) && t.toLocalTime()<LocalTime.of(16,0)
    }
    fun nextTransition(time:Long):SessionTransition {
        val t=Instant.ofEpochMilli(time).atZone(ZoneOffset.UTC)
        if(isOpen(time))return SessionTransition(t.toLocalDate().atTime(16,0).toInstant(ZoneOffset.UTC).toEpochMilli(),false)
        for(i in 0L..7L) {
            val date=t.toLocalDate().plusDays(i);if(!weekday(date))continue
            val at=date.atTime(9,30).toInstant(ZoneOffset.UTC).toEpochMilli()
            if(at>time)return SessionTransition(at,true)
        }
        error("session_calendar_error")
    }
}
