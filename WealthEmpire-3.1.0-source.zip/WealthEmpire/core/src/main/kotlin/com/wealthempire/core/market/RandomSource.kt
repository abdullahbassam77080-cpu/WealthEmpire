package com.wealthempire.core.market

import com.wealthempire.core.models.GameState
import kotlin.math.*

/** SplitMix64: state is saved with the same atomic transaction as the outcome. */
class RandomSource(private val state: GameState, private val stream:String="legacy") {
    fun next(): Double {
        val value=when(stream){"macro"->state.world.macroRng;"price"->state.world.priceRng;else->state.rngState} + -7046029254386353131L
        when(stream){"macro"->state.world.macroRng=value;"price"->state.world.priceRng=value;else->state.rngState=value}
        var z = value
        z = (z xor (z ushr 30)) * -4658895280553007687L
        z = (z xor (z ushr 27)) * -7723592293110705685L
        z = z xor (z ushr 31)
        return (z ushr 11).toDouble() / 9007199254740992.0
    }
    fun normal(): Double = sqrt(-2.0 * ln(next().coerceAtLeast(1e-12))) * cos(2.0 * PI * next())
    fun index(size: Int): Int = (next() * size).toInt().coerceAtMost(size - 1)
}
