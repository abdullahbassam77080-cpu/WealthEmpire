package com.wealthempire.core.economy

import com.wealthempire.core.models.*
import com.wealthempire.core.world.*
import com.wealthempire.core.market.*
import kotlin.math.*

/** All rates are percentage points; indices are dimensionless relative to launch. */
object EconomicEngine {
    const val DAY=86_400_000L
    fun initialize(s:GameState,market:MarketEngine) {
        val w=s.world;if(w.initialized)return
        w.initialized=true;w.seed=s.rngState;w.macroRng=s.rngState xor 0x51a38L;w.priceRng=s.rngState xor 0x81237L
        w.lastDaily=s.marketTime/DAY
        w.economies["USA"]=EconomicState("USA")
        w.economies["Europe"]=EconomicState("Europe",growth=1.2,unemployment=6.3,rate=3.25,expectedRate=3.25,yield2=3.0,yield10=3.2)
        w.economies["China"]=EconomicState("China",inflation=1.8,coreInflation=1.6,growth=4.5,rate=3.0,expectedRate=3.0,yield2=2.8,yield10=3.1)
        w.economies["Japan"]=EconomicState("Japan",inflation=2.0,coreInflation=1.8,growth=.9,rate=.5,expectedRate=.5,yield2=.7,yield10=1.2)
        val rng=RandomSource(s,"macro")
        for(a in market.assets(s)) {
            if(a.kind==AssetKind.STOCK && !a.isEtf && !a.legacy) {
                val pe=when(a.sector){"tech","chips","technology","semiconductors"->32.0;"banks","financials"->15.0;else->22.0}
                val eps=a.initialPrice.toDouble()/pe;val revenue=max(500.0,a.marketCap.toDouble()/1e6/5)
                val initialMargin=.12+rng.next()*.16
                w.companies[a.symbol]=Company(a.symbol,a.sector,revenue,.025+rng.next()*.12,eps,initialMargin,
                    revenue*(.1+rng.next()*.5),revenue*(.1+rng.next()*.4),valuation=pe,nextEarnings=s.marketTime+(7+rng.index(75))*DAY,
                    forecastEps=eps/4,forecastRevenue=revenue/4,shares=revenue*initialMargin/eps,referencePrice=a.initialPrice.toDouble())
            }
            if(a.kind==AssetKind.CRYPTO && !a.stable)w.networks[a.symbol]=Network(institutional=if(a.symbol=="BTC").95 else if(a.symbol=="ETH").65 else .2)
            w.sectors.putIfAbsent(a.sector,1.0)
        }
        w.nextUnexpected=s.marketTime+30*60_000L
        syncLegacy(s)
    }
    fun policyTarget(e:EconomicState):Double = (2.5+1.05*(e.coreInflation-2)+.22*(e.growth-2)-.38*(e.unemployment-4.2)+.12*(e.wages-3.5)+.2*(e.credit-1)).coerceIn(0.0,10.0)
    fun advance(s:GameState) {
        val w=s.world;val due=s.marketTime/DAY
        while(w.lastDaily<due) {w.lastDaily++;daily(s)}
        syncLegacy(s)
    }
    private fun daily(s:GameState) {
        val w=s.world;val rng=RandomSource(s,"macro");val c=w.commodities
        val tension=w.stories.filter {it.type=="GEOPOLITICS"}.maxOfOrNull {it.tension/100} ?: 0.0
        val oldPhase=w.economies.getValue("USA").phase
        w.economies.values.forEach {e->
            e.phaseAge++
            val duration=when(e.phase){Phase.EXPANSION->600.0;Phase.LATE_EXPANSION->240.0;Phase.SLOWDOWN->180.0;Phase.RECESSION->240.0;Phase.RECOVERY->360.0}*(.85+(w.seed and 255)/850.0)
            if(e.phaseAge>duration) {e.phase=Phase.entries[(e.phase.ordinal+1)%Phase.entries.size];e.phaseAge=0.0}
            val target=when(e.phase){Phase.EXPANSION->2.8;Phase.LATE_EXPANSION->2.1;Phase.SLOWDOWN->.5;Phase.RECESSION->-1.8;Phase.RECOVERY->2.2}+if(e.region=="China")1.5 else if(e.region=="Japan")-.8 else 0.0
            e.growth+=(target-.22*(e.rate-e.inflation-1)-.8*(1-w.supplyChains)-e.growth)*.009+rng.normal()*.025
            e.growth=e.growth.coerceIn(-6.0,7.0)
            val unemploymentTarget=(5.5-.5*e.growth+.35*(1-e.credit)).coerceIn(2.5,12.0)
            e.unemployment+=(unemploymentTarget-e.unemployment)*.006+rng.normal()*.007
            e.jobs=(180-95*(e.unemployment-4.2)+30*(e.growth-2)).coerceIn(-600.0,450.0)
            e.wages+=(2+.45*e.inflation+.25*(4.5-e.unemployment)-e.wages)*.009
            e.spending+=(e.growth+.25*(e.wages-e.inflation)-.35*(e.unemployment-4.2)-e.spending)*.014
            val energyPressure=1.4*c.disruption+.8*tension+.5*(1-c.shipping)
            e.inflation+=(2+.32*e.growth+.15*(e.wages-3.5)+energyPressure-.28*(e.rate-e.inflation-1)-e.inflation)*.005+rng.normal()*.012
            e.inflation=e.inflation.coerceIn(-.5,9.0)
            e.coreInflation+=(e.inflation-.25*energyPressure-e.coreInflation)*.018
            e.manufacturing=50+2.2*e.growth-3*(1-w.supplyChains);e.services=50+2*e.spending
            e.confidence=(100+6*e.growth-4*(e.unemployment-4)-5*(e.inflation-2)).coerceIn(40.0,150.0)
            e.credit+=(1-.065*(e.rate-e.inflation)-.12*w.newsStress-e.credit)*.013
            e.credit=e.credit.coerceIn(.4,1.4)
            e.liquidity+=(1-.055*(e.rate-3.0)+.12*(e.credit-1)-e.liquidity)*.015
            e.liquidity=e.liquidity.coerceIn(.45,1.7)
            val gap=policyTarget(e)-e.rate
            e.hikeProbability=1/(1+exp(-14*(gap-.18)));e.cutProbability=1/(1+exp(-14*(-gap-.18)))
            e.expectedRate=e.rate+.25*(e.hikeProbability-e.cutProbability)+.25*(1/(1+exp(-14*(gap-.8)))-1/(1+exp(-14*(-gap-.8))))
            e.yield2+=(e.expectedRate+.12*e.growth-e.yield2)*.035
            e.yield10+=(.55*e.expectedRate+.45*(e.inflation+1.5)+.08*e.growth-e.yield10)*.028
            e.currencyStrength=exp(.09*(e.yield2-4.3)+.025*(e.growth-2.1)-.03*(e.inflation-2.8))
        }
        w.globalGrowth=w.economies.values.map {it.growth}.average()
        w.globalLiquidity=w.economies.values.map {it.liquidity}.average()
        w.riskAppetite=(.5+.07*w.globalGrowth+.7*(w.globalLiquidity-1)-.3*tension-.35*w.newsStress).coerceIn(.03,.97)
        w.fear=(18+28*(.5-w.riskAppetite)+25*w.newsStress+20*tension).coerceIn(9.0,75.0)
        w.newsStress*=.95;w.regulation*=.992
        w.globalTrade+=(1+.03*w.globalGrowth-.18*tension-w.globalTrade)*.01
        w.supplyChains+=(w.globalTrade-.25*c.disruption-w.supplyChains)*.018
        w.supplyChains=w.supplyChains.coerceIn(.5,1.3)
        c.disruption*=.988;c.shipping+=(1-.2*tension-c.shipping)*.02
        c.production+=(1+.03*(c.oilDemand-c.oilSupply)-c.production)*.01
        c.oilSupply+=(c.production*(1-.2*c.disruption)-c.oilSupply)*.04
        c.oilDemand+=(1+.055*(w.globalGrowth-2)+.02*w.globalTrade-c.oilDemand)*.03
        c.inventories=(c.inventories+(c.oilSupply-c.oilDemand)*.015).coerceIn(.65,1.4)
        val season=cos((w.lastDaily%365)/365.0*2*PI)
        c.winterDemand=1+.2*season;c.gasStorage=(c.gasStorage+(c.gasProduction-c.winterDemand)*.004).coerceIn(.5,1.5)
        c.gasProduction+=(1-c.gasProduction)*.009;c.lng+=(1+.05*w.globalGrowth-.1*tension-c.lng)*.01
        c.goldDemand+=(1+.01*(w.fear-18)+.2*tension-c.goldDemand)*.02
        w.stablecoinLiquidity+=(w.globalLiquidity+.15*(w.riskAppetite-.5)-.08*w.regulation-w.stablecoinLiquidity)*.022
        w.etfFlows=w.etfFlows*.95+rng.normal()*.015+.018*(w.riskAppetite-.5)
        w.institutionalDemand+=(1+.5*w.etfFlows+.15*(w.globalLiquidity-1)-w.institutionalDemand)*.03
        w.btcDominance+=(.54+.15*(.5-w.riskAppetite)-w.btcDominance)*.025
        w.networks.forEach {(symbol,n)->
            n.activity+=(1+.4*(w.riskAppetite-.5)-.2*w.regulation-n.activity)*.012+rng.normal()*.003
            n.developers+=(n.activity-n.developers)*.008;n.security+=(1-n.security)*.018
            n.reserves+=(1-.18*w.etfFlows+.15*n.unlockPressure-n.reserves)*.03
            n.staking+=(.3+.08*w.globalLiquidity-.12*(1-n.security)-n.staking)*.012
            n.unlockPressure*=.94
            if(symbol=="BTC")n.energyCost=1+.4*(c.oilDemand-c.oilSupply)+.4*c.disruption
        }
        w.sectors.keys.toList().forEach {sector->
            val value=when(sector){"energy"->1+.2*(c.oilDemand-c.oilSupply)+.2*c.disruption;"banks","financials"->1+.06*(w.economies.getValue("USA").rate-3)+.15*(w.globalGrowth-2);"tech","chips","technology","semiconductors"->1+.09*(w.globalGrowth-2)+.2*(w.globalLiquidity-1);"airlines","transport"->1-.3*c.disruption+.08*(w.globalGrowth-2);else->1+.055*(w.globalGrowth-2)}
            w.sectors[sector]=((w.sectors[sector] ?: 1.0)*.975+value*.025).coerceIn(.5,1.7)
        }
        // Consensus evolves with available data and freezes one day before publication.
        w.calendar.filter {it.actual==null && it.time>s.marketTime+DAY}.forEach {r->
            val e=w.economies[r.region] ?: return@forEach
            r.forecast=when(r.type){"CPI"->e.inflation;"JOBS"->e.jobs;"GDP"->e.growth;"RATE"->e.expectedRate;"OIL_INVENTORY"->c.inventories;else->r.forecast}
        }
        val newPhase=w.economies.getValue("USA").phase
        if(newPhase!=oldPhase) {s.progression.cycleCount++;if(newPhase==Phase.RECESSION)s.progression.experiencedRecession=true}
        syncLegacy(s)
    }
    fun syncLegacy(s:GameState) {
        val us=s.world.economies["USA"] ?: return
        s.economy.policyRate=us.rate;s.economy.inflation=us.inflation;s.economy.growth=us.growth
        s.economy.riskAppetite=2*s.world.riskAppetite-1;s.economy.cryptoTrust=1-s.world.regulation
        s.economy.dollarPressure=(us.yield2-4.3)/5;s.economy.energySupply=s.world.commodities.oilSupply-1
    }
}
