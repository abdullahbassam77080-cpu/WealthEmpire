package com.wealthempire.core.models
import kotlinx.serialization.Serializable
@Serializable enum class AlertType {MARKET_OPEN,MARKET_CLOSED,NEWS}
@Serializable data class GameAlert(val id:Long,val type:AlertType,val key:String,val target:String,val time:Long)
object GameAlerts {
    const val MAX_PENDING=1
    fun enqueue(s:GameState,a:GameAlert) {
        if(!s.alertsEnabled)return
        if(s.alerts.none {it.id==a.id})s.alerts.add(a)
        while(s.alerts.size>MAX_PENDING)s.alerts.removeAt(0)
    }
    fun dismiss(s:GameState,id:Long){s.alerts.removeAll {it.id==id}}
}
