package com.wealthempire.core.trading
import com.wealthempire.core.models.*
import java.math.BigDecimal
object FuturesMath {
    val MAKER=d("0.0002");val TAKER=d("0.0005")
    fun maintenanceRate(n:BigDecimal)=when {n<=d(50000)->d("0.0005");n<=d(250000)->d("0.001");n<=d(1000000)->d("0.0025");else->d("0.005")}
    fun maintenanceAmount(n:BigDecimal):BigDecimal {
        require(n>=ZERO)
        return minOf(n,d(50000))*d("0.0005")+minOf((n-d(50000)).positive(),d(200000))*d("0.001")+
            minOf((n-d(250000)).positive(),d(750000))*d("0.0025")+(n-d(1000000)).positive()*d("0.005")
    }
    fun notional(p:Position,mark:BigDecimal)=p.quantity*mark
    fun pnl(p:Position,mark:BigDecimal)=p.quantity*(if(p.side==Side.LONG)mark-p.entry else p.entry-mark)
    fun roe(p:Position,mark:BigDecimal)=pnl(p,mark).divD(p.originalMargin)*d(100)
    fun maintenance(p:Position,mark:BigDecimal)=maintenanceAmount(notional(p,mark))
    fun riskRequirement(p:Position,mark:BigDecimal)=maintenance(p,mark)+notional(p,mark)*TAKER
    fun crossEquity(s:GameState)=s.positions.filter {it.mode==MarginMode.CROSS}.fold(s.futuresCash){a,p->a+p.margin+pnl(p,s.quote(p.symbol).price)}
    fun crossRequirement(s:GameState)=s.positions.filter {it.mode==MarginMode.CROSS}.fold(ZERO){a,p->a+riskRequirement(p,s.quote(p.symbol).price)}
    fun crossSafetyAt(s:GameState,symbol:String,price:BigDecimal)=s.positions.filter {it.mode==MarginMode.CROSS}.fold(s.futuresCash){a,p->
        val mark=if(p.symbol==symbol)price else s.quote(p.symbol).price
        a+p.margin+pnl(p,mark)-riskRequirement(p,mark)
    }
    fun liquidationRange(s:GameState,p:Position):LiquidationRange {
        val mark=s.quote(p.symbol).price
        if(p.mode==MarginMode.ISOLATED)return LiquidationSolver.bounds(mark,p.side==Side.SHORT){price->p.margin+pnl(p,price)-riskRequirement(p,price)}
        val same=s.positions.filter {it.mode==MarginMode.CROSS && it.symbol==p.symbol}
        val net=same.fold(ZERO){a,x->a+x.quantity*(if(x.side==Side.LONG)ONE else -ONE)}
        val gross=same.fold(ZERO){a,x->a+x.quantity}
        return LiquidationSolver.bounds(mark,net<gross*d("0.0055")){price->crossSafetyAt(s,p.symbol,price)}
    }
    fun liquidation(s:GameState,p:Position):BigDecimal=liquidationRange(s,p).let {it.lower ?: it.upper ?: ZERO}
    fun liquidation(p:Position,collateral:BigDecimal=p.margin):BigDecimal {
        val safety:(BigDecimal)->BigDecimal={price->collateral+pnl(p,price)-riskRequirement(p,price)}
        var anchor=p.entry
        repeat(128){if(safety(anchor)<=ZERO)anchor=if(p.side==Side.LONG)anchor*d(2) else anchor.divD(d(2))}
        if(safety(anchor)<=ZERO)return ZERO
        val range=LiquidationSolver.bounds(anchor,p.side==Side.SHORT,safety)
        return if(p.side==Side.LONG)range.lower ?: ZERO else range.upper ?: ZERO
    }
}
