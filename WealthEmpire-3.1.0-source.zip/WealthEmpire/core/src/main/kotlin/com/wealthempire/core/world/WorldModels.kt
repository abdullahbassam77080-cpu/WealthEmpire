package com.wealthempire.core.world

import kotlinx.serialization.Serializable

@Serializable enum class Phase { EXPANSION, LATE_EXPANSION, SLOWDOWN, RECESSION, RECOVERY }
@Serializable enum class GameMode { PURE_INVESTOR, REAL_LIFE, HARDCORE }
@Serializable data class EconomicState(
    val region:String, var inflation:Double=2.8, var coreInflation:Double=2.6,
    var growth:Double=2.1, var unemployment:Double=4.2, var jobs:Double=180.0,
    var wages:Double=3.6, var spending:Double=2.5, var manufacturing:Double=51.0,
    var services:Double=53.0, var confidence:Double=100.0, var rate:Double=4.5,
    var expectedRate:Double=4.5, var yield2:Double=4.3, var yield10:Double=4.1,
    var credit:Double=1.0, var liquidity:Double=1.0, var currencyStrength:Double=1.0,
    var phase:Phase=Phase.EXPANSION, var phaseAge:Double=0.0, var cutProbability:Double=.25,
    var hikeProbability:Double=.25
)
@Serializable data class Company(
    val symbol:String, val sector:String, var revenue:Double, var revenueGrowth:Double,
    var eps:Double, var margin:Double, var debt:Double, var cash:Double,
    var guidance:Double=1.0, var marketShare:Double=.2, var valuation:Double=25.0,
    var sentiment:Double=0.0, var nextEarnings:Long=0, var forecastEps:Double=0.0,
    var forecastRevenue:Double=0.0, var actualEps:Double?=null, var actualRevenue:Double?=null, val shares:Double=1.0, val referencePrice:Double=1.0
)
@Serializable data class Network(
    var activity:Double=1.0, var developers:Double=1.0, var security:Double=1.0,
    var reserves:Double=1.0, var staking:Double=.3, var unlockPressure:Double=0.0,
    var institutional:Double=.4, var energyCost:Double=1.0
)
@Serializable data class Commodities(
    var oilSupply:Double=1.0,var oilDemand:Double=1.0,var inventories:Double=1.0,
    var production:Double=1.0,var shipping:Double=1.0,var gasStorage:Double=1.0,
    var gasProduction:Double=1.0,var winterDemand:Double=1.0,var lng:Double=1.0,
    var goldDemand:Double=1.0,var disruption:Double=0.0
)
@Serializable data class Microstructure(var depth:Double=1e7,var spread:Double=.0004,
    var volume:Double=0.0,var openInterest:Double=1e8,var longFraction:Double=.5,
    var basis:Double=0.0,var funding:Double=0.0,var volatility:Double=.3,
    var liquidationCluster:Double=0.0)
@Serializable data class Release(val id:Long,val type:String,val region:String,val time:Long,
    val previous:Double,var forecast:Double,val uncertainty:Double,val symbol:String="",
    var actual:Double?=null,var surprise:Double?=null)
@Serializable data class WorldEvent(val id:Long,val type:String,val region:String,val time:Long,
    val magnitude:Double,val surprise:Double=0.0,val symbol:String="",val storyId:Long=0)
@Serializable data class Story(val id:Long,val type:String,val region:String,var stage:Int,
    var tension:Double,var nextAt:Long,val symbol:String="")
@Serializable data class Tokenomics(val symbol:String,val team:Double,val supply:Double,
    var circulating:Double,val hype:Double,val investorInterest:Double,var nextUnlock:Long,
    var unlocks:Int=0)
@Serializable data class AwayReport(val from:Long,val to:Long,val before:String,val after:String,
    val moves:Map<String,Double>,val events:List<Long>,val filled:Int,val stops:Int,val profits:Int,
    val liquidations:Int,val funding:String,val earn:String)
@Serializable data class Progression(var researchDay:Long=-1,var researched:MutableList<String> = mutableListOf(),
    var safeSince:Long=0,var peakLeverage:Int=1,var careerIncome:String="0",
    var incomeMonth:Long=-1,var cycleCount:Int=0,var experiencedRecession:Boolean=false,
    var skills:MutableMap<String,Int> = mutableMapOf(),var skillPoints:Int=0,var rewardedLevel:Int=1,
    var benchmarkStart:Double=0.0,var benchmarkAt:Long=0,var benchmarkWealth:String="20000",
    var completed:MutableList<String> = mutableListOf())
@Serializable data class WorldState(
    var initialized:Boolean=false,var seed:Long=42,var macroRng:Long=42,var priceRng:Long=43,
    var lastDaily:Long=0,var nextUnexpected:Long=0,
    val economies:MutableMap<String,EconomicState> = mutableMapOf(),
    val companies:MutableMap<String,Company> = mutableMapOf(),
    val networks:MutableMap<String,Network> = mutableMapOf(),
    val micro:MutableMap<String,Microstructure> = mutableMapOf(),
    val sectors:MutableMap<String,Double> = mutableMapOf(),
    val calendar:MutableList<Release> = mutableListOf(),val events:MutableList<WorldEvent> = mutableListOf(),
    val stories:MutableList<Story> = mutableListOf(),val tokens:MutableMap<String,Tokenomics> = mutableMapOf(),
    val commodities:Commodities=Commodities(),var globalGrowth:Double=2.2,var globalLiquidity:Double=1.0,
    var globalTrade:Double=1.0,var supplyChains:Double=1.0,var riskAppetite:Double=.5,
    var fear:Double=18.4,var btcDominance:Double=.54,var stablecoinLiquidity:Double=1.0,
    var etfFlows:Double=0.0,var institutionalDemand:Double=1.0,var regulation:Double=0.0,
    var newsStress:Double=0.0
)
fun WorldState.deepCopy()=copy(economies=economies.mapValues {it.value.copy()}.toMutableMap(),
    companies=companies.mapValues {it.value.copy()}.toMutableMap(),networks=networks.mapValues {it.value.copy()}.toMutableMap(),
    micro=micro.mapValues {it.value.copy()}.toMutableMap(),sectors=sectors.toMutableMap(),calendar=calendar.map {it.copy()}.toMutableList(),
    events=events.toMutableList(),stories=stories.map {it.copy()}.toMutableList(),tokens=tokens.mapValues {it.value.copy()}.toMutableMap(),commodities=commodities.copy())
