package com.wealthempire.core.market

import com.wealthempire.core.models.*
import java.time.*
import java.math.BigDecimal
import kotlin.math.*

class MarketEngine(inputCatalog:List<AssetSpec> = AssetCatalog.defaults) {
    val catalog=inputCatalog+listOf("US2Y","US10Y").filter {sym->inputCatalog.none {it.symbol==sym}}.map {sym->AssetSpec(sym,if(sym=="US2Y")"US Treasury 2Y" else "US Treasury 10Y",AssetKind.BOND,d(100),.0001,d("1000000000000"),1,"bonds","bond",if(sym=="US2Y")"سندات الخزانة سنتان" else "سندات الخزانة عشر سنوات")}
    private val bySymbol=catalog.associateBy {it.symbol}
    val news=NewsEngine(this)
    val listings=ListingsEngine(this)
    init {
        require(catalog.isNotEmpty() && bySymbol.size==catalog.size)
        require(catalog.all {it.initialPrice>ZERO && it.marketCap>ZERO && it.volatility>0 && it.risk in 1..5})
    }
    fun spec(symbol:String,s:GameState?=null):AssetSpec=bySymbol[symbol]
        ?: s?.listings?.firstOrNull {it.spec.symbol==symbol}?.spec
        ?: throw IllegalArgumentException("invalid_market")
    fun assets(s:GameState)=catalog+s.listings.filter {it.status==ListingStatus.LIVE}.map {it.spec}
    fun visibleAssets(s:GameState)=assets(s).filter {a -> !a.legacy || s.holdings.any {it.symbol==a.symbol} ||
        s.positions.any {it.symbol==a.symbol} || s.orders.any {it.symbol==a.symbol}}
    fun stockOpen(time:Long)=MarketSessions.isOpen(time)
    fun isOpen(a:AssetSpec,time:Long):Boolean=when(a.kind) {
        AssetKind.CRYPTO->true
        AssetKind.STOCK->stockOpen(time)
        else->Instant.ofEpochMilli(time).atZone(ZoneOffset.UTC).dayOfWeek.value<=5
    }
    fun seed(s:GameState) {
        val initial=s.quotes.isEmpty()
        for(a in assets(s))if(s.quotes.none {it.symbol==a.symbol})seedAsset(s,a,true)
        if(initial)addNews(s,"welcome","ALL",0.0)
        news.initialize(s);listings.initialize(s)
        com.wealthempire.core.economy.EconomicEngine.initialize(s,this)
        com.wealthempire.core.events.EventEngine.initialize(s)
    }
    internal fun seedAsset(s:GameState,a:AssetSpec,history:Boolean) {
        val rng=RandomSource(s)
        val q=Quote(a.symbol,a.initialPrice,a.initialPrice,dayBucket=s.marketTime/NewsEngine.DAY)
        for(frame in AssetCatalog.frames) {
            val bars=mutableListOf<Candle>();var price=a.initialPrice
            if(history) {
                for(i in 240 downTo 1) {
                    val time=(s.marketTime/(frame*60_000L)-i)*(frame*60_000L)
                    val move=if(a.stable)0.0 else (rng.normal()*a.volatility*sqrt(frame.toDouble())*.25).coerceIn(-.2,.2)
                    val close=(price*d(exp(move))).money().max(d("0.00000001"))
                    val wick=if(a.stable)ZERO else d(abs(rng.normal())*a.volatility*sqrt(frame.toDouble())/2)
                    bars.add(Candle(time,price,maxOf(price,close)*(ONE+wick),minOf(price,close)*(ONE-wick).max(d("0.1")),close,d(100+rng.next()*10000)))
                    price=close
                }
                val scale=a.initialPrice.divD(price)
                q.bars[frame]=bars.map {Candle(it.time,(it.open*scale).money(),(it.high*scale).money(),(it.low*scale).money(),(it.close*scale).money(),it.volume)}.toMutableList()
            } else q.bars[frame]=mutableListOf(Candle(s.marketTime/(frame*60_000L)*(frame*60_000L),price,price,price,price,ZERO))
        }
        s.quotes.add(q)
    }
    /** Bounded adaptive path. Risk/orders execute at every sampled mark. */
    fun step(s:GameState,onMark:(()->Unit)?=null)=stepDuration(s,60_000L,onMark)
    fun stepDuration(s:GameState,duration:Long,onMark:(()->Unit)?=null) {
        require(duration>0)
        com.wealthempire.core.economy.EconomicEngine.initialize(s,this)
        com.wealthempire.core.events.EventEngine.initialize(s)
        val beforeTime=s.marketTime;val wasOpen=stockOpen(beforeTime);s.ticks++
        val rng=RandomSource(s,"price")
        val specs=assets(s).associateBy {it.symbol}.toMutableMap()
        repeat(4) {micro->
            s.marketTime=beforeTime+duration*(micro+1)/4
            com.wealthempire.core.economy.EconomicEngine.advance(s)
            com.wealthempire.core.events.EventEngine.step(s)
            listings.step(s,RandomSource(s,"macro"));assets(s).forEach {specs[it.symbol]=it}
            val common=List(4){rng.normal()}
            // Reset all day bases before reference ETFs or closed assets are handled.
            s.quotes.forEach {q->val day=s.marketTime/NewsEngine.DAY;if(day!=q.dayBucket){q.dayOpen=q.price;q.dayBucket=day}}
            for(q in s.quotes) {
                val a=specs[q.symbol] ?: continue
                if(!isOpen(a,s.marketTime) || a.referenceSymbol!=null)continue
                val before=q.price
                if(a.stable){q.price=a.initialPrice;updateBars(q,s.marketTime,before,q.price,ZERO);continue}
                val factor=common[when(a.kind){AssetKind.CRYPTO->0;AssetKind.STOCK->1;AssetKind.FOREX,AssetKind.BOND->2;AssetKind.COMMODITY->3}]
                val move=PriceEngine.move(s,a,q,maxOf(1,duration/4),factor,rng)
                q.price=(q.price*d(exp(move))).money().max(d("0.00000001"))
                updateBars(q,s.marketTime,before,q.price,d(s.world.micro[q.symbol]?.volume ?: 1.0).divD(q.price).money())
            }
            for(q in s.quotes) {
                val a=specs[q.symbol] ?: continue;val reference=a.referenceSymbol ?: continue
                if(!isOpen(a,s.marketTime))continue
                val underlying=s.quotes.firstOrNull {it.symbol==reference} ?: continue
                val daily=underlying.price.divD(underlying.dayOpen)-ONE
                val expense=d("0.01")*d(s.marketTime%NewsEngine.DAY).divD(d(365L*NewsEngine.DAY))
                val before=q.price;q.price=(q.dayOpen*(ONE+d(a.dailyLeverage)*daily).max(d("0.001"))*(ONE-expense)).money().max(d("0.00000001"))
                updateBars(q,s.marketTime,before,q.price,d(100+rng.next()*1000))
            }
            s.regime=if(s.world.riskAppetite>.6)Regime.BULL else if(s.world.riskAppetite<.4)Regime.BEAR else Regime.SIDEWAYS
            onMark?.invoke()
        }
        val opened=stockOpen(s.marketTime)
        if(wasOpen!=opened)GameAlerts.enqueue(s,GameAlert(s.id(),if(opened)AlertType.MARKET_OPEN else AlertType.MARKET_CLOSED,
            if(opened)"market_opened_notice" else "market_closed_notice","STOCKS",s.marketTime))
    }
    private fun updateBars(q:Quote,time:Long,previous:BigDecimal,price:BigDecimal,volume:BigDecimal) {
        for(frame in AssetCatalog.frames) {
            val bucket=time/(frame*60_000L)*(frame*60_000L);val bars=q.bars.getOrPut(frame){mutableListOf()}
            val last=bars.lastOrNull()
            if(last==null || last.time!=bucket) {
                bars.add(Candle(bucket,previous,maxOf(previous,price),minOf(previous,price),price,volume))
                while(bars.size>260)bars.removeAt(0)
            } else {bars[bars.lastIndex]=last.copy(high=maxOf(last.high,price),low=minOf(last.low,price),close=price,volume=last.volume+volume)}
        }
    }
    /** Compatibility for old saved headline keys and deterministic unit tests. */
    fun addNews(s:GameState,key:String,target:String,impact:Double) {
        val item=News(s.id(),key,target,impact,s.marketTime);s.news.add(0,item)
        if(abs(impact)>=.004)GameAlerts.enqueue(s,GameAlert(item.id,AlertType.NEWS,key,target,s.marketTime))
        while(s.news.size>160)s.news.removeAt(s.news.lastIndex)
        s.quotes.filter {target=="ALL" || target==it.symbol || target=="CRYPTO" && spec(it.symbol,s).kind==AssetKind.CRYPTO ||
            target=="STOCKS" && spec(it.symbol,s).kind==AssetKind.STOCK}.forEach {it.eventBias+=impact}
    }
}
