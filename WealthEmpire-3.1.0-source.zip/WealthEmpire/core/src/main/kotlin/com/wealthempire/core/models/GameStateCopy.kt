package com.wealthempire.core.models
import com.wealthempire.core.world.deepCopy

/** Typed copy avoids encoding/decoding every candle on each UI tick. */
object GameStateCopy {
    fun copy(s:GameState,copyMarket:Boolean=true):GameState=s.copy(
        alerts=s.alerts.toMutableList(), world=s.world.deepCopy(), favorites=s.favorites.toMutableList(),
        progression=s.progression.copy(researched=s.progression.researched.toMutableList(),skills=s.progression.skills.toMutableMap(),completed=s.progression.completed.toMutableList()),
        quotes=if(copyMarket)s.quotes.map {q->q.copy(bars=q.bars.mapValues {(_,bars)->bars.toMutableList()}.toMutableMap())}.toMutableList() else s.quotes.toMutableList(),
        holdings=s.holdings.map {it.copy()}.toMutableList(),positions=s.positions.map {it.copy()}.toMutableList(),
        orders=s.orders.map {it.copy()}.toMutableList(),orderHistory=s.orderHistory.map {it.copy()}.toMutableList(),
        trades=s.trades.toMutableList(),news=s.news.toMutableList(),wealthHistory=s.wealthHistory.toMutableList(),
        financialHistory=s.financialHistory.toMutableList(),achievements=s.achievements.toMutableList(),stats=s.stats.copy(),
        economy=s.economy.copy(lastNewsKeys=s.economy.lastNewsKeys.toMutableList()),effects=s.effects.toMutableList(),
        stories=s.stories.toMutableList(),listings=s.listings.map {it.copy()}.toMutableList(),
        savings=s.savings.map {it.copy()}.toMutableList(),savingsOffers=s.savingsOffers.map {it.copy()}.toMutableList(),
        savingsHistory=s.savingsHistory.toMutableList())
}
