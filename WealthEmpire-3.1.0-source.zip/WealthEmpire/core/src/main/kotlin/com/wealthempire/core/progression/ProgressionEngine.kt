package com.wealthempire.core.progression

import com.wealthempire.core.models.*
import com.wealthempire.core.world.*
import com.wealthempire.core.market.*
import com.wealthempire.core.portfolio.PortfolioAnalytics
import com.wealthempire.core.statistics.Wealth

object ProgressionEngine {
    val tools=linkedMapOf("calendar" to 1,"earnings" to 2,"portfolio_risk" to 2,"sector_heatmap" to 3,"funding" to 3,"open_interest" to 4,"yield_curve" to 4,"consensus" to 5,"research_terminal" to 6)
    val specialties=listOf("trader","investor","macro","crypto_specialist")
    fun unlocked(s:GameState,tool:String):Boolean {
        val specialty=when(tool){"funding","open_interest"->"trader";"earnings","consensus"->"investor";"yield_curve","calendar"->"macro";else->"crypto_specialist"}
        return s.level+(s.progression.skills[specialty] ?: 0)>=(tools[tool] ?: 1)
    }
    fun research(s:GameState,key:String) {
        val p=s.progression;val day=s.marketTime/86_400_000L
        if(p.researchDay!=day){p.researchDay=day;p.researched.clear()}
        require(key !in p.researched && p.researched.size<5){"research_done"}
        p.researched.add(key);s.xp+=20
    }
    fun specialize(s:GameState,key:String) {
        require(key in specialties && s.progression.skillPoints>0 && (s.progression.skills[key] ?: 0)<3){"skill_unavailable"}
        s.progression.skillPoints--;s.progression.skills[key]=(s.progression.skills[key] ?: 0)+1
    }
    fun observe(s:GameState,market:MarketEngine) {
        val p=s.progression
        if(PortfolioAnalytics.health(s,market)<75)p.safeSince=0 else if(p.safeSince==0L)p.safeSince=s.marketTime
        if(s.level>p.rewardedLevel){p.skillPoints+=s.level-p.rewardedLevel;p.rewardedLevel=s.level}
    }
    fun advance(s:GameState,market:MarketEngine) {
        observe(s,market);val p=s.progression;val month=s.marketTime/(30*86_400_000L)
        if(p.incomeMonth<0)p.incomeMonth=month
        if(month>p.incomeMonth){
            val months=month-p.incomeMonth
            val net=when(s.gameMode){GameMode.REAL_LIFE->d(750);GameMode.HARDCORE->d(100);else->ZERO}
            val income=net*d(months);if(income>ZERO)s.credit(Wallet.CASH,income);p.careerIncome=(d(p.careerIncome)+income).toPlainString();p.incomeMonth=month

        }
        val wealth=Wealth.total(s)
        fun grant(key:String,condition:Boolean,xp:Long){if(condition && key !in p.completed){p.completed.add(key);s.xp+=xp}}
        grant("diversify",s.holdings.filter {it.quantity>ZERO}.map {market.spec(it.symbol,s).kind}.distinct().size>=4,150)
        grant("no_extreme_leverage",wealth>=d(100000) && p.peakLeverage<=5,400)
        grant("recession_survivor",p.experiencedRecession && s.world.economies["USA"]?.phase==Phase.RECOVERY && wealth>d(1000),300)
        grant("safe_year",p.safeSince>0 && s.marketTime-p.safeSince>=365*86_400_000L,300)
        if(p.benchmarkAt==0L){p.benchmarkAt=s.marketTime;p.benchmarkStart=s.quote("BTC").price.toDouble();p.benchmarkWealth=wealth.toPlainString()}
        grant("beat_benchmark",s.marketTime-p.benchmarkAt>=365*86_400_000L && wealth>d(p.benchmarkWealth)*s.quote("BTC").price.divD(d(p.benchmarkStart)),350)
        grant("oil_shock",s.world.commodities.disruption>.15 && s.holdings.any {market.spec(it.symbol,s).sector=="energy" && it.quantity*s.quote(it.symbol).price>it.cost} && wealth>s.initialCapital,200)
        grant("crypto_crash",s.world.riskAppetite<.25 && wealth>s.initialCapital*d(".8") && PortfolioAnalytics.health(s,market)>=75,250)
    }
    fun rank(s:GameState,market:MarketEngine):String {
        val wealth=Wealth.total(s);val health=PortfolioAnalytics.health(s,market)
        return when {wealth>=d("100000000") && s.level>=12 && health>=60->"financial_empire";wealth>=d("10000000") && s.level>=9->"capital_titan";wealth>=d("1000000") && s.level>=6->"market_mogul";wealth>=d("250000") && s.level>=4 && health>=60 && s.progression.completed.isNotEmpty()->"fund_manager";wealth>=d("100000") && s.level>=3->"portfolio_manager";wealth>=d("50000")->"investor";wealth>=d("25000")->"trader";else->"rookie"}
    }
}
