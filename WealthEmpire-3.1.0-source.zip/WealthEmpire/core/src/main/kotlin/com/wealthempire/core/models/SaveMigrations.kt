package com.wealthempire.core.models
object SaveMigrations {
    const val CURRENT_SCHEMA=6
    /** Previous economies restart once, as explicitly requested by the player. */
    fun needsEconomyRestart(s:GameState):Boolean {
        require(s.schema in 1..CURRENT_SCHEMA) {"unsupported_save"}
        return s.schema<5
    }
}
