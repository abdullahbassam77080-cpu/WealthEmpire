package com.wealthempire.core.portfolio

import com.wealthempire.core.models.*
import com.wealthempire.core.market.MarketEngine
import com.wealthempire.core.statistics.Wealth
import com.wealthempire.core.trading.FuturesMath
import kotlin.math.*

object PortfolioAnalytics {
    fun unrealized(s:GameState)=s.holdings.fold(ZERO){a,h->a+h.quantity*s.quote(h.symbol).price-h.cost}+
        s.savings.fold(ZERO){a,p->a+p.principal*s.quote(p.symbol).price-p.costBasis}+
        s.positions.fold(ZERO){a,p->a+FuturesMath.pnl(p,s.quote(p.symbol).price)}
    fun realized(s:GameState)=Wealth.total(s)-s.initialCapital-d(s.progression.careerIncome)-unrealized(s)
    fun risk(s:GameState,market:MarketEngine):Int {
        val total=Wealth.total(s).toDouble().coerceAtLeast(1.0)
        val exposure=mutableMapOf<String,Double>()
        s.holdings.forEach {exposure[it.symbol]=(exposure[it.symbol] ?: 0.0)+it.quantity.toDouble()*s.quote(it.symbol).price.toDouble()}
        s.savings.forEach {exposure[it.symbol]=(exposure[it.symbol] ?: 0.0)+(it.principal+it.rewards).toDouble()*s.quote(it.symbol).price.toDouble()}
        s.positions.forEach {p->exposure[p.symbol]=(exposure[p.symbol] ?: 0.0)+p.quantity.toDouble()*s.quote(p.symbol).price.toDouble()*(if(p.side==Side.LONG)1 else -1)}
        val gross=exposure.values.sumOf {abs(it)}
        val concentration=exposure.values.maxOfOrNull {abs(it)/max(gross,1.0)} ?: 0.0
        val volatility=exposure.entries.sumOf {(symbol,value)->abs(value)/total*(s.world.micro[symbol]?.volatility ?: market.spec(symbol,s).risk*.09)}
        val isolated=s.positions.filter {it.mode==MarginMode.ISOLATED}.sumOf {it.margin.toDouble()/total*min(1.0,it.leverage/25.0)}
        val cash=(Wealth.availableCash(s).toDouble()/total).coerceIn(0.0,1.0)
        return (volatility*34+max(0.0,gross/total-1)*15+concentration*(1-cash)*15+isolated*20).roundToInt().coerceIn(0,100)
    }
    fun health(s:GameState,market:MarketEngine)=100-risk(s,market)
    fun allocation(s:GameState,market:MarketEngine):Map<String,Double> {
        val r=linkedMapOf("cash" to Wealth.availableCash(s).toDouble())
        s.holdings.forEach {h->val key=market.spec(h.symbol,s).kind.name;r[key]=(r[key] ?: 0.0)+h.quantity.toDouble()*s.quote(h.symbol).price.toDouble()}
        r["savings"]=Wealth.savingsValue(s).toDouble()
        r["futures"]=s.positions.sumOf {(it.margin+FuturesMath.pnl(it,s.quote(it.symbol).price)).toDouble()}+s.orders.sumOf {it.reserved.toDouble()}
        return r.filterValues {it>0}
    }
    fun sectors(s:GameState,market:MarketEngine):Map<String,Double> = s.holdings.groupBy {market.spec(it.symbol,s).sector}.mapValues {(_,hs)->hs.sumOf {it.quantity.toDouble()*s.quote(it.symbol).price.toDouble()}}
}
