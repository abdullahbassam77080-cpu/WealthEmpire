package com.wealthempire.core.market
import com.wealthempire.core.models.GameState
object GameClock {
    const val SIM_STEP_MS=1000L
    val speeds=listOf(0,1,5,12,16)
    fun requireSpeed(speed:Int) {require(speed in speeds) {"invalid_speed"}}
    fun visualTime(s:GameState,now:Long):Long {
        requireSpeed(s.marketSpeed)
        val at=if(s.marketTickAt==0L)s.lastSeenAt else s.marketTickAt
        val elapsed=(now-at).coerceAtLeast(0).coerceAtMost(60000L)
        val phase=(s.marketCarryMs+elapsed*s.marketSpeed).coerceIn(0L,60000L)
        return s.marketTime+phase
    }
    fun candleRemaining(s:GameState,frameMinutes:Int,now:Long):Long {
        require(frameMinutes>0);val duration=frameMinutes*60000L
        return ((s.marketTime/duration+1)*duration-visualTime(s,now)).coerceAtLeast(0)
    }
    fun realRemaining(ms:Long,speed:Int):Long {
        requireSpeed(speed)
        if(speed==0)return Long.MAX_VALUE
        val positive=ms.coerceAtLeast(0)
        return positive/speed+if(positive%speed==0L)0 else 1
    }
}
