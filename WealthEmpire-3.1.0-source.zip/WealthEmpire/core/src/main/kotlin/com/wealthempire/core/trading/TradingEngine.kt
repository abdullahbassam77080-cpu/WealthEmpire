package com.wealthempire.core.trading

import com.wealthempire.core.models.*
import com.wealthempire.core.market.*
import java.math.BigDecimal

class TradingEngine(private val market: MarketEngine) {
    fun submit(s: GameState, symbol: String, venue: OrderVenue, kind: OrderKind,
        side: Side, amount: BigDecimal, leverage: Int = 1,
        mode: MarginMode = MarginMode.ISOLATED, trigger: BigDecimal? = null,
        takeProfit: BigDecimal? = null, stopLoss: BigDecimal? = null) {
        require(amount >= d("0.00000001") && amount <= d("1000000000000")) { "invalid_amount" }
        val spec = market.spec(symbol,s)
        require(!spec.stable) {"invalid_market"}
        require(s.quotes.any {it.symbol==symbol}) {"market_not_listed"}
        val mark = s.quote(symbol).price
        // Futures contracts may reference stocks and ETFs. Only the dedicated STOCK venue
        // requires a stock asset; Spot remains unavailable for stock/ETF assets.
        require(venue != OrderVenue.STOCK || spec.kind == AssetKind.STOCK) { "invalid_market" }
        require(venue != OrderVenue.SPOT || spec.kind != AssetKind.STOCK) { "invalid_market" }
        require(market.isOpen(spec,s.marketTime)) { "market_closed" }
        require(venue!=OrderVenue.FUTURES || s.listings.none {it.spec.symbol==symbol && s.marketTime<it.opensAt+NewsEngine.DAY}) {"listing_spot_only"}
        require(kind == OrderKind.MARKET || (trigger != null && trigger > ZERO)) { "invalid_price" }
        val wallet = when(venue) { OrderVenue.FUTURES -> Wallet.FUTURES; OrderVenue.SPOT -> Wallet.SPOT; OrderVenue.STOCK -> Wallet.STOCKS }
        if(venue == OrderVenue.FUTURES) {
            require(leverage in AssetCatalog.leverages) { "invalid_leverage" }
            require(amount >= d(1)) { "invalid_amount" }
            require(ONE.divD(d(leverage)) > FuturesMath.maintenanceRate(amount*d(leverage)) + FuturesMath.TAKER) { "leverage_tier" }
            validateBrackets(side, if(kind == OrderKind.MARKET) mark else trigger!!, takeProfit,stopLoss)
        }
        if(venue != OrderVenue.FUTURES && side == Side.SHORT) {
            val holding = s.holdings.firstOrNull { it.symbol == symbol }
            val committed = s.orders.filter { it.symbol == symbol && it.venue == venue && it.side == Side.SHORT }
                .fold(ZERO) { acc,o -> acc+o.amount }
            require((holding?.quantity ?: ZERO) - committed >= amount) { "insufficient_holding" }
        }
        val immediate = kind == OrderKind.MARKET || matches(kind,side,trigger,mark)
        val fee = if(!immediate && kind == OrderKind.LIMIT) FuturesMath.MAKER else FuturesMath.TAKER
        val reserve = if(venue == OrderVenue.FUTURES) amount + amount*d(leverage)*fee
            else if(side == Side.LONG) amount * (ONE+fee) else ZERO
        require(s.balance(wallet) >= reserve) { "insufficient_balance" }
        val order = Order(s.id(),symbol,venue,kind,side,mode,leverage,amount,trigger,takeProfit,stopLoss,wallet,reserve,s.marketTime)
        s.credit(wallet,-reserve)
        if(immediate) {
            s.credit(wallet,reserve)
            execute(s,order,fee)
            order.status = OrderStatus.FILLED; order.result = "filled";s.stats.filledOrders++; archive(s,order)
        } else s.orders.add(order)
    }
    fun cancel(s: GameState, id: Long) {
        val order = s.orders.first { it.id == id }
        s.credit(order.wallet,order.reserved); s.orders.remove(order)
        order.status = OrderStatus.CANCELLED; order.result = "cancelled"; archive(s,order)
    }
    fun process(s: GameState) {
        // Margin safety has priority over user triggers and queued entry orders.
        risk(s)
        for(p in s.positions.toList()) {
            if(s.positions.none {it.id==p.id})continue
            val mark = s.quote(p.symbol).price
            val tp = p.takeProfit?.let { if(p.side == Side.LONG) mark >= it else mark <= it } ?: false
            val sl = p.stopLoss?.let { if(p.side == Side.LONG) mark <= it else mark >= it } ?: false
            if(tp || sl) close(s,p.id, if(sl) "STOP_LOSS" else "TAKE_PROFIT")
        }
        for(order in s.orders.toList()) {
            if(!market.isOpen(market.spec(order.symbol,s),s.marketTime)) continue
            if(!matches(order.kind,order.side,order.trigger,s.quote(order.symbol).price)) continue
            s.orders.remove(order); s.credit(order.wallet,order.reserved)
            try {
                execute(s,order,if(order.kind == OrderKind.LIMIT) FuturesMath.MAKER else FuturesMath.TAKER)
                order.status = OrderStatus.FILLED; order.result = "filled";s.stats.filledOrders++
            } catch(e: IllegalArgumentException) { order.status = OrderStatus.REJECTED; order.result = e.message ?: "rejected" }
            archive(s,order)
        }
        risk(s)
    }
    fun processPath(s:GameState,previous:Map<String,BigDecimal>) {
        val endpoint=s.quotes.associate {it.symbol to it.price}
        val crossings=mutableListOf<Double>()
        fun cross(symbol:String,trigger:BigDecimal?) {
            if(trigger==null)return
            val start=previous[symbol] ?: return;val end=endpoint[symbol] ?: return
            if(start==end)return
            val t=(trigger-start).divD(end-start).toDouble()
            if(t>0 && t<=1)crossings.add(t)
        }
        for(p in s.positions){cross(p.symbol,p.stopLoss);cross(p.symbol,p.takeProfit)
            if(p.mode==MarginMode.ISOLATED) {
                val end=endpoint.getValue(p.symbol)
                if(p.margin+FuturesMath.pnl(p,end)<=FuturesMath.riskRequirement(p,end)) {
                    val start=previous[p.symbol] ?: end
                    var lo=0.0;var hi=1.0
                    repeat(48){val mid=(lo+hi)/2;val price=start+(end-start)*d(mid)
                        if(p.margin+FuturesMath.pnl(p,price)<=FuturesMath.riskRequirement(p,price))hi=mid else lo=mid}
                    crossings.add(hi)
                }
            }
        }
        s.orders.forEach {cross(it.symbol,it.trigger)}
        val crossPositions=s.positions.filter {it.mode==MarginMode.CROSS}
        if(crossPositions.isNotEmpty() && FuturesMath.crossEquity(s)<=FuturesMath.crossRequirement(s)) {
            fun unsafe(t:Double):Boolean {
                s.quotes.forEach {q->val start=previous[q.symbol] ?: endpoint.getValue(q.symbol);q.price=start+(endpoint.getValue(q.symbol)-start)*d(t)}
                return FuturesMath.crossEquity(s)<=FuturesMath.crossRequirement(s)
            }
            var lo=0.0;var hi=1.0;repeat(48){val m=(lo+hi)/2;if(unsafe(m))hi=m else lo=m}
            crossings.add(hi)
        }
        try {for(t in crossings.distinct().sorted()) {
            s.quotes.forEach {q->val start=previous[q.symbol] ?: endpoint.getValue(q.symbol);q.price=start+(endpoint.getValue(q.symbol)-start)*d(t)}
            process(s)
        }} finally {s.quotes.forEach {it.price=endpoint.getValue(it.symbol)}}
        process(s)
    }
    fun setBrackets(s: GameState,id: Long,tp: BigDecimal?,sl: BigDecimal?) {
        val p = s.positions.first { it.id == id }
        validateBrackets(p.side,s.quote(p.symbol).price,tp,sl)
        p.takeProfit=tp; p.stopLoss=sl
    }
    private fun validateBrackets(side: Side, reference: BigDecimal, tp: BigDecimal?, sl: BigDecimal?) {
        require(tp == null || tp > ZERO && (if(side == Side.LONG) tp > reference else tp < reference)) { "invalid_tp" }
        require(sl == null || sl > ZERO && (if(side == Side.LONG) sl < reference else sl > reference)) { "invalid_sl" }
    }
    private fun matches(kind: OrderKind,side: Side,trigger: BigDecimal?,price: BigDecimal): Boolean = when(kind) {
        OrderKind.MARKET -> true
        OrderKind.LIMIT -> if(side == Side.LONG) price <= trigger!! else price >= trigger!!
        OrderKind.STOP_MARKET -> if(side == Side.LONG) price >= trigger!! else price <= trigger!!
    }
    private fun execute(s: GameState, o: Order, feeRate: BigDecimal) {
        val mark = s.quote(o.symbol).price
        val slip = if(o.kind == OrderKind.LIMIT) ZERO else d(PriceEngine.slippage(s,o.symbol,if(o.venue==OrderVenue.FUTURES)o.amount.toDouble()*o.leverage else if(o.side==Side.LONG)o.amount.toDouble() else o.amount.toDouble()*mark.toDouble()))
        var entry = mark * (if(o.side == Side.LONG) ONE+slip else ONE-slip)
        // A limit fill never executes outside its limit.
        if(o.kind == OrderKind.LIMIT) entry = if(o.side == Side.LONG) minOf(entry,o.trigger!!) else maxOf(entry,o.trigger!!)
        if(o.venue == OrderVenue.FUTURES) {
            validateBrackets(o.side,entry,o.takeProfit,o.stopLoss)
            val notional = o.amount*d(o.leverage); val fee = notional*feeRate
            require(s.futuresCash >= o.amount+fee) { "insufficient_balance" }
            s.futuresCash -= o.amount+fee; s.stats.fees += fee
            s.progression.peakLeverage=maxOf(s.progression.peakLeverage,o.leverage)
            s.positions.add(Position(s.id(),o.symbol,o.side,o.marginMode,o.leverage,entry,
                notional.divD(entry),o.amount,o.amount,o.takeProfit,o.stopLoss,openFee=fee,openedAt=s.marketTime))
            record(s,Trade(s.id(),o.symbol,o.side,o.venue,entry,entry,notional.divD(entry),ZERO,fee,"OPEN",s.marketTime),false)
        } else if(o.side == Side.LONG) {
            val fee = o.amount*feeRate
            require(s.balance(o.wallet) >= o.amount+fee) { "insufficient_balance" }
            val holding = s.holdings.firstOrNull { it.symbol == o.symbol }
                ?: Holding(o.symbol).also { s.holdings.add(it) }
            s.credit(o.wallet,-o.amount-fee); s.stats.fees += fee
            holding.quantity += o.amount.divD(entry); holding.cost += o.amount+fee
            record(s,Trade(s.id(),o.symbol,o.side,o.venue,entry,entry,o.amount.divD(entry),ZERO,fee,"BUY",s.marketTime),false)
        } else {
            val holding = s.holdings.firstOrNull { it.symbol == o.symbol }
            require(holding != null && holding.quantity >= o.amount) { "insufficient_holding" }
            val average = holding.average; val gross = o.amount*entry; val fee = gross*feeRate
            val cost = o.amount*average; val realized = gross-fee-cost
            s.credit(o.wallet,gross-fee); s.stats.fees += fee
            holding.quantity -= o.amount; holding.cost = (holding.cost-cost).positive()
            if(holding.quantity <= ZERO) s.holdings.remove(holding)
            if(o.venue == OrderVenue.STOCK) s.stats.stocks += realized else s.stats.spot += realized
            record(s,Trade(s.id(),o.symbol,o.side,o.venue,average,entry,o.amount,realized,fee,"SELL",s.marketTime),true)
        }
    }
    fun close(s:GameState,id:Long,reason:String="CLOSED")=closeSlice(s,id,ONE,reason)
    fun closeFraction(s:GameState,id:Long,fraction:BigDecimal) {
        require(fraction>ZERO && fraction<=ONE){"invalid_fraction"}
        closeSlice(s,id,fraction,if(fraction<ONE)"PARTIAL_CLOSE" else "CLOSED")
    }
    private fun closeSlice(s:GameState,id:Long,fraction:BigDecimal,reason:String) {
        val index=s.positions.indexOfFirst {it.id==id};require(index>=0){"position_missing"}
        val p=s.positions[index]
        val slice=p.copy(quantity=p.quantity*fraction,margin=p.margin*fraction,originalMargin=p.originalMargin*fraction,
            funding=p.funding*fraction,openFee=p.openFee*fraction)
        val mark=s.quote(p.symbol).price;val fee=FuturesMath.notional(slice,mark)*FuturesMath.TAKER
        val raw=slice.margin+FuturesMath.pnl(slice,mark)-fee
        val release=if(p.mode==MarginMode.ISOLATED)raw.positive() else raw
        s.futuresCash+=release
        if(fraction==ONE)s.positions.removeAt(index) else s.positions[index]=p.copy(quantity=p.quantity-slice.quantity,
            margin=p.margin-slice.margin,originalMargin=p.originalMargin-slice.originalMargin,
            funding=p.funding-slice.funding,openFee=p.openFee-slice.openFee)
        s.stats.fees+=fee;val net=release-slice.originalMargin-slice.openFee;s.stats.futures+=net
        record(s,Trade(s.id(),p.symbol,p.side,OrderVenue.FUTURES,p.entry,mark,slice.quantity,net,
            fee+slice.openFee,reason,s.marketTime),true)
        if(reason=="STOP_LOSS")s.stats.stopExecutions++
        if(reason=="TAKE_PROFIT")s.stats.takeProfitExecutions++
        if(reason=="LIQUIDATED")s.stats.liquidations++
        if(reason=="LIQUIDATED")s.stats.largestLiquidation=maxOf(s.stats.largestLiquidation,(-net).positive()) else risk(s)
    }
    fun risk(s: GameState) {
        s.positions.filter { it.mode == MarginMode.ISOLATED }.toList().forEach { p ->
            val mark = s.quote(p.symbol).price
            if(p.margin+FuturesMath.pnl(p,mark) <= FuturesMath.riskRequirement(p,mark)) close(s,p.id,"LIQUIDATED")
        }
        val cross = s.positions.filter { it.mode == MarginMode.CROSS }
        val requirement=FuturesMath.crossRequirement(s)
        if(cross.isNotEmpty() && FuturesMath.crossEquity(s) <= requirement) liquidateCross(s)
    }
    private fun liquidateCross(s: GameState) {
        val positions = s.positions.filter { it.mode == MarginMode.CROSS }
        if(positions.isEmpty()) return
        val starting = s.futuresCash + positions.fold(ZERO) { acc,p -> acc+p.margin }
        val rawEquity = FuturesMath.crossEquity(s)
        val closeFees = positions.fold(ZERO) { acc,p -> acc+FuturesMath.notional(p,s.quote(p.symbol).price)*FuturesMath.TAKER }
        val remainder = (rawEquity-closeFees).positive()
        val actualLoss = remainder - starting
        val totalMargins = positions.fold(ZERO) { acc,p -> acc+p.originalMargin }
        for(p in positions) {
            val allocation = actualLoss * p.originalMargin.divD(totalMargins) + p.funding - p.openFee
            s.stats.futures += allocation
            s.stats.largestLiquidation = maxOf(s.stats.largestLiquidation,(-allocation).positive())
            record(s,Trade(s.id(),p.symbol,p.side,OrderVenue.FUTURES,p.entry,s.quote(p.symbol).price,p.quantity,
                allocation,p.openFee+FuturesMath.notional(p,s.quote(p.symbol).price)*FuturesMath.TAKER,"LIQUIDATED",s.marketTime),true)
            s.stats.liquidations++;s.positions.remove(p)
        }
        s.stats.fees += closeFees; s.futuresCash = remainder
    }
    fun funding(s: GameState) {
        val bucket = s.marketTime / 28800000L
        if(bucket <= s.fundingBucket) return
        val periods = bucket-s.fundingBucket
        val fallback = when(s.regime) { Regime.BULL -> d("0.0001"); Regime.BEAR -> d("-0.0001"); Regime.SIDEWAYS -> d("0.000025") }
        for(p in s.positions) {
            val rate=s.world.micro[p.symbol]?.let {d(it.funding)} ?: fallback
            val signed = if(p.side == Side.LONG) -ONE else ONE
            val payment = FuturesMath.notional(p,s.quote(p.symbol).price)*rate*signed*d(periods)
            p.margin += payment; p.funding += payment; s.stats.funding += payment
        }
        s.fundingBucket = bucket
        risk(s)
    }
    private fun archive(s: GameState,o: Order) {
        s.orderHistory.add(0,o); while(s.orderHistory.size > 300) s.orderHistory.removeAt(s.orderHistory.lastIndex)
    }
    private fun record(s: GameState,t: Trade,closed: Boolean) {
        s.trades.add(0,t); while(s.trades.size > 500) s.trades.removeAt(s.trades.lastIndex)
        if(closed) {
            if(s.stats.trades == 0) { s.stats.bestTrade=t.pnl; s.stats.worstTrade=t.pnl }
            else { s.stats.bestTrade=maxOf(s.stats.bestTrade,t.pnl); s.stats.worstTrade=minOf(s.stats.worstTrade,t.pnl) }
            s.stats.trades++; if(t.pnl > ZERO) s.stats.wins++
        }
    }
}
