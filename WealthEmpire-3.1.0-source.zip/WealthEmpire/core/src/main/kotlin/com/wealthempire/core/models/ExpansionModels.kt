@file:UseSerializers(DecimalSerializer::class)
package com.wealthempire.core.models

import java.math.BigDecimal
import kotlinx.serialization.Serializable
import kotlinx.serialization.UseSerializers

/** Internal news families are deliberately not exposed as predictable UI categories. */
@Serializable enum class NewsFamily { POLICY, INFLATION, GROWTH, CREDIT, SECURITY, ADOPTION, COMPANY, ENERGY, GEOPOLITICS, LIQUIDITY }
@Serializable data class EconomyState(
    var initialized:Boolean=false, var policyRate:Double=4.5, var inflation:Double=2.8,
    var growth:Double=2.0, var riskAppetite:Double=0.0, var dollarPressure:Double=0.0,
    var energySupply:Double=0.0, var cryptoTrust:Double=0.0,
    var nextRandomNewsAt:Long=0, var nextPolicyAt:Long=0, var nextInflationAt:Long=0,
    var nextJobsAt:Long=0, var nextInventoryAt:Long=0, var nextEarningsAt:Long=0,
    var nextListingAt:Long=0, var lastNewsKeys:MutableList<String> = mutableListOf()
)
@Serializable data class MarketEffect(val id:Long,val symbol:String,val startsAt:Long,val expiresAt:Long,
    val driftPerMinute:Double,val volatilityBoost:Double,val halfLifeMs:Long,val storyId:Long=0)
@Serializable data class MarketStory(val id:Long,val family:NewsFamily,val symbol:String,
    val nextAt:Long,val severity:Double,val stage:Int=0)
@Serializable enum class ListingStatus { UPCOMING, LIVE }
@Serializable data class AssetListing(val id:Long,val spec:AssetSpec,val announceAt:Long,
    val opensAt:Long,var status:ListingStatus=ListingStatus.UPCOMING,val narrative:String="")
@Serializable data class SavingsOffer(val symbol:String,var baseApr:BigDecimal,
    var bonusApr:BigDecimal,val bonusQuota:BigDecimal,var locked30Apr:BigDecimal,
    var locked90Apr:BigDecimal,var nextRateAt:Long)
@Serializable enum class SavingsStatus { ACTIVE, REDEEMING }
@Serializable data class SavingsPosition(val id:Long,val symbol:String,var principal:BigDecimal,
    var costBasis:BigDecimal,val days:Int,val fixedApr:BigDecimal,
    var rewards:BigDecimal=ZERO,var distributed:BigDecimal=ZERO,var distributedUsd:BigDecimal=ZERO,
    val subscribedAt:Long,val maturesAt:Long,var lastAccruedAt:Long,var nextPayoutAt:Long,
    val autoCompound:Boolean=true,var status:SavingsStatus=SavingsStatus.ACTIVE,var redeemAt:Long=0,
    var lastHistoryAt:Long=subscribedAt,var historyReward:BigDecimal=ZERO)
@Serializable data class SavingsRecord(val id:Long,val positionId:Long,val symbol:String,
    val action:String,val quantity:BigDecimal,val apr:BigDecimal,val time:Long)
