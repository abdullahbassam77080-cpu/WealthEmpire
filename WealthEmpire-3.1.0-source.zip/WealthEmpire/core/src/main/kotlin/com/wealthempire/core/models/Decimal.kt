package com.wealthempire.core.models

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlinx.serialization.KSerializer
import kotlinx.serialization.descriptors.PrimitiveKind
import kotlinx.serialization.descriptors.PrimitiveSerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder

val MC = MathContext(28, RoundingMode.HALF_EVEN)
val ZERO: BigDecimal = BigDecimal.ZERO
val ONE: BigDecimal = BigDecimal.ONE
fun d(value: String): BigDecimal = value.toBigDecimal(MC)
fun d(value: Long): BigDecimal = BigDecimal.valueOf(value)
fun d(value: Int): BigDecimal = d(value.toLong())
fun d(value: Double): BigDecimal { require(value.isFinite()); return BigDecimal.valueOf(value) }
fun BigDecimal.divD(other: BigDecimal): BigDecimal = divide(other, MC)
fun BigDecimal.money(): BigDecimal = setScale(8, RoundingMode.HALF_EVEN)
fun BigDecimal.positive(): BigDecimal = max(ZERO)
object DecimalSerializer : KSerializer<BigDecimal> {
    override val descriptor = PrimitiveSerialDescriptor("Decimal", PrimitiveKind.STRING)
    override fun serialize(encoder: Encoder, value: BigDecimal) = encoder.encodeString(value.toPlainString())
    override fun deserialize(decoder: Decoder) = decoder.decodeString().toBigDecimal()
}
