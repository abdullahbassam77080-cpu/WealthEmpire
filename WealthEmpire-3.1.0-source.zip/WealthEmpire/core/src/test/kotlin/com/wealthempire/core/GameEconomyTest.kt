package com.wealthempire.core

import com.wealthempire.core.market.GameClock
import com.wealthempire.core.models.*
import com.wealthempire.core.statistics.Wealth
import kotlinx.serialization.json.Json
import org.junit.Test
import kotlin.test.*

class GameEconomyTest {
    @Test fun freshGameStartsWithExactlyTwentyThousandAndNoEarnedProfit() {
        val s=GameEngine().newGame(1000,42)
        assertEquals(d(20000),s.cash);assertEquals(d(20000),s.initialCapital)
        assertEquals(d(20000),Wealth.financialTotal(s));assertEquals(d(20000),s.stats.highestWealth)
        assertEquals(ZERO,s.futuresCash+s.spotCash+s.stocksCash)
        assertTrue(s.holdings.isEmpty() && s.positions.isEmpty() && s.orders.isEmpty() && s.savings.isEmpty())
        assertEquals(0L,s.xp);assertTrue(s.achievements.isEmpty())
        assertEquals(ZERO,Wealth.total(s)-s.initialCapital)
    }
    @Test fun idleCashDoesNotGrowAtAnyClockSpeedOrAfterAbsence() {
        for(speed in GameClock.speeds) {
            val engine=GameEngine();val s=engine.newGame(1000,42);s.marketSpeed=speed
            engine.tick(s,61000);assertEquals(d(20000),s.cash)
            engine.resume(s,1000+12*3600000L);assertEquals(d(20000),s.cash)
            val copy=GameStateCopy.copy(s);engine.resume(s,s.lastSeenAt)
            assertEquals(copy.cash,s.cash);assertEquals(copy.ticks,s.ticks)
        }
    }
    @Test fun previousEconomiesRestartOnceAndDiscardAllPriorFinancialState() {
        val engine=GameEngine()
        for(schema in 1..4) {
            val old=GameState(schema=schema,cash=d(9_000_000),futuresCash=d(50),xp=9999,marketSpeed=12,marketCarryMs=12345,alertsEnabled=false)
            old.holdings.add(Holding("BTC",ONE,d(65000)));old.achievements.add("1000000")
            val fresh=engine.restore(old,5000,42)
            assertEquals(d(20000),fresh.cash);assertEquals(ZERO,fresh.futuresCash)
            assertTrue(fresh.holdings.isEmpty());assertTrue(fresh.achievements.isEmpty())
            assertEquals(0L,fresh.xp);assertEquals(0L,fresh.marketCarryMs)
            assertEquals(12,fresh.marketSpeed);assertFalse(fresh.alertsEnabled);assertTrue(fresh.alerts.isEmpty())
            fresh.cash=d(12345);assertSame(fresh,engine.restore(fresh,6000,99))
            assertEquals(d(12345),fresh.cash)
        }
    }
    @Test fun currentSaveKeepsTradesAndSettingsWithoutToppingUpBalance() {
        val e=GameEngine();val s=e.newGame(1000,42);s.cash=d(123);s.marketSpeed=16
        s.holdings.add(Holding("BTC",d("0.01"),d(650)));val before=GameStateCopy.copy(s)
        assertSame(s,e.restore(s,5000,99));assertEquals(before,s)
        e.tick(s,61000);assertEquals(d(123),s.cash)
    }
    @Test fun unsupportedSaveAndInvalidSpeedDoNotChangeMoney() {
        val e=GameEngine();val s=GameState(schema=7,cash=d(77))
        assertFailsWith<IllegalArgumentException>{e.restore(s,1000,42)};assertEquals(d(77),s.cash)
        val fresh=e.newGame(1000,42);val before=GameStateCopy.copy(fresh)
        assertFailsWith<IllegalArgumentException>{e.setSpeed(fresh,30,61000)};assertEquals(before,fresh)
    }
    @Test fun speedChangeSettlesTheOldPhaseAndSaveRetainsTheFraction() {
        val e=GameEngine();val s=e.newGame(1000,42);val start=s.marketTime
        e.setSpeed(s,12,31000);while(e.advanceOne(s)){};assertEquals(start+30000,GameClock.visualTime(s,31000))
        e.tick(s,36000);while(e.advanceOne(s)){};assertEquals(start+90000,GameClock.visualTime(s,36000))
        val json=Json {encodeDefaults=true}
        val copy=json.decodeFromString<GameState>(json.encodeToString(GameState.serializer(),s))
        e.setSpeed(copy,1,36000);e.tick(copy,66000);while(e.advanceOne(copy)){}
        assertEquals(start+120000,GameClock.visualTime(copy,66000));assertEquals(d(20000),copy.cash)
    }
}
