package com.wealthempire.core

import com.wealthempire.core.models.*
import com.wealthempire.core.market.*
import com.wealthempire.core.trading.*
import com.wealthempire.core.wallet.WalletRules
import com.wealthempire.core.statistics.Wealth
import kotlinx.serialization.json.Json
import org.junit.Test
import kotlin.test.*
import java.math.BigDecimal

class EngineTest {
    private val engine=GameEngine()
    private val trader=engine.trading
    private fun state():GameState = GameState(schema=SaveMigrations.CURRENT_SCHEMA,cash=d(6000),futuresCash=d(1000),spotCash=d(1000),stocksCash=d(1000),
        marketTime=1791194400000L,lastSeenAt=1000).also {
        it.fundingBucket=it.marketTime/28800000L
        AssetCatalog.defaults.forEach { spec->it.quotes.add(Quote(spec.symbol,spec.initialPrice,spec.initialPrice)) }
    }
    private fun near(expected:BigDecimal,actual:BigDecimal,tolerance:BigDecimal=d("0.0000001")) = assertTrue((expected-actual).abs()<tolerance,"$expected != $actual")
    private fun open(s:GameState,side:Side=Side.LONG,mode:MarginMode=MarginMode.ISOLATED,leverage:Int=10,amount:BigDecimal=d(100)) {
        trader.submit(s,"BTC",OrderVenue.FUTURES,OrderKind.MARKET,side,amount,leverage,mode)
    }
    @Test fun leverageIsAppliedOnce() {
        val s=state();open(s);val p=s.positions.single()
        near(d(1000),p.quantity*p.entry)
        near(d(100),FuturesMath.pnl(p,p.entry*d("1.1")))
        near(d(100),FuturesMath.roe(p,p.entry*d("1.1")))
        near(d("899.5"),s.futuresCash)
    }
    @Test fun shortPnlDirection() {
        val s=state();open(s,Side.SHORT);val p=s.positions.single()
        near(d(200),FuturesMath.pnl(p,p.entry*d("0.8")))
        near(d(-100),FuturesMath.pnl(p,p.entry*d("1.1")))
    }
    @Test fun isolatedLiquidationEquationIncludesClosingFee() {
        val s=state();open(s);val p=s.positions.single();val price=FuturesMath.liquidation(p)
        near(FuturesMath.riskRequirement(p,price),p.margin+FuturesMath.pnl(p,price))
        assertTrue(price<p.entry)
    }
    @Test fun shortLiquidationEquation() {
        val s=state();open(s,Side.SHORT);val p=s.positions.single();val price=FuturesMath.liquidation(p)
        near(FuturesMath.riskRequirement(p,price),p.margin+FuturesMath.pnl(p,price));assertTrue(price>p.entry)
    }
    @Test fun crossUsesFreeFundsWhileIsolatedDoesNot() {
        val a=state();val b=state();open(a);open(b,mode=MarginMode.CROSS)
        a.quote("BTC").price=d(50000);b.quote("BTC").price=d(50000)
        trader.risk(a);trader.risk(b)
        assertTrue(a.positions.isEmpty());assertEquals(1,b.positions.size)
        near(d("899.5"),a.futuresCash);assertEquals("LIQUIDATED",a.trades.first().reason)
    }
    @Test fun crossLiquidationClosesPoolAndCannotSpendCashWallet() {
        val s=state();open(s,mode=MarginMode.CROSS,leverage=100)
        val cash=s.cash;s.quote("BTC").price=d(1);trader.risk(s)
        assertTrue(s.positions.isEmpty());near(ZERO,s.futuresCash);assertEquals(cash,s.cash)
        assertEquals("LIQUIDATED",s.trades.first().reason)
    }
    @Test fun crossWithdrawalCannotRemoveRequiredCollateral() {
        val s=state();open(s,mode=MarginMode.CROSS);s.quote("BTC").price=d(58500)
        assertFails {WalletRules.transfer(s,Wallet.FUTURES,Wallet.CASH,d(899))}
    }
    @Test fun crossLiquidationEstimateChangesWhenTransferredIn() {
        val s=state();open(s,mode=MarginMode.CROSS,leverage=100)
        val p=s.positions.single();val before=FuturesMath.liquidation(s,p)
        WalletRules.transfer(s,Wallet.CASH,Wallet.FUTURES,d(1000))
        assertTrue(FuturesMath.liquidation(s,p)<before)
    }
    @Test fun fiveHundredAllowedOnlyForSmallNotional() {
        val s=state();open(s,leverage=500,amount=d(1));assertEquals(500,s.positions.single().leverage)
        s.futuresCash=d(100000);assertFails {open(s,leverage=500,amount=d(1000))}
    }
    @Test fun closeChargesBothFeesAndConservesEquity() {
        val s=state();val before=Wealth.total(s);open(s)
        val p=s.positions.single();s.quote("BTC").price=p.entry
        trader.close(s,p.id)
        near(d("999"),s.futuresCash);near(d(-1),s.stats.futures)
        near(before-d(1),Wealth.total(s));near(d(1),s.stats.fees)
    }
    @Test fun limitReservesFundsAndCancelRestoresWealth() {
        val s=state();val before=Wealth.total(s)
        trader.submit(s,"BTC",OrderVenue.FUTURES,OrderKind.LIMIT,Side.LONG,d(100),10,trigger=d(60000))
        near(d("899.8"),s.futuresCash);near(before,Wealth.total(s))
        trader.cancel(s,s.orders.single().id);near(d(1000),s.futuresCash);assertTrue(s.orders.isEmpty())
    }
    @Test fun makerLimitFillsAtCorrectPriceAndFee() {
        val s=state();trader.submit(s,"BTC",OrderVenue.FUTURES,OrderKind.LIMIT,Side.LONG,d(100),10,trigger=d(60000))
        s.quote("BTC").price=d(59000);trader.process(s)
        assertTrue(s.orders.isEmpty());near(d(59000),s.positions.single().entry);near(d("0.2"),s.positions.single().openFee)
    }
    @Test fun crossingLimitIsTaker() {
        val s=state();trader.submit(s,"BTC",OrderVenue.FUTURES,OrderKind.LIMIT,Side.LONG,d(100),10,trigger=d(70000))
        near(d("0.5"),s.positions.single().openFee)
    }
    @Test fun stopMarketReservesTakerFeeAndTriggersOnlyAbovePrice() {
        val s=state();trader.submit(s,"BTC",OrderVenue.FUTURES,OrderKind.STOP_MARKET,Side.LONG,d(100),10,trigger=d(66000))
        near(d("100.5"),s.orders.single().reserved);trader.process(s);assertTrue(s.positions.isEmpty())
        s.quote("BTC").price=d(67000);trader.process(s);assertEquals(1,s.positions.size)
    }
    @Test fun takeProfitClosesAutomatically() {
        val s=state();trader.submit(s,"BTC",OrderVenue.FUTURES,OrderKind.MARKET,Side.LONG,d(100),10,takeProfit=d(70000),stopLoss=d(62000))
        s.quote("BTC").price=d(71000);trader.process(s)
        assertTrue(s.positions.isEmpty());assertEquals("TAKE_PROFIT",s.trades.first().reason)
    }
    @Test fun liquidationWinsOverStopOnGap() {
        val s=state();trader.submit(s,"BTC",OrderVenue.FUTURES,OrderKind.MARKET,Side.LONG,d(100),10,stopLoss=d(63000))
        s.quote("BTC").price=d(1);trader.process(s)
        assertEquals("LIQUIDATED",s.trades.first().reason);assertTrue(s.futuresCash>=ZERO)
    }
    @Test fun spotAverageIncludesFeeAndSaleAccountsForCost() {
        val s=state();val before=Wealth.total(s)
        trader.submit(s,"BTC",OrderVenue.SPOT,OrderKind.MARKET,Side.LONG,d(100))
        val h=s.holdings.single();val quantity=h.quantity;near(d("100.05"),h.cost)
        trader.submit(s,"BTC",OrderVenue.SPOT,OrderKind.MARKET,Side.SHORT,quantity)
        assertTrue(s.holdings.isEmpty());assertTrue(s.stats.spot<ZERO)
        near(before+s.stats.spot,Wealth.total(s));assertEquals(1,s.stats.trades)
    }
    @Test fun pendingSellCannotOversellHoldings() {
        val s=state();trader.submit(s,"BTC",OrderVenue.SPOT,OrderKind.MARKET,Side.LONG,d(100))
        val q=s.holdings.single().quantity
        trader.submit(s,"BTC",OrderVenue.SPOT,OrderKind.LIMIT,Side.SHORT,q,trigger=d(70000))
        assertFails {trader.submit(s,"BTC",OrderVenue.SPOT,OrderKind.MARKET,Side.SHORT,q)}
    }
    @Test fun stockSessionsEnforced() {
        val s=state();assertTrue(engine.market.stockOpen(s.marketTime))
        s.marketTime+=12*3600000L
        assertFalse(engine.market.stockOpen(s.marketTime))
        assertFails {trader.submit(s,"APL",OrderVenue.STOCK,OrderKind.MARKET,Side.LONG,d(100))}
        val before=s.quote("APL").price;engine.market.step(s);assertEquals(before,s.quote("APL").price)
    }
    @Test fun fundingIsAppliedOncePerBucket() {
        val s=state();open(s);s.regime=Regime.BULL;s.marketTime+=28800000L
        trader.funding(s);val margin=s.positions.single().margin;val payment=s.positions.single().funding
        assertTrue(payment<ZERO);trader.funding(s);assertEquals(margin,s.positions.single().margin)
    }
    @Test fun newsHasAnActualPriceEngineBias() {
        val s=state();engine.market.addNews(s,"etf_inflow","CRYPTO",.01)
        assertTrue(s.quote("BTC").eventBias>0);near(ZERO,d(s.quote("APL").eventBias))
        engine.market.step(s);assertTrue(s.quote("BTC").price>d(65000));assertTrue(s.news.any {it.key=="etf_inflow"})
    }
    @Test fun simulationProducesValidCandlesAndDifferentAssetRisk() {
        val s=state();repeat(1000){engine.market.step(s)}
        s.quotes.forEach { q ->assertTrue(q.price>ZERO)
            q.bars.values.forEach { bars ->assertTrue(bars.size<=260);bars.forEach { b->
                assertTrue(b.high>=b.open && b.high>=b.close);assertTrue(b.low<=b.open && b.low<=b.close);assertTrue(b.volume>=ZERO);if(!engine.market.spec(q.symbol,s).stable)assertTrue(b.volume>ZERO)
            } }
        }
        assertTrue(AssetCatalog.defaults.first {it.symbol=="DOGE"}.volatility>AssetCatalog.defaults.first().volatility)
    }
    @Test fun decimalSnapshotRoundtripPreservesEntireState() {
        val s=engine.newGame(1000,42);s.cash=d("999999999999.12345678")
        val json=Json {encodeDefaults=true}
        val round=json.decodeFromString<GameState>(json.encodeToString(GameState.serializer(),s))
        assertEquals(s,round);assertEquals(s.cash.toPlainString(),round.cash.toPlainString())
    }
    @Test fun indicatorsWarmUpAndConstantSeriesAreCorrect() {
        val values=List(250){100.0};val ema=Indicators.ema(values,200)
        assertNull(ema[198]);assertEquals(100.0,ema.last())
        assertEquals(50.0,Indicators.rsi(values).last());assertEquals(0.0,Indicators.macd(values).line.last())
        assertEquals(100.0,Indicators.bollinger(values).first.last())
    }
    @Test fun resetStartsCleanAndRealTimeResumeIsIdempotent() {
        val s=state();engine.resume(s,61000);val cash=s.cash;val ticks=s.ticks
        engine.resume(s,61000);assertEquals(cash,s.cash);assertEquals(ticks,s.ticks)
        val fresh=engine.newGame(61000,42);assertEquals(d(20000),fresh.cash);assertTrue(fresh.positions.isEmpty());assertTrue(fresh.orders.isEmpty())
    }
}
