package com.wealthempire.core

import com.wealthempire.core.models.*
import com.wealthempire.core.statistics.Wealth
import com.wealthempire.core.wallet.WalletRules
import org.junit.Test
import kotlin.test.*

class FinancialDashboardTest {
    @Test fun totalMatchesAllFinancialFundsExactly() {
        val s=GameEngine().newGame(1000,42);s.cash=d("102.05")
        assertEquals(d("102.05"),Wealth.total(s))
        assertEquals(d("102.05"),Wealth.financialTotal(s))
        assertEquals(ZERO,Wealth.financialInvested(s))
    }
    @Test fun investmentsOrdersAndAllWalletsCountOnceWithBothSidesPnl() {
        val s=GameEngine().newGame(1000,42)
        s.cash=d(100);s.futuresCash=d(20);s.spotCash=d(30);s.stocksCash=d(40)
        s.quote("BTC").price=d(110);s.holdings.add(Holding("BTC",d(2),d(200)))
        s.positions.add(Position(1,"BTC",Side.LONG,MarginMode.CROSS,10,d(100),d(3),d(30),d(30),openedAt=0))
        s.positions.add(Position(2,"BTC",Side.SHORT,MarginMode.CROSS,10,d(100),d(1),d(10),d(10),openedAt=0))
        s.orders.add(Order(3,"BTC",OrderVenue.SPOT,OrderKind.LIMIT,Side.LONG,MarginMode.ISOLATED,1,d(50),d(90),null,null,Wallet.SPOT,d(50),0))
        s.stats.futures=d(8000);s.stats.spot=d(-9000)
        assertEquals(d(520),Wealth.financialTotal(s)) // cash 190 + holdings 220 + margins 40 + net PNL 20 + reserve 50
        assertEquals(d(330),Wealth.financialInvested(s))
    }
    @Test fun walletTransfersCannotIncreaseFinancialTotal() {
        val s=GameEngine().newGame(1000,42)
        WalletRules.transfer(s,Wallet.CASH,Wallet.FUTURES,d(5000))
        WalletRules.transfer(s,Wallet.CASH,Wallet.SPOT,d(5000))
        assertEquals(0,Wealth.financialTotal(s).compareTo(d(20000)))
        assertEquals(Wealth.total(s),Wealth.financialTotal(s))
    }
    @Test fun dashboardChartAndDayChangeUseFinancialEquity() {
        val s=GameEngine().newGame(1000,42);s.cash-=d(300)
        Wealth.update(s,s.marketTime+60000)
        assertEquals(d(19700).money(),s.financialHistory.last().value.money())
        assertEquals(d(-300),Wealth.financialTotal(s)-s.stats.financialDayStart!!)
        assertEquals(Wealth.total(s),Wealth.financialTotal(s))
    }
}
