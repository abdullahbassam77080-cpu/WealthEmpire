package com.wealthempire.core

import com.wealthempire.core.models.*
import com.wealthempire.core.market.*
import kotlinx.serialization.json.Json
import java.time.Instant
import org.junit.Test
import kotlin.test.*

class MarketClockAlertsTest {
    private fun time(value:String)=Instant.parse(value).toEpochMilli()
    private fun state(at:String)=GameState(schema=3,marketTime=time(at),marketTickAt=1000,lastSeenAt=1000)
    @Test fun sessionEdgesAndWeekend() {
        assertFalse(MarketSessions.isOpen(time("2026-10-05T09:29:59Z")))
        assertTrue(MarketSessions.isOpen(time("2026-10-05T09:30:00Z")))
        assertFalse(MarketSessions.isOpen(time("2026-10-05T16:00:00Z")))
        assertFalse(MarketSessions.isOpen(time("2026-10-10T10:00:00Z")))
        assertEquals(time("2026-10-12T09:30:00Z"),MarketSessions.nextTransition(time("2026-10-09T16:00:00Z")).time)
    }
    @Test fun oneNoticePerSessionEdge() {
        val market=MarketEngine();val s=state("2026-10-05T09:29:00Z");market.seed(s)
        assertTrue(s.alerts.isEmpty());market.step(s);assertEquals(AlertType.MARKET_OPEN,s.alerts.single().type)
        val id=s.alerts.single().id;market.step(s);assertEquals(id,s.alerts.single().id)
        s.marketTime=time("2026-10-05T15:59:00Z");market.step(s)
        assertEquals(AlertType.MARKET_CLOSED,s.alerts.single().type)
    }
    @Test fun newsNoticeAndPriceBiasShareEvent() {
        val market=MarketEngine();val s=state("2026-10-05T10:00:00Z");market.seed(s)
        market.addNews(s,"regulation","CRYPTO",-.009)
        assertEquals(s.news.first().id,s.alerts.single().id)
        assertEquals(-.009,s.quote("BTC").eventBias);assertEquals(0.0,s.quote("APL").eventBias)
        market.addNews(s,"welcome","ALL",0.0);assertEquals(1,s.alerts.size)
    }
    @Test fun onlyLatestNoticePersistsAndDismisses() {
        val s=state("2026-10-05T10:00:00Z")
        for(id in 1L..25L)GameAlerts.enqueue(s,GameAlert(id,AlertType.NEWS,"recession","ALL",s.marketTime))
        assertEquals(25,s.alerts.single().id)
        GameAlerts.enqueue(s,s.alerts.single());assertEquals(1,s.alerts.size)
        val copy=Json.decodeFromString<GameState>(Json.encodeToString(GameState.serializer(),s))
        assertEquals(s.alerts,copy.alerts);GameAlerts.dismiss(copy,25);assertTrue(copy.alerts.isEmpty())
    }
    @Test fun notificationsOffDoesNotDisableNewsPriceEffects() {
        val market=MarketEngine();val s=state("2026-10-05T09:29:00Z");market.seed(s);s.alertsEnabled=false
        market.step(s);market.addNews(s,"regulation","CRYPTO",-.009)
        assertTrue(s.alerts.isEmpty());assertTrue(s.news.any {it.key=="regulation"})
        assertEquals(-.009,s.quote("BTC").eventBias)
    }
    @Test fun everyTimeframeAtEverySelectableSpeed() {
        val s=state("2026-10-05T00:00:00Z")
        for(speed in GameClock.speeds.filter {it>0}) {
            s.marketSpeed=speed
            for(frame in AssetCatalog.frames) {
                assertEquals(frame*60000L,GameClock.candleRemaining(s,frame,1000))
                assertEquals(frame*60000L/speed,GameClock.realRemaining(GameClock.candleRemaining(s,frame,1000),speed))
            }
            assertEquals(60000L-1000*speed,GameClock.candleRemaining(s,1,2000))
        }
    }
    @Test fun ticksPreserveSubminutePhaseAndBackwardClock() {
        val engine=GameEngine();val s=engine.newGame(1000,42);s.marketSpeed=12
        val start=s.marketTime
        engine.tick(s,2500);assertEquals(start+8000,s.marketTime);assertEquals(10000,s.pendingWorldMs)
        while(engine.advanceOne(s)){};assertEquals(start+18000,s.marketTime)
        engine.tick(s,6500);while(engine.advanceOne(s)){}
        assertEquals(start+66000,s.marketTime);assertEquals(0,s.marketCarryMs)
        assertEquals(s.marketTime,GameClock.visualTime(s,6500))
        engine.tick(s,2000);assertEquals(6500,s.marketTickAt);assertEquals(0,s.marketCarryMs)
    }
    @Test fun offlineReplayUsesSavedSpeedAndCapsSteps() {
        val engine=GameEngine();val s=engine.newGame(1000,42);s.marketSpeed=16
        s.marketTime=time("2026-10-05T15:59:00Z");engine.resume(s,3601000)
        assertEquals(time("2026-10-06T07:59:00Z"),s.marketTime);val ticks=s.ticks;assertTrue(s.alerts.size<=1);assertEquals(3601000,s.marketTickAt)
        engine.resume(s,3601000);assertEquals(ticks,s.ticks)
        val realtime=engine.newGame(1000,42);engine.resume(realtime,61000);assertEquals(time("2026-10-05T10:01:00Z"),realtime.marketTime)
    }
    @Test fun liveStallReanchorsAfterFiveSteps() {
        val engine=GameEngine();val s=engine.newGame(1000,42);s.marketSpeed=12;val start=s.marketTime
        engine.tick(s,101000);while(engine.advanceOne(s)){};assertEquals(start+1200000,s.marketTime)
        assertEquals(101000,s.marketTickAt);assertEquals(s.marketTime,GameClock.visualTime(s,101000))
    }
}
