package com.wealthempire.core

import com.wealthempire.core.market.*
import com.wealthempire.core.models.*
import com.wealthempire.core.trading.TradingEngine
import com.wealthempire.core.statistics.Wealth
import org.junit.Test
import kotlin.test.*

class ExpandedMarketTest {
    private val market=MarketEngine()
    private fun state()=GameState(marketTime=1791280800000L,spotCash=d(10000),stocksCash=d(10000),futuresCash=d(10000),rngState=42).also {s->
        AssetCatalog.defaults.forEach {s.quotes.add(Quote(it.symbol,it.initialPrice,it.initialPrice,dayBucket=s.marketTime/NewsEngine.DAY))}
        market.news.initialize(s)
    }
    @Test fun goldEnergyStocksAndAsianCurrenciesHaveCorrectUnits() {
        assertEquals(77,market.catalog.size);assertEquals("troy_ounce",market.spec("XAU").unit)
        assertEquals("barrel",market.spec("WTI").unit);assertEquals("mmbtu",market.spec("NATGAS").unit)
        for(symbol in listOf("AAPL","MSFT","NVDA","SOXL","SOXS"))assertEquals(AssetKind.STOCK,market.spec(symbol).kind)
        assertTrue(market.spec("JPY").initialPrice<ONE);assertTrue(market.spec("CNY").initialPrice<ONE)
        assertEquals(9,market.catalog.count {it.kind==AssetKind.FOREX})
    }
    @Test fun commodityAndCurrencyPurchasesAreValuedInUsdPerRealUnit() {
        val s=state();val trader=TradingEngine(market)
        for(symbol in listOf("XAU","WTI","NATGAS","JPY","CNY")) {
            trader.submit(s,symbol,OrderVenue.SPOT,OrderKind.MARKET,Side.LONG,d(100))
            val h=s.holdings.first {it.symbol==symbol}
            assertTrue((h.quantity*s.quote(symbol).price-d(100).divD(d("1.0002"))).abs()<d("0.000001"))
        }
        assertTrue(s.holdings.first {it.symbol=="JPY"}.quantity>d(10000))
        assertTrue(Wealth.holdingsValue(s)<d(500));assertTrue(Wealth.holdingsValue(s)>d(499))
    }
    @Test fun targetedHackAndLongPolicyEffectsAreSavedAndAppliedToRelevantAssets() {
        val s=state();market.news.publish(s,"token_hack","SOL",-.2,3*NewsEngine.DAY,1.5,"خبر اختراق","Hack report")
        assertTrue(s.quote("SOL").pendingJump<0);assertEquals(0.0,s.quote("BTC").pendingJump)
        assertEquals("SOL",s.effects.single().symbol)
        market.news.publish(s,"policy_decision","USD_POLICY",-.02,42*NewsEngine.DAY,.5,"فائدة","Rates")
        val fx=s.effects.first {it.symbol=="CNY"};assertEquals(42*NewsEngine.DAY,fx.expiresAt-fx.startsAt)
        assertTrue(s.quote("XAU").pendingJump<0);assertTrue(s.quote("JPM").pendingJump>0)
        val sol=s.quote("SOL").price;market.step(s);assertTrue(s.quote("SOL").price<sol*d("0.95"))
        assertTrue(s.effects.any {it.id==fx.id});assertEquals("policy_decision",s.news.first().key)
    }
    @Test fun geopoliticalRiskMovesHavensAndRiskAssetsInOppositeDirections() {
        val s=state();market.news.publish(s,"geopolitical_risk","GLOBAL",-.04,7*NewsEngine.DAY,1.0,"توتر","Tension")
        assertTrue(s.quote("BTC").pendingJump<0);assertTrue(s.quote("NVDA").pendingJump<0)
        assertTrue(s.quote("XAU").pendingJump>0);assertTrue(s.quote("JPY").pendingJump>0)
        assertTrue(s.quote("WTI").pendingJump>0);assertEquals(0.0,s.quote("USD").pendingJump)
    }
    @Test fun randomNewsHasDiverseTemplatesVariableWaitingTimesAndNoSixHeadlineRepeat() {
        val s=state();val keys=mutableListOf<String>();val waits=mutableSetOf<Long>()
        repeat(80) {
            s.economy.nextRandomNewsAt=s.marketTime
            market.news.step(s,RandomSource(s));val key=s.economy.lastNewsKeys.last()
            assertFalse(key in keys.takeLast(6));keys.add(key)
            waits.add(s.economy.nextRandomNewsAt-s.marketTime)
        }
        assertTrue(keys.toSet().size>25);assertTrue(waits.size>30)
        assertTrue(s.news.all {it.titleAr.isNotEmpty() && it.titleEn.isNotEmpty()})
        assertTrue(NewsTemplates.all.sumOf {it.ar.size}>=120)
    }
    @Test fun newsAndPricesResumeTheSavedRandomStreamExactly() {
        val a=state();market.listings.initialize(a);a.economy.nextRandomNewsAt=a.marketTime
        val b=GameStateCopy.copy(a);repeat(20){market.step(a);market.step(b)}
        assertEquals(a,b)
    }
    @Test fun listingsCannotExecuteBeforeOpeningAndFirstDayIsSpotOnly() {
        val s=state();market.listings.initialize(s);val listing=s.listings.first();val trader=TradingEngine(market)
        assertTrue(s.quotes.none {it.symbol==listing.spec.symbol})
        assertFailsWith<IllegalArgumentException>{trader.submit(s,listing.spec.symbol,OrderVenue.SPOT,OrderKind.MARKET,Side.LONG,d(10))}
        s.marketTime=listing.opensAt;market.listings.step(s,RandomSource(s))
        val q=s.quote(listing.spec.symbol);assertEquals(ListingStatus.LIVE,listing.status)
        assertTrue(q.bars.values.all {it.size==1});assertTrue(q.price>ZERO)
        trader.submit(s,listing.spec.symbol,OrderVenue.SPOT,OrderKind.MARKET,Side.LONG,d(10))
        assertFailsWith<IllegalArgumentException>{trader.submit(s,listing.spec.symbol,OrderVenue.FUTURES,OrderKind.MARKET,Side.LONG,d(10))}
        s.marketTime+=NewsEngine.DAY;trader.submit(s,listing.spec.symbol,OrderVenue.FUTURES,OrderKind.MARKET,Side.LONG,d(10))
        assertEquals(listing.spec.symbol,s.positions.single().symbol)
    }
    @Test fun leveragedEtfsShareTheBenchmarkAndHaveOppositeDailyReturns() {
        val s=state();repeat(10){market.step(s)}
        val underlying=s.quote("SOXX");val daily=underlying.price.divD(underlying.dayOpen)-ONE
        for(symbol in listOf("SOXL","SOXS")) {
            val q=s.quote(symbol);val expense=d("0.01")*d(s.marketTime%NewsEngine.DAY).divD(d(365L*NewsEngine.DAY))
            val expected=(ONE+d(market.spec(symbol).dailyLeverage)*daily)*(ONE-expense)-ONE
            assertTrue(((q.price.divD(q.dayOpen)-ONE)-expected).abs()<d("0.00000001"))
        }
    }
    @Test fun everyMinuteHasFourRiskMarksAndCandleBoundsCoverThoseMarks() {
        val s=state();val prices=mutableListOf<java.math.BigDecimal>();market.step(s){prices.add(s.quote("BTC").price)}
        assertEquals(4,prices.size);assertEquals(1L,s.ticks)
        for(price in prices)assertTrue(s.quote("BTC").bars[5]!!.last().let {price in it.low..it.high})
    }
    @Test fun weekendClosesEnergyAndForexButLeavesCryptoOpen() {
        val time=java.time.Instant.parse("2026-10-10T12:00:00Z").toEpochMilli()
        assertFalse(market.isOpen(market.spec("XAU"),time));assertFalse(market.isOpen(market.spec("JPY"),time))
        assertTrue(market.isOpen(market.spec("BTC"),time));assertFalse(market.isOpen(market.spec("AAPL"),time))
    }
    @Test fun stockAndEtfFuturesAreAllowedButSpotAndVenueMismatchesAreRejected() {
        val s=state()
        val trader=TradingEngine(market)
        // Stock futures use the Futures wallet/engine, not the dedicated Stocks venue.
        trader.submit(s,"NVDA",OrderVenue.FUTURES,OrderKind.MARKET,Side.LONG,d(100),leverage=5)
        assertEquals("NVDA",s.positions.single().symbol)
        assertEquals(OrderVenue.FUTURES,s.trades.first().venue)
        trader.submit(s,"SOXX",OrderVenue.FUTURES,OrderKind.MARKET,Side.SHORT,d(100),leverage=5)
        assertEquals(2,s.positions.size)
        assertFailsWith<IllegalArgumentException> {
            trader.submit(s,"NVDA",OrderVenue.SPOT,OrderKind.MARKET,Side.LONG,d(100))
        }
        assertFailsWith<IllegalArgumentException> {
            trader.submit(s,"BTC",OrderVenue.STOCK,OrderKind.MARKET,Side.LONG,d(100))
        }
    }

}
