package com.wealthempire.core

import com.wealthempire.core.market.*
import com.wealthempire.core.models.*
import com.wealthempire.core.savings.SavingsRules as Earn
import com.wealthempire.core.statistics.Wealth
import org.junit.Test
import kotlin.test.*
import java.math.BigDecimal

class SavingsTest {
    private val market=MarketEngine()
    private fun state()=GameState(marketTime=0,spotCash=d(1000)).also {s->
        AssetCatalog.defaults.forEach {s.quotes.add(Quote(it.symbol,it.initialPrice,it.initialPrice))}
        s.holdings.add(Holding("BTC",d(2),d(100000)));Earn.seed(s,market)
    }
    private fun near(a:BigDecimal,b:BigDecimal)=assertTrue((a-b).abs()<d("0.000000000000000000001"),"$a != $b")
    @Test fun annualRatePaysTokensAndSubscriptionConservesEquity() {
        val s=state();val before=Wealth.financialTotal(s)
        val offer=s.savingsOffers.first {it.symbol=="BTC"};offer.baseApr=d(36.5);offer.bonusApr=ZERO
        Earn.subscribe(s,market,"BTC",ONE,0,false,0)
        near(before,Wealth.financialTotal(s));near(d(50000),s.savings.single().costBasis)
        Earn.advance(s,market,Earn.DAY)
        near(d("0.001"),s.savings.single().rewards)
        near(before+d(65),Wealth.financialTotal(s));near(d(65),s.stats.savings)
    }
    @Test fun flexiblePartialRedemptionConservesTokensAndCostBasis() {
        val s=state();Earn.subscribe(s,market,"BTC",ONE,0,false,0)
        Earn.advance(s,market,Earn.DAY/2);val p=s.savings.single();val reward=p.rewards;val total=Wealth.financialTotal(s)
        Earn.redeem(s,market,p.id,d("0.25"),Earn.DAY/2)
        near(d("0.75"),p.principal);near(d(37500),p.costBasis)
        near(d("1.25")+reward*d("0.25"),s.holdings.single().quantity)
        near(d(62500),s.holdings.single().cost);near(total,Wealth.financialTotal(s))
        Earn.redeem(s,market,p.id,ONE,Earn.DAY/2);assertTrue(s.savings.isEmpty())
        near(d(100000),s.holdings.single().cost);near(d(2)+reward,s.holdings.single().quantity)
    }
    @Test fun globalBonusQuotaCannotBeMultipliedBySplittingDeposits() {
        val a=state();val b=state()
        Earn.subscribe(a,market,"BTC",ONE,0,false,0)
        Earn.subscribe(b,market,"BTC",d("0.25"),0,false,0);Earn.subscribe(b,market,"BTC",d("0.75"),0,false,0)
        val expected=d("0.5")+d("1.5")*d(1000).divD(d(65000))
        near(expected,Earn.flexibleApr(a,"BTC"))
        Earn.advance(a,market,Earn.DAY);Earn.advance(b,market,Earn.DAY)
        near(a.savings.single().rewards,b.savings.fold(ZERO){sum,p->sum+p.rewards})
    }
    @Test fun DailyCompoundingDoesNotDependOnTickFrequency() {
        val a=state();val b=state();Earn.subscribe(a,market,"BTC",ONE,0,true,0);Earn.subscribe(b,market,"BTC",ONE,0,true,0)
        Earn.advance(a,market,3*Earn.DAY)
        for(i in 1..72)Earn.advance(b,market,i*Earn.DAY/24)
        near(a.savings.single().rewards,b.savings.single().rewards)
        assertEquals(a.rngState,b.rngState);assertEquals(a.savingsOffers,b.savingsOffers)
        val reward=a.savings.single().rewards;Earn.advance(a,market,3*Earn.DAY);Earn.advance(a,market,Earn.DAY)
        near(reward,a.savings.single().rewards)
    }
    @Test fun lockedRateStaysFixedAndDailyPaymentIsNotDoubleCounted() {
        val s=state();Earn.subscribe(s,market,"BTC",ONE,30,true,0)
        val p=s.savings.single();val rate=p.fixedApr;val before=Wealth.financialTotal(s)
        s.savingsOffers.first {it.symbol=="BTC"}.locked30Apr=d(90)
        Earn.advance(s,market,Earn.DAY)
        val expected=rate.divD(d(36500))
        near(expected,p.distributed);near(ZERO,p.rewards);assertFalse(p.autoCompound)
        near(before+expected*d(65000),Wealth.financialTotal(s));near(expected*d(65000),s.stats.savings)
    }
    @Test fun earlyLockedRedemptionClawsBackPaidRewardsAndPreservesOriginalBasis() {
        val s=state();Earn.subscribe(s,market,"BTC",ONE,30,false,0);val p=s.savings.single()
        Earn.advance(s,market,2*Earn.DAY);val distributed=p.distributed
        Earn.redeem(s,market,p.id,ONE,2*Earn.DAY)
        assertEquals(SavingsStatus.REDEEMING,p.status);near(ONE-distributed,p.principal);near(d(50000),p.costBasis)
        near(ZERO,s.stats.savings);val principal=p.principal
        Earn.advance(s,market,5*Earn.DAY-1);assertEquals(principal,s.savings.single().principal)
        Earn.advance(s,market,5*Earn.DAY);assertTrue(s.savings.isEmpty())
        near(d(2),s.holdings.single().quantity);near(d(100000),s.holdings.single().cost)
    }
    @Test fun lockedMaturityReturnsPrincipalAndAllAnnualizedRewards() {
        val s=state();Earn.subscribe(s,market,"BTC",ONE,30,false,0);val rate=s.savings.single().fixedApr
        Earn.advance(s,market,30*Earn.DAY);assertTrue(s.savings.isEmpty())
        near(d(2)+rate*d(30).divD(d(36500)),s.holdings.single().quantity)
        near(d(100000),s.holdings.single().cost);assertEquals("MATURED",s.savingsHistory.first().action)
    }
    @Test fun StableSavingsUseSpotCashAndReturnToTheSameWallet() {
        val s=state();val cash=s.cash;Earn.subscribe(s,market,"USDT",d(500),0,false,0)
        near(d(500),s.spotCash);assertEquals(cash,s.cash)
        Earn.redeem(s,market,s.savings.single().id,ONE,0);near(d(1000),s.spotCash)
    }
    @Test fun coinsReservedForSellOrdersCannotBeSubscribed() {
        val s=state();val trader=com.wealthempire.core.trading.TradingEngine(market)
        trader.submit(s,"BTC",OrderVenue.SPOT,OrderKind.LIMIT,Side.SHORT,d("1.5"),trigger=d(70000))
        near(d("0.5"),Earn.available(s,"BTC"));val old=GameStateCopy.copy(s)
        assertFailsWith<IllegalArgumentException>{Earn.subscribe(s,market,"BTC",ONE,0,false,0)}
        assertEquals(old,s)
    }
    @Test fun partialLockedReturnAndInvalidTermsCannotMutateFunds() {
        val s=state();Earn.subscribe(s,market,"BTC",ONE,30,false,0);val before=GameStateCopy.copy(s)
        assertFailsWith<IllegalArgumentException>{Earn.redeem(s,market,s.savings.single().id,d("0.25"),Earn.DAY)}
        assertEquals(before,s)
        assertFailsWith<IllegalArgumentException>{Earn.subscribe(s,market,"BTC",ONE,7,false,0)}
        assertEquals(before,s)
    }
}
