package com.wealthempire.core
import com.wealthempire.core.models.*
import com.wealthempire.core.market.*
import com.wealthempire.core.trading.*
import com.wealthempire.core.statistics.Wealth
import com.wealthempire.core.wallet.WalletRules
import java.math.BigDecimal
import org.junit.Test
import kotlin.test.*
class TradingUpdatesTest {
 private val t=TradingEngine(MarketEngine())
 private fun state()=GameState(schema=2,futuresCash=d(100)).also {it.quotes.add(Quote("BTC",d(100),d(100)));it.quotes.add(Quote("ETH",d(20),d(20)))}
 private fun p(s:GameState,side:Side=Side.LONG,qty:BigDecimal=d(10),mode:MarginMode=MarginMode.CROSS,symbol:String="BTC")=Position(s.id(),symbol,side,mode,10,s.quote(symbol).price,qty,d(100),d(100),openedAt=0).also {s.positions.add(it)}
 private fun near(a:BigDecimal,b:BigDecimal)=assertTrue((a-b).abs()<d("0.000000001"),"$a != $b")
 @Test fun hedgeMovesSharedBoundary(){val s=state();val a=p(s);val before=FuturesMath.liquidationRange(s,a).lower!!;val b=p(s,Side.SHORT,d(5));val r=FuturesMath.liquidationRange(s,a);assertTrue(r.lower!!<before);assertEquals(r,FuturesMath.liquidationRange(s,b));near(ZERO,FuturesMath.crossSafetyAt(s,"BTC",r.lower!!))}
 @Test fun equalHedgeRemovesDownsideRisk(){val s=state();val a=p(s);p(s,Side.SHORT);val r=FuturesMath.liquidationRange(s,a);assertNull(r.lower);assertTrue(r.upper!!>d(100));near(ZERO,FuturesMath.crossSafetyAt(s,"BTC",r.upper!!));s.quote("BTC").price=d(1);t.risk(s);assertEquals(2,s.positions.size)}
 @Test fun shortHeavyHedgeHasUpsideBoundary(){val s=state();val a=p(s,Side.SHORT);p(s,qty=d(5));val r=FuturesMath.liquidationRange(s,a);assertNull(r.lower);assertTrue(r.upper!!>d(100));near(ZERO,FuturesMath.crossSafetyAt(s,"BTC",r.upper!!))}
 @Test fun isolatedIgnoresOtherCollateral(){val s=state();val a=p(s,mode=MarginMode.ISOLATED);val r=FuturesMath.liquidationRange(s,a);p(s,Side.SHORT);s.futuresCash=d(99999);assertEquals(r,FuturesMath.liquidationRange(s,a));assertNull(r.upper)}
 @Test fun otherSymbolPnlMovesBoundary(){val s=state();val a=p(s);p(s,symbol="ETH");val before=FuturesMath.liquidationRange(s,a).lower!!;s.quote("ETH").price=d(25);val after=FuturesMath.liquidationRange(s,a).lower!!;assertTrue(after<before);near(ZERO,FuturesMath.crossSafetyAt(s,"BTC",after));assertEquals(d(25),s.quote("ETH").price)}
 @Test fun displayedBoundaryMatchesActualRisk(){val s=state();val a=p(s);p(s,Side.SHORT,d(5));val bound=FuturesMath.liquidationRange(s,a).lower!!;s.quote("BTC").price=bound+d("0.01");t.risk(s);assertEquals(2,s.positions.size);s.quote("BTC").price=bound-d("0.01");t.risk(s);assertTrue(s.positions.isEmpty());assertTrue(s.trades.all {it.reason=="LIQUIDATED"})}
 @Test fun maintenanceContinuousAcrossTiers(){for(e in listOf(50000,250000,1000000)){val a=FuturesMath.maintenanceAmount(d(e));assertTrue((a-FuturesMath.maintenanceAmount(d(e)-d("0.01"))).abs()<d("0.001"));assertTrue((a-FuturesMath.maintenanceAmount(d(e)+d("0.01"))).abs()<d("0.001"))};near(d(25),FuturesMath.maintenanceAmount(d(50000)));near(d(225),FuturesMath.maintenanceAmount(d(250000)));near(d(2100),FuturesMath.maintenanceAmount(d(1000000)))}
 @Test fun partialAllocatesAllCapitalAndKeepsBrackets(){val s=state();val a=p(s,mode=MarginMode.ISOLATED).copy(margin=d(98),funding=d(-2),openFee=ONE,takeProfit=d(130),stopLoss=d(95));s.positions[0]=a;s.quote("BTC").price=d(110);val before=Wealth.total(s);t.closeFraction(s,a.id,d("0.25"));val b=s.positions.single();near(d("7.5"),b.quantity);near(d("73.5"),b.margin);near(d(75),b.originalMargin);near(d("-1.5"),b.funding);near(d("0.75"),b.openFee);assertEquals(a.takeProfit,b.takeProfit);assertEquals(a.stopLoss,b.stopLoss);assertEquals(a.id,b.id);near(d("24.1125"),s.stats.futures);near(d("0.3875"),s.trades.single().fees);near(before-d("0.1375"),Wealth.total(s))}
 @Test fun repeatedPartialEqualsSingleFullClose(){
 fun filled()=state().also {val a=p(it,mode=MarginMode.ISOLATED);it.positions[0]=a.copy(openFee=ONE);it.quote("BTC").price=d(110)}
 val a=filled();val b=filled();val id=a.positions.single().id;t.closeFraction(a,id,d("0.25"));t.closeFraction(a,id,d("0.5"));t.close(a,id);t.close(b,b.positions.single().id);near(a.futuresCash,b.futuresCash);near(a.stats.futures,b.stats.futures);near(a.stats.fees,b.stats.fees);near(d(10),a.trades.fold(ZERO){v,x->v+x.quantity});assertTrue(a.positions.isEmpty())}
 @Test fun partialShortProfit(){val s=state();val a=p(s,Side.SHORT,mode=MarginMode.ISOLATED);s.quote("BTC").price=d(90);t.closeFraction(s,a.id,d("0.5"));near(d("49.775"),s.stats.futures);near(d(5),s.positions.single().quantity)}
 @Test fun invalidFractionsLeavePositionIntact(){val s=state();val a=p(s);for(f in listOf(ZERO,d(-1),d("1.01")))assertFailsWith<IllegalArgumentException>{t.closeFraction(s,a.id,f)};assertEquals(a,s.positions.single());assertTrue(s.trades.isEmpty());assertFailsWith<IllegalArgumentException>{t.closeFraction(s,999,ONE)}}
 @Test fun losingHedgeCloseDoesNotLiquidateHealthyPool(){val s=state();val a=p(s);p(s,Side.SHORT);s.quote("BTC").price=d(10);val before=Wealth.total(s);t.close(s,a.id);assertTrue(s.futuresCash<ZERO);assertEquals(1,s.positions.size);assertTrue(FuturesMath.crossEquity(s)>FuturesMath.crossRequirement(s));near(before-d("0.05"),Wealth.total(s));assertFails {WalletRules.transfer(s,Wallet.FUTURES,Wallet.CASH,ONE)};t.close(s,s.positions.single().id);near(d("299.9"),s.futuresCash)}
 @Test fun profitableHedgePartialMaintainsHealthyPool(){val s=state();p(s);val b=p(s,Side.SHORT);s.quote("BTC").price=d(10);t.closeFraction(s,b.id,d("0.5"));assertEquals(2,s.positions.size);assertTrue(FuturesMath.crossEquity(s)>FuturesMath.crossRequirement(s));t.close(s,b.id);assertEquals(1,s.positions.size)}
}
