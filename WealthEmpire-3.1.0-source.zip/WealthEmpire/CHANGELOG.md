# 3.1.1 — Stock & ETF futures fix
- Fixed market validation so futures contracts can be opened on stocks and ETFs.
- Added regression coverage for stock/ETF futures and rejected invalid Spot/Stocks venue combinations.
- Preserved application ID, debug signing key, save schema, and existing player progress.

# 3.0.0 — Financial World

Causal four-region economics, expectations and central banks, company earnings, sector factors, branching event news, commodities/forex/bonds, liquidity and funding. Priority command actor, Room event journal, asynchronous streaming snapshots and full adaptive offline backlog. Redesigned dashboard/markets/terminal/portfolio/economy/progression, away report, career modes and analytical unlocks. Retains Cross hedging, partial closure, Earn and chart gesture arbitration. No mining/gambling.

# Changelog

## 2.1.0 — 2026-10-06
- Removed mining routes, screens, illustrations, resources, income rules, models, commands and snapshot fields.
- New-game starting cash and accounting baseline are $20,000; no uninvested-cash income.
- User-authorized one-time restart of prior economies1–4; schema5 progress saves normally and is not refilled on reopen.
- Removed obsolete gambling data models along with prior-economy compatibility obligations.
- Five-tab navigation; dashboard mining statistic replaced by savings profit. First milestone is$50,000.
- Added no-idle-income, clock-speed, one-time restart, current-save continuity and removed-field persistence coverage.
- versionCode6; same existing package/key retained without requiring previous progress preservation.

## 2.0.0 — 2026-10-06
- Expanded catalog to 75 assets: real-company stocks/ETFs, gold/metals, oil/gas and USD-valued Forex; legacy holdings preserved.
- Correlated price factors, volatility clustering, four intraminute risk marks, macro surprises, persistent news effects and branching investigations; 120 headline variants.
- Saved emerging crypto listings with prelaunch restrictions, opening gaps and first-day Spot trading.
- Token-denominated flexible and fixed-term Earn, shared bonus tiers, daily rewards, partial flexible redemption, maturity and early-return clawbacks.
- Removed gambling navigation, UI and wager engine; historical save fields remain data-only.
- Room v2 non-destructive chunk migration and snapshot schema4; same package/key, versionCode5.
- Typed state copies, batched passive checkpoints, lazy lists and enabled-only indicators reduce UI/background work.
- Added financial, market, persistence and UI regression coverage; device instrumentation status recorded in VERIFICATION.md.

## 1.2.1 — 2026-10-06
- Fixed chart/page gesture conflict: one-finger vertical swipes scroll the page, horizontal swipes pan candles, two-finger pinches zoom.
- Stable pointer handling during market ticks; time-anchored historical viewport and a Latest shortcut.
- Adaptive rounded price labels, last-price marker, separate volume strip and aligned indicator plots.
- Compact chart toolbar, on-demand indicator/market details, direct Positions shortcut.
- Added viewport/formatting regression tests and compiled pointer-dispatch instrumentation tests.
- Same package, snapshot schema and financial/market rules as 1.2.0; same fixed signing key, versionCode 4.

## 1.2.0 — 2026-10-06
- Same app/package and fixed signing key as 1.1.0; versionCode 3.
- Adjustable game clock: 1×, 5×, 12×, 16×; mining accelerates with game minutes.
- Weekday/date display and adaptive candle/session timers; phase-safe speed switching.
- Exact carried mining fractions; saved speed used during capped real-time absence.
- Removed modal news/session alerts; optional animated four-second top notice, latest only.
- 3×3 fruit machine with nine selectable, progressively priced paylines, individual prizes and reel motion.
- Dashboard financial total, day delta and chart exclude all mining hardware value.
- Compact futures cards and optional details; partial closing retained.
- Snapshot schema 3 migrates historical data; original slot outcome kept without reroll.
- Full source retained for subsequent UI/game updates. No real-market data integration.

## 1.1.0 — 2026-10-06
- Multiple mining rigs, $300 purchase, level 1 $10/min and level 2 $30/min.
- New-game capital $1,000; prior balances preserved.
- Partial futures closes and Cross hedge-aware liquidation boundaries.
- Simulated market/candle timers and news/session alerts.
- Fixed development signing key introduced; original 1.0.0 private key unavailable.

## 1.0.0
- Original local Android game.

## 3.1.0
- Enabled the Futures/Spot selector for stock-market instruments as well, including listed ETFs such as SPY, QQQ, SOXX, SOXL and SOXS. Stock symbols can now be selected for simulated futures trading.
- Added continuously accrued simulated cash dividends for owned stock and ETF holdings, credited to the Stocks wallet. Annualized yields vary conservatively by instrument category/sector; bond coupons remain unchanged.
