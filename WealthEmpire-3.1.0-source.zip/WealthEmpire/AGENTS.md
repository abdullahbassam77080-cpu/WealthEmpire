# Wealth Empire maintenance

Modify this existing Kotlin Android project. Keep working from this project. For 3.0.0 the user explicitly authorized discarding prior progress; previous economy snapshots restart once at $20,000. Current saves must persist normally.

- Preserve applicationId `com.wealthempire` and `dev-signing/debug.keystore`. Never regenerate the key for an update. Increment versionCode and update versionName/CHANGELOG.
- Core financial rules live in `core`; Compose belongs in `app`. Arabic is primary, English strings must remain aligned.
- Settings offer Pause and 1×, 5×, 12×, 16×. Settle elapsed market time at the old speed before changing it. Preserve the fractional market phase.
- Dashboard financial total includes wallets, holdings, savings and open-position equity; realized profits are already in wallets and must not be counted again.
- Snapshot schema 6 denotes the causal world; schema 5 migrates without discarding finances. Known schemas 1–4 restart once during repository loading using an atomic Room reset. Unknown/corrupt saves remain errors. Do not refill money or reset current schema5/6 saves.
- Mining and gambling are fully removed: no routes, screens, resources, models or income engine. Do not restore them without a new user request. Removed JSON fields are ignored when reading known old saves. All money is virtual.
- Prices are quoted in USD per actual inventory unit (currency, troy ounce, barrel, MMBtu, share, token). Do not treat an inverse FX quote as USD inventory value.
- News families are internal; headlines must be connected to saved impacts, durations, surprises and follow-ups.
- Savings APR is annual in game time. Principal/rewards use token quantities. Respect global bonus quotas, daily compound boundaries, fixed lock APR, early-redeem clawbacks and cost-basis conservation.
- Room v3 uses journal-first commands, 256 KiB current/backup snapshots and non-destructive v1→v2→v3 migrations. Snapshots stream compression on IO every 30 seconds/on STOP. Player commands must never wait for snapshot compression; use the priority actor. Simulation yields between bounded quanta; RNG streams, backlog and event boundaries persist.
- Keep futures cards compact. Additional data belongs in optional details. Preserve Cross hedge-aware risk and partial-close accounting.
- Price engine is a local simulation. No live data or unverifiable claim of matching Saya.
- Chart gestures must leave one-finger vertical scrolling to the page; consume only horizontal drags or two-finger transforms. Keep gesture keys stable during market ticks and anchor historical viewports by candle time.
- Run meaningful core/app unit tests, assembleDebug and lintDebug. Compile instrumentation when UI changes; report honestly if not executed on a device.
- Use JDK 17 / Gradle 8.9 / SDK 35. Build outputs are reproducible; source and signing key are the durable update baseline.
